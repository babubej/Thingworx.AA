#!/bin/bash

#
# Copy this shell script along with suppression file to the main cmake build folder
#
# Remember to check and change LOG_INDEX to store more log files.

day=$(date +%d)
month=$(date +%m)
year=$(date +%Y)

LOG_PREFIX="valgrind_memcheck_${day}-${month}-${year}_"
LOG_INDEX=$(( `ls -1 ${LOG_PREFIX}*valgrind | wc -l` + 1 ))
LOG="${LOG_PREFIX}${LOG_INDEX}.valgrind"
XTREE="${LOG_PREFIX}${LOG_INDEX}.kcg"
SUPPRESS_FILE="valgrind_suppress.txt"
EXE=./bin/ELGiAgent

echo "Executing valgrind for "`basename $EXE`" program..."
valgrind -v --tool=memcheck --leak-check=full --xtree-memory=full \
    --xtree-memory-file=${XTREE} --log-file="${LOG}" \
    --undef-value-errors=no --suppressions="${SUPPRESS_FILE}" \
    --show-leak-kinds=all ${EXE}
