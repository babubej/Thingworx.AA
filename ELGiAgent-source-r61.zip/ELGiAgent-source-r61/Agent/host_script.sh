#!/bin/sh
# Copyright (C) Sierra Wireless Inc. Use of this work is subject to license.
# RUN this script on your host Tested with Ubuntu PC
#
#

# replace the enp0s20f0u2i19 with the interface name seen at your host end.
sudo route add default gw 192.168.2.2 enp0s20f0u2i19

sudo echo -e "nameserver 8.8.8.8\nnameserver 8.8.4.4"  | sudo tee /etc/resolv.conf
