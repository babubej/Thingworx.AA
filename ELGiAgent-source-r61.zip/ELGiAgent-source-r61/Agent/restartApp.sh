#!/bin/sh
# Copyright (C) Sierra Wireless Inc. Use of this work is subject to license.
#
 
# PATH
export PATH=/legato/systems/current/bin:/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin
 
sleep 5 && /legato/systems/current/bin/app start RestartAgent &
 
echo "RESTART INITIATED"