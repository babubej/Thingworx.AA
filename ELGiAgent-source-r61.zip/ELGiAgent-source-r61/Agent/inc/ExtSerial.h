/*
 * ExtSerial.h
 *
 *  Created on: Nov 16, 2017
 *      Author: Francis DUHAUT
 */

#ifndef SERIAL_H_
#define SERIAL_H_

#include <stdio.h>
#include <string.h>
#ifndef WIN32
#include <termios.h>
#include <sys/ioctl.h>
#include <unistd.h>
#endif
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>

/* Divers */
#define in16(var, l, h) var = ((unsigned int)(l)) | (((unsigned int)(h)) << 8)
#define out16(l, h, val)               \
    {                                  \
        l = (unsigned char)val;        \
        h = (unsigned char)(val >> 8); \
    }
#define in24(var, l, m, h) var = ((unsigned long)(l)) | (((unsigned long)(m)) << 8 | ((unsigned long)(h)) << 16)
#define out24(l, m, h, val)             \
    {                                   \
        l = (unsigned char)val;         \
        m = (unsigned char)(val >> 8);  \
        h = (unsigned char)(val >> 16); \
    }

#define LowByte(x) (*((unsigned char *)&x))
#define HighByte(x) (*((unsigned char *)&x + 1))
#define LowWord(x) (*((unsigned short *)&x))
#define HighWord(x) (*((unsigned short *)&x + 1))

int OpenComport(int comport_number, int baudrate);
int PollComport(int comport_number, char *buf, int size);
int SendByte(int comport_number, unsigned char byte);
int SendBuf(int comport_number, const char *buf, int size, int length, int queryNo);
int SendFabNumberBuf(int comport_number, const char *buf, int size);
int SendFrame(int comport_number, unsigned char *buf, int size);
void CloseComport(int comport_number);
int IsCTSEnabled(int comport_number);

#endif /* SERIAL_H_ */
