
/*
 * ExtDataConnection.h
 */

#ifndef DATACONNECTION_H_
#define DATACONNECTION_H_

#include "GeneralDefines.h"

extern GS_BOOL g_bIsWaitingForConnection;

#if defined(LEGATO)
void ExtDataConnection_Initialize(void);
void ExtDataConnection_Shutdown(void);
#endif // LEGATO

#endif // DATACONNECTION_H_
