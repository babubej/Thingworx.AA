/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  Utilities.h
//  
//  Subsystem  :  ELGiAgent
//
//  Description:  Header file for various support (utility) functions for the
//                Example Agent.
//                These functions only use the 'C' run-time library and are 
//                already cross-platform compatible.
//
*****************************************************************************/

#ifndef __UTILITIES_H__
#define __UTILITIES_H__

#include "cJSON.h"
#include "AgentConfig.h"

/*****************************************************************************
// GsVerifyJSONContent
//  - input:  JSON object, JSON object element name, JSON object element value
//  - return:  pointer to memory holding the content of the JSON object element 
//             value.
// caller is responsible to free the memory returned by GsVerifyJSONContent******
//****************************************************************************/
cJSON *GsVerifyJSONContent(cJSON *pszJSONContent, char *pszJSONObjectName);

//*****************************************************************************
// Duplicate the string.
// input:  source string to be duplicated.
// return:  pointer to duplicated string.
//  *** The caller is responsible to free the memory of the returned pointer
//*****************************************************************************
char *GsStringDup(const char *pszSource);

/****************************************************************************
 Get the absolute directory location per CWD
 input: pszSubFolderName:  name of subfolder directory.
 return: pointer to absolute directory path relative to the current working directory
  *** The caller is responsible to free the memory of the returned pointer
****************************************************************************/
char *GsGetRelativeDirectoryName(char *pszDirectoryName);

/*****************************************************************************
Return the absolute path & filename relative to the current working directory. 
input:   
    - pszSubFolderName:  Optional sub-folder name  (can be NULL)
    - pszFileName:  file name
return:  pointer to relative file path.
*** The caller is responsible to free the memory of the returned pointer
*****************************************************************************/
char *GsGetRelativeFilename(char *folderName, char *fileName);

/*****************************************************************************
 Return the full file name path of the path + filename.
 inputs:  pszPath and file name. 
 If path does not end in a deliminter it will be added.
 return:  pointer to complete file name with path.
  *** The caller is responsible to free the memory of the returned pointer

*****************************************************************************/
char *GsAppendFilenameToPath(char *pszPath, char *pszFileName);

/*****************************************************************************
Return the full file name path of the path + filename.
input:   
    - pszPath:  path name (relative or absolute)
    - pszFolderName:  folder name to be appended.
 If path does not end in a deliminter it will be added.
 return:  pointer to complete file name with path.
  *** The caller is responsible to free the memory of the returned pointer
*****************************************************************************/
char *GsAppendFolderNameToPath(char *pszPath, char *pszFolderName);

/*****************************************************************************
 Signal to intiate shutdown process
*****************************************************************************/
void GsInitializeShutdownEvent();
unsigned long GsWaitForShutdownEvent(unsigned long delay);
void GsSignalShutdownEvent();
void GsGsDestroyShutdownEvent();

//*****************************************************************************
// Function pointer for a twlist destructor:
// Item will be removed from a list (by twlist), but NOT deleted.
// the Item entries memory is managed else where (by g_pPropertyTemplateList).
//
// Note:  if memory management becomes more difficult, may need to add
// some type of reference counting.
void GsDontDeleteFunc(void *pItem);

// Check whether or not provided path is absolute.
GS_BOOL GsIsPathAbsolute(const char *pszPath);

// Create the directory based on the input configured path.
// The configured string can be a relative or absolute path.
// If relative, it is appended to the current working directory.
// Optional argument for custom current directory path.
// Caller owns the returned memory.
char *GsCreateRelOrAbsDir(char *pszConfiguredPath, char *pszCustomCwd);

// General function to initiate a shutdown.  Set bRestartApplication to restart the Agent application.
void GsShutdownApplication(GS_BOOL bRestartApplication);

// Recursively delete all contents of a directory. !!! Be careful !!!
// return 0 if successful, otherwise error code
int GsDeleteDirectoryRecursive(char *pszDirectory);

// If file exists, backup by renaming with added timestamp
// returns return of the MoveFile instruction as the success code:  TW_OK or GetLastError()
int GsBackupFileWithTimestamp(char *pszFilename);

#endif /* __UTILITIES_H__ */
