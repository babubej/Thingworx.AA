//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  MessageThreadPoolMgr.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Define the public functions used to initialize/start/stop the thread
//                to manage the SDK's twMessageHandler_msgHandlerTask().
//
//*****************************************************************************

#ifndef __MESSAGE_THREAD_POOL_MGR_H__
#define __MESSAGE_THREAD_POOL_MGR_H__

#include "twApi.h"

// 'public' Functions
void MessageThreadPoolMgr_Initialize();
int MessageThreadPoolMgr_Start();
void MessageThreadPoolMgr_Shutdown();

void MessageThreadPoolMgr_SignalThread();

void MessageThreadPool_SetThreadScanPeriod(int iPeriod);
void MessageThreadPool_SetPoolSize(int iPoolSize);
void MessageThreadPool_SetTaskIterations(int iIterations);

#endif // __MESSAGE_THREAD_POOL_MGR_H__
