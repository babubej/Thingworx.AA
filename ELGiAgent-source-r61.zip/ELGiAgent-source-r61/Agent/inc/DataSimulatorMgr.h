//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  DataSimulatorMgr.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Define the public functions to manage initialization,
//                start and stopping of the Data (property) Simulator.
//
//*****************************************************************************

#ifndef __DATA_SIMULATOR_MGR_H__
#define __DATA_SIMULATOR_MGR_H__

// 'public' Functions
int DataSimulatorMrg_ReadConfiguration();
void DataSimulatorMgr_Initialize();
int DataSimulatorMgr_Start();
void DataSimulatorMgr_Shutdown();

extern GS_BOOL g_bSimulatorEnabled;

#endif // __DATA_SIMULATOR_MGR_H__
