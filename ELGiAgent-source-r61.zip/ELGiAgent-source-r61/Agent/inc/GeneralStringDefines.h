/*****************************************************************************
// 
//  Copyright © 1985-2020 PTC.  All rights reserved. 
// 
******************************************************************************
// 
//  Filename   : GeneralStringDefines.h
//   
//  Subsystem :  ELGiAgent 
// 
//  Description: General String definition used in the project 
//               The ELGiAgent philosophy is that strings should be defined in a central
//               file and not used directly within the code.
// 
// 
******************************************************************************/
#ifndef _GENERAL_STRING_DEFINES_H_
#define _GENERAL_STRING_DEFINES_H_

static char *STR_SUCCESS = "success";
static char *STR_VERSION = "version";

/* configuration defaults */
static char *STR_DEFAULT_LOGFILE_DIRECTORY = "/temp/agent_logs/agent.log";
static char *STR_DEFAULT_DATA_LOG_DIRECTORY = "data_logs";

static char *STR_IT_COL_RESULT = "result";
static char *STR_IT_COL_INPUT = "input";

static char *STR_MODBUS_CONFIG_FILENAME = "Modbus.cfg";
static char *STR_TAG_PARSER_CONFIG_FILENAME = "tag_parser.cfg";

/* json files */
static char *STR_JSON_FILE_AGENT_CONFIG = "agent_config.json";
static char *STR_JSON_FILE_FILE_TRANSFER = "file_transfer.json";
static char *STR_JSON_FILE_LOGGING = "logging.json";
static char *STR_JSON_FILE_OFFLINE_MSG = "offline_msg.json";
static char *STR_JSON_FILE_PROPERTIES = "properties.json";
static char *STR_JSON_FILE_WS_CONNECTION = "ws_connection.json";
static char *STR_JSON_FILE_SERVER_CONFIG = "server_config.json";
static char *STR_JSON_FILE_CONNECTION_CONF = "connection.json";
static char *STR_THROUGHPUT_EVALUATION_FILENAME = "throughput_evaluation.csv";
static char *STR_THROUGHPUT_EVALUATION_FILENAME_NO_EXT = "throughput_evaluation";
static char *STR_DATA_BUFFER_FILENAME = "data_buffer.csv";
static char *STR_DATA_BUFFER_FILENAME_NO_EXT = "data_buffer";
static char *STR_CSV_EXT = ".csv";

/* WS_Connection .json */
static char *STR_WS_CONNECTION = "ws_connection";
static char *STR_CONNECTION_TIMEOUT = "connect_timeout";
static char *STR_DUTY_CYCLE = "duty_cycle";
static char *STR_PING_RATE = "ping_rate";
static char *STR_PINGPONG_TO = "pingpong_timeout";
static char *STR_MAX_MSG_SIZE = "max_msg_size";
static char *STR_MSG_CHUNK_SIZE = "message_chunk_size";
static char *STR_CONNECT_RETRY_INTERVAL = "connect_retry_interval";
static char *STR_MAX_CONNECT_DELAY = "max_connect_delay";
static char *STR_MAX_MESSAGES = "max_messages";
static char *STR_VERBOSE = "verbose";
static char *STR_FRAME_READ_TIMEOUT = "frame_read_timeout";
static char *STR_DEFAULT_MESSAGE_TIMEOUT = "default_message_timeout";
static char *STR_DISABLE_WEB_SOCKET_COMPRESSION = "disable_compression";
static char *STR_SOCKET_READ_TIMEOUT = "socket_read_timeout";
static char *STR_ENABLE_TLS_HOSTNAME_VALIDATION = "enable_tls_hostname_validation";

/* Logging.json */
static char *STR_LOGGER = "logger";
static char *STR_LEVEL = "level";
static char *STR_MAX_FILE_STORAGE = "max_file_storage";

/* OFFLINE_MSG.json*/
static char *STR_OFFLINE_MSG_STORAGE = "offline_msg_store";
static char *STR_MAX_SIZE = "max_size";
static char *STR_DIRECTORY = "directory";

/* File_transfer.json */
static char *STR_FILE = "file";
static char *STR_BUFFER_SIZE = "buffer_size"; // used in multiple config files.
static char *STR_MAX_FILE_SIZE = "max_file_size";
static char *STR_STAGING_DIR = "staging_dir";
static char *STR_VIRTUAL_DIR = "virtual_dirs";
static char *STR_FILE_TRANSFER_TIMEOUT = "file_transfer_timeout";

/* agent_config file params*/
static char *STR_SCAN_RATE = "scan_rate";
static char *STR_API_TASKER = "api_tasker";
static char *STR_MESSAGE_THREAD_POOL = "message_thread_pool";
static char *STR_POOL_SIZE = "pool_size";
static char *STR_TASK_ITERATIONS = "task_iterations";

// system
static char *STR_SYSTEM = "system";
static char *STR_PUBLISH_MESSAGE_TIMEOUT = "publish_message_timeout";
static char *STR_PUBLISH_DATA_DURING_FILE_TRANSFER_ENABLED = "publish_data_during_file_transfer_enabled";
static char *STR_ENABLE_ERROR_EVENTS = "enable_error_events";
static char *STR_DATA_LOGS_DIR = "data_logs_dir";

// publishing
static char *STR_PUBLISHING = "publishing";
static char *STR_MIN_PROPERTY_QUEUE_SIZE = "min_property_queue_size";
static char *STR_MAX_PROPERTY_QUEUE_SIZE = "max_property_queue_size";
static char *STR_PROPERTY_PUBLISHING_DELAY = "property_publishing_delay";
static char *STR_DATA_BUFFER_OUTPUT_ENABLE = "data_buffer_output_enable";

// software content management
static char *STR_SCM = "scm";
static char *STR_SCM_STAGING_DIR = "staging_dir";
static char *STR_SCM_IDLE_TIMEOUT = "idle_timeout_hours";

// server_config.json parameters
#define STR_SERVER_CONFIG "server_config"
#define STR_HOST_NAME "host_name"
#define STR_PORT "port"
#define STR_APP_KEY "app_key"
#define STR_THING_IDENTIFIER "thing_identifier"
#define STR_THING_NAME "thing_name"
#define STR_REGISTRATION_THING_NAME "registration_thing_name"
#define STR_REGISTRATION_SERVICE_NAME "registration_service_name"
#define STR_FAB_NUMBER "fab_no"
#define STR_IMEI_NUMBER "imei_no"
#define STR_MACHINE_DETAILS_1 "machine_details_1"
#define STR_MACHINE_DETAILS_2 "machine_details_2"
#define STR_SECURITY "security"
#define STR_USE_PEM_FILE "use_pem_file"
#define STR_PEM_FILE_NAME "pem_file_name"
#define STR_ENABLE_FIPS_MODE "enable_FIPS_mode"
#define STR_IGNORE_DATA "ignore_data"
#define STR_MAPPING_INFO "mapping_info"
#define STR_MODBUS_CONFIG "modbus_config"
#define STR_MODBUS_CONFIG_OK "modbus_config_ok"
#define STR_MACHINE_DETAILS_MOD "machineDetailsModified"
#define STR_TAG_PARSER "tag_parser"
#define STR_TAG_PARSER_OK "tag_parser_ok"
#define STR_SHOULD_RESTART "should_restart"

// Registration services & helpers
static char *STR_REGISTER_SERVICE_DEFAULT = "RegisterAgent";
static char *STR_CREATE_THING_SERVICE = "PreCreateRemoteThing";
static char *STR_BIND_PROPERTIES_SERVICE = "BindRemoteProperties";
static char *STR_BIND_SERVICES_SERVICE = "BindRemoteServices";
static char *STR_BIND_REMOTE_THING_NAME = "remoteThingName";
static char *STR_BIND_REMOTE_METADATA = "remoteMetadata";

// Register parameters
static char *STR_REGISTER_FAB_NUMBER = "fabNumber";
static char *STR_REGISTER_IMEI_NUMBER = "imeiNumber";
static char *STR_REGISTER_DETAILS_1 = "machineDetails_1";
static char *STR_REGISTER_DETAILS_2 = "machineDetails_2";
static char *STR_REGISTER_APPKEY = "AppKey";
static char *STR_REGISTER_THING_NAME = "ThingName";

// Unregister parameters
static char *STR_UNREGISTER_SHOULD_SHUTDOWN = "shouldShutdown";
static char *STR_UNREGISTER_TIMEOUT_SEC = "timeoutSec";

// Error event defines
static char *STR_ERROR_EVENT_NAME = "AgentErrorEvent";
static char *STR_ERROR_EVENT_DESCRIPTION = "Triggered whenever the Agent encounters an error condition";
static char *STR_ERROR_EVENT_DATA_SHAPE_NAME = "AgentErrorEvent.DS";

// Error Event Infotable definitions.
static char *STR_EVENT_CATEGORY = "Category";
static char *STR_EVENT_MESSAGE = "Message";
static char *STR_EVENT_TIMESTAMP = "Time";

// Max-Min-Average property infotable
static char *STR_MMA_MAX = "Max";
static char *STR_MMA_MIN = "Min";
static char *STR_MMA_AVG = "Average";
static char *STR_MMA_COUNT = "Count";
static char *STR_MMA_SHAPE_NAME = "AgentMaxMinAvg.DS";

/* Agent configuration files folder */
static char *CONFIG_FOLDER_NAME = "ConfigFiles"; // ??? should be configurable via AgentConfig.json
static char *BACKUP_FOLDER_NAME = "twBackup";

static char *MODBUS_CONFIG_FOLDER_NAME = "ModbusConfigurator";
static char *MODBUS_DATA_FOLDER_NAME = "ModbusData";
static char *FAB_NUMBER_FOLDER_NAME = "FabNumber";

// static properties
static char *STR_AGENT_VERSION_PROPERTY = "Agent_Version";
static char *STR_AGENT_HOME_ENV_VAR = "AGENT_HOME";
static char *STR_AGENT_DEFAULT_HOME_PATH = "/home/root";
static char *STR_AGENT_DEFAULT_HOME_DIR_NAME = "ELGiAgent";

// ThingWorx Server properties that are read from the edge.
static char *STR_THING_NAME_PROPERTY = "name";

static char *STR_DISCONNECT_REGISTER_FAILURE = "Thing Registration failure";

/* SCM feature */
static char *STR_DEFAULT_SCM_TARGET_DIR = "C:\\temp\\scm_update";
static char *STR_TAR_ENTRY_FILE_EXT_JSON = ".json";
static char *STR_TAR_ENTRY_FILE_EXT_BAT = ".bat";
static char *STR_TAR_ENTRY_FILE_EXT_SH = ".sh";
static char *STR_TAR_ENTRY_FILE_EXT_PEM = ".pem";

#endif /*_GENERAL_STRING_DEFINES_H_*/
