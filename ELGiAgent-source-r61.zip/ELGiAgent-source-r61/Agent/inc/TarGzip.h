//*****************************************************************************
//
//  Copyright © 1985-2017 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  TarGzip.h
//  
// //  Subsystem:  EDC_Agent
//
//  Description:  Wrap the TarLib and GZip 'C' functions.
//
//                The TarLib functionality allows automatic use of Gzip via
//                the gztype definition.  Functionality includes Create,
//                Extract and List the files in a Tar-Gzip (tarball)file.
//
//
//	This TarGzip.h file is modifed from Axeda Agent ETarGzip.h file
//
//*****************************************************************************

#ifndef __TAR_GZIP_H__
#define __TAR_GZIP_H__


// #define T_MAXPATHLEN						512

// Functions here are expected to change the pszZipFileName per the default of the compression algorithm. 
// For example, functions will add .tar.gz as the file extension.
// A WinZip compression implemenation might add .zip extension.
// As a result, the final zip file name may be different from the caller's original name in pFileName
// Extract from Tar-GZip the files to the destination.
// pszZipFileName is an input parameter for the archive file, pszDestination is the location for extracted files
// Note:  This will overwrite any files that are not actively being used by a process.
int TarGzip_Extract(char* pszZipFileName, char* pszDestinationDir);

// List the files in the Tar-GZip file. pszZipFileName is an input parameter for the zip file, output contained in pListFiles.
// Note:  file names are converted to use the correct OS path delimiter. 
int TarGzip_List(char* pszZipFileName, twList* pListFiles);

// Define the constant to activate the GarGzip_Test() function
#ifdef __TEST_GZIP__
void TarGzip_Test();
#endif

#endif // __TAR_GZIP_H__
