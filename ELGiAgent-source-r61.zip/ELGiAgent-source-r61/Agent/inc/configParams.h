/*****************************************************************************
// 
//  Copyright © 1985-2020 PTC.  All rights reserved. 
// 
******************************************************************************
// 
//  Filename   : configParams.h
//   
//  Subsystem :  ELGiAgent 
//
//  Description:
//      Reads values from JSON files and sets the parameters of SDK, 
//      network connection, logging, offline message store, file transfer & server configuration.
//      Also reads ELGiAgent 'module' configurations.
// 
// 
******************************************************************************/
#ifndef __CONFIG_PARAMS_H__
#define __CONFIG_PARAMS_H__

void ConfigCleanUp();
// configure the various SDK and twcfg settings from various json config files.
// An error return is fatal.
int ConfigSdkSettings();
void ReadGenericConfigFiles();
int RefreshServerConfigurationFile();
int RefreshModbusConfigurationFile(char *pszConfigContent);
int RefreshTagParserConfigurationFile(char *pszConfigContent);
void ParseRegisterServiceOutput(cJSON *pJsonResult);

// return the pointer to the static host name.
char *GetThingWorxHostName();
int GetThingWorxPort();

// return pointer to the static AppKey
void GetAppKeyCallback(char *appKeyBuffer, unsigned int maxLength);

// Sets the pointer to the static system identifier
// This is used as the Thing identifier which needs to be mapped to
// the user-friendly Thing Name at the Thingworx Server
void SetThingIdentifier(char *pszIdentifierRoot);

void SetRegistrationThingName(char *pszRegistrationThing);

void SetRegistrationServiceName(char *pszServiceName);

void SetRemoteThingName(char *pszRemoteName);

void SetFabNumber(char *pszInput);

void SetImeiNumber(char *pszInput);

// Get .pem file naem.  Will be NULL if not used.
char *GetPemFileName();

GS_BOOL IsFIPSmodeEnabled();

#endif /* __CONFIG_PARAMS_H__ */
