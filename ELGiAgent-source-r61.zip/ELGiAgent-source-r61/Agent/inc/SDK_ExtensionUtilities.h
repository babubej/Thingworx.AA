/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  SDK_ExtensionUtilities.h
//  
//  Subsystem  :  ELGiAgent
//
//  Description:  
//      Defines various ThingWorx 'C' SDK extenion functions for the Agent project.
//      Why this code is here?? This code has a two fold purpose:
//          1. Wrap the SDK functions with a new function to add or enhance the functionality.
//          2. Expose SDK information that is not 'supposed' to be exposed by the SDK, but is 
//             available from the SDK DLL by defining structures and methods as 'extern'.
// Programmer Note:
//                !!! THUS:  this code is subject to change per SDK API release.  !!!

*****************************************************************************/

#ifndef __SDK_EXTENSION_UTILITIES_H__
#define __SDK_EXTENSION_UTILITIES_H__

#include "AgentConfig.h"

/*****************************************************************************
 Convert a tw primative's value to a string.
 - input:  twPrimitive*
 - return:  pointer to string.
            The caller is responsible to free the memory of the returned string.

*****************************************************************************/
char *GsConvertPrimativeValueToString(twPrimitive *pPrimative);

// Given a virtual directory name, return the actual directory name for the ThingName
//  *** The caller is responsible to free the memory of the returned pointer
char *GsGetActualFolderName(char *pszVirtualDir);

//*****************************************************************************
// Simple 'find' function to find if an known list entry value is in a list.
// return true if value is found,
GS_BOOL Gs_twList_Find(struct twList *pList, void *pEntryValue);

// Append pNewList to pCompositeList to make a composite list.
// The compisit list will own all the nodes.
// Upon return,  pNewList will have a count 0 and will still need to be deleted to
// free the list's memory.
// Note: ThingWorx list locking is not global - therefore the caller will need to block lists as needed, ...
//       ... Note: the pCompositeList's mutex CANNOT be locked because w/o recursive a mutex the twList_Add()
//       ... function would cause a dead-lock.
// Return:  TW_OK OR TW_INVALID_PARAM
int Gs_twList_AppendList(struct twList *pCompositeList, struct twList *pNewList);

// Get count of all queued values in the subscribed property manager.
int GsGetSpmQueueCount();

// return the percent full of the offline message storage for persisted SPM values.
// Note:  this is stored to a different file then the offline messages.
// If the offline storage is not enabled or persited file stream is not created, return -1.
double GsGetSPMPersistedValuesOfflineStoragePercentFull();

//*********************************************************************************
// return TRUE if there is any SDK data pending being sent to the Server including:
//   - persisted messages
//   - persisted SPM values
//   - buffered SPM values.
//   - SCM jobs in process
GS_BOOL IsAnyInfoPendingToBePublished();

//*********************************************************************************
// Replacement for SDK's twApi_AddPropertyToList in order to define the Property quality
int GsAddPropertyToList(propertyList *proplist, char *pszName, twPrimitive *value,
                        DATETIME timestamp, char *pszQuality);

//*********************************************************************************
// Replacement for SDK's twApi_CreatePropertyList in order to define the Property quality
propertyList *GsCreatePropertyList(char *pszName, twPrimitive *value, DATETIME timestamp,
                                   char *pszQuality);

#endif /* __SDK_EXTENSION_UTILITIES_H__ */
