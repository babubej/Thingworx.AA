//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  API_Task.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Define the public functions used to initialize/start/stop the thread
//                to manage the SDK's twApi_TaskerFunction().
//
//*****************************************************************************

#ifndef __API_TASK_H__
#define __API_TASK_H__

#include "twApi.h"

// 'public' Functions
void API_Task_Initialize();
int API_Task_Start();
void API_Task_Shutdown();
void API_Task_SetScanRate(int iScanRate);
void API_Task_SetTaskIterations(int iIterations);

#endif // __API_TASK_H__
