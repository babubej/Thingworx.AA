//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  DataPublishingMgr.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Define the public functions to manage data (property) publishing
//                to the ThingWorx Server.
//
//*****************************************************************************

#ifndef __DATA_PUBLISHING_MGR_H__
#define __DATA_PUBLISHING_MGR_H__

// 'public' Functions
void DataPublishingMgr_Initialize();
int DataPublishingMgr_Start();
void DataPublishingMgr_Shutdown();

void DataPublishingMgr_SignalThread();

// Transfer the ownership of the propertyList and the publishing of the properties
// to the Publishing Manager.
// The Caller is responsible to destroy the pPropertyList
void DataPublishingMgr_PublishProperties(propertyList *ppPropertylist, GS_BOOL bSynchronized);

// Set the minimum property queue size for publishing properties to the platform
void DataPublishingMgr_SetMinPropertyQueueSize(int minPropertyQueueSize);

// set the maximum # of properties to store in the g_pInterimPropertyList
// before loss of data (throw away newer values).
void DataPublishingMgr_SetMaxPropertyQueueSize(int minPropertyQueueSize);

// Set the property publishing delay time to the platform
void DataPublishingMgr_SetPropertyPublishingDelay(int propertyPublishingDelay);

/*****************************************************************************
Set the data buffer output feature enable/disable.  This is used for 
scalability evaluation.
*****************************************************************************/
void DataPublishingMgr_SetDataBufferOutput(int enabled);

#endif // __DATA_PUBLISHING_MGR_H__
