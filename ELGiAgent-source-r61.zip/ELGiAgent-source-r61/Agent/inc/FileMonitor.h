/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   :  FileMonitor.c
//
//  Subsystem:  ELGiAgent
//
//  Description:  Expose the public function used when subscribing the the SDK's
//                file manager's callback notifications. 
//
******************************************************************************/
#ifndef FILEWATCHER_H_
#define FILEWATCHER_H_

#include "twFileManager.h"

void OnFileCompleteCallbackFunc(char fileRcvd, twFileTransferInfo *info, void *userdata);

#endif /* FILEWATCHER_H_ */
