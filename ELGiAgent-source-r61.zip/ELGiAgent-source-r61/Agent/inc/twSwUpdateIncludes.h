//*****************************************************************************
//
//  Copyright © 1985-2017 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  twSwUpdateIncludes.h
//  
//  Subsystem  :  EDC_Agent
//
//  Description:  
//                This file is a collection of definitions from various files in the 
//                pre-released SDK used for Software Updates.
// 
//                !!!
//                !!! This code will need to be modified once the SCM capability is in the released
//                !!!  SDK.
//                !!!  At this time, this file manages interfacing with the 
//                !!!  pre-released versions of the twSwUpdateManager and twSwUpdateJob files.
//                !!!
//
//*****************************************************************************

#ifndef __TW_SW_UPDATE_INCLUDES_H__
#define __TW_SW_UPDATE_INCLUDES_H__

/**
 * \name SW Update
*/
#define TW_SW_UPDATE_FUNC_ID void *  
/* Use the built in download function */
#define DEFAULT_SW_UPATE_DOWNLOAD_FUNC NULL

/**
 * \brief Signature of a function that is called to perform a SW update function.
 *        The function could be a download or install.
 *
 * \param[in]     script      Full path of script file to execute or, if
 *                            enclosed by <>, the actual script
 * \param[in]     id          The id of the SW Update job
 * \param[in]     entityName  The name of the Thing being updated
 * \param[in]     campaign    The name of the update campaign  (i.e. the SCM deployment name)
 * \param[in]     updateMgr   The name of the UpdateManager on the server  (i.e. the name of the template:  TW.RSM.SFW.SoftwareManager)
 * \param[in]     path        The path to the update file ON THE SERVER  (i.e. the name of the tar.gz file just downloaded).
 * \param[in]     downloadDir The real path to the directory that the update file(s) will be downloaded to.  (i.e. the directory where the downloaded tar.gz is currently)   
 * \param[in]     params      A string containing a whitespace separate list of script flags and name/value pair parameters
 * \param[in]     func_id     A pointer to an opaque identifier used by the download/install function and stored in the job structure (i.e. the JSON that contains all the paramaters just passed into this function)
 * \param[in]     abort       A if TRUE the funcntion should abort its current activity and return TW_SWU_COMPLETE_FAILED
 *
 * \return 0 if complete without errors, 1 if still in progress, 2 if complete with errors.
 *
 * \note This functon may get called multiple times if it spins off a separate process and retuns "still in progress"
 *       It is up to the implementer to keep track of the status of the actual installation and return the proper completion code.
 *
 * \note The script parameter is a text field that may contain the name of a file that contains the script, or if enclosed by <>
 *       it may contain the script itself.  Taken further, if enclosed by a <> it could be a base64 encoded binary executable that
 *       the function will call.  The only stipulation is the the swupdate_func must understand what to do with this parameter.
*/

// Bug Fix:  recommend simply arguements and just pass in the job*  
int SCM_InstallFunc (char * script, char * id, char * entityName, char * campaign, char * updateMgr, char * path, 
							  char * downloadDir, TW_SW_UPDATE_FUNC_ID * func_id, char * params, char abort);

/* Use a custom install function  as defined above */
#define DEFAULT_SW_UPATE_INSTALL_FUNC SCM_InstallFunc

/**
 * \name Software Update Errors 15xx
*/
#define TW_SWUPDATE_MANAGER_NOT_INITIALIZED 1500
#define TW_SWUPDATE_JOB_CREATION_FAILED 1501

// software update defines.
#define TW_SWU_COMPLETE_SUCCESS 0
#define TW_SWU_IN_PROGRESS 1
#define TW_SWU_COMPLETE_FAILED 2

// Agent implementation global variables
// software update global variables.  Originally in twConfig.
extern int32_t  g_sw_update_idle_timeout; 
extern char* g_pszSw_update_staging_dir; 

// array of service names - terminated by the key: "SENTINEL"
extern char * swUpdateServices[];

/* SW update callback for handling all SW Update services. */
extern enum msgCodeEnum swUpdateServiceCallback(const char * entityName, const char * serviceName, twInfoTable * params, twInfoTable ** content);


#endif  // __TW_SW_UPDATE_INCLUDES_H__
