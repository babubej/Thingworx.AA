/*****************************************************************************
* 
*  Copyright © 1985-2020 PTC.  All rights reserved. 
* 
******************************************************************************
* 
*  Filename   : GeneralDefines.h
*   
*  Subsystem  : ELGiAgent
* 
*  Description: General definitions used in the project 
* 
* 
******************************************************************************/
#ifndef _GENERAL_DEFINES_H_
#define _GENERAL_DEFINES_H_

/* Currently supported config file version */
static int CURRENT_CONFIG_FILE_VERSION = 1; // todo:  for future revisions, the version is file dependent (& not univerally defined).
static int PROPERTIES_JSON_VERSION = 1;

/* Time Sync constants */
static int HTTP_HEADER_MAX_SIZE = 10;
static int HTTP_REQUEST_SIZE = 512;
static int TIME_STR_LEN = 13;

#ifdef WIN32
#ifndef PATH_MAX
#define PATH_MAX MAX_PATH
#else
#include <unistd.h> //  Added for the getcwd()
#endif
// define Thread function return type
#define THREAD_FUNCTION_RETURN DWORD WINAPI
#else // Linux
// define Thread function return type
#define THREAD_FUNCTION_RETURN void *
#endif

// Global Service standard defines
typedef char GS_BOOL;
#define GS_OK 0
#define GS_GENERAL_ERR -1
#define GS_FAILED -2 /* failure code, but not necessarily 'fatal' */
#define GS_QUALITY_ERROR -3
#define GS_TIMEOUT_ERROR -4
#define GS_INVALID_PARAMS -5 /* invalid parameters to functions */

// error codes for gzip utility
#define GS_FILEOPEN -10
#define GS_FILEREAD -11
#define GS_TARGZIP_FILENAME_TOO_LONG -12
#define GS_TARGZIP_FILE_FAILURE -13
#define GS_TARGZIP_CREATE_FAILURE -14
#define GS_TARGZIP_EXTRACTION_FAILURE -15
#define GS_TARGZIP_LIST_FAILURE -16

#define GS_FAB_NUMBER_DEFAULT_SLEEP 5000

typedef enum
{
  qUnknown, // default at initialization.  should only used be with max/min/average
  qBad,
  qGood,
  qUnverified_source
} Quality;

#include <string.h>
#include <ctype.h>

#if defined(WIN32) || defined(WIN64)
#ifndef strcasecmp
#define strcasecmp _stricmp
#endif
#endif /* Def WIN32 or Def WIN64 */

#endif /* _GENERAL_DEFINES_H_ */
