//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  ConnectionMgr.h
//
//  Subsystem  :  EMS_GetConnected
//
//  Description:
//     Central management of connecting, reconnecting and disconnecting
//     to/from the ThingWorx Server via the C-SDK.
//
//
//*****************************************************************************

#ifndef __CONNECTION_MGR_H__
#define __CONNECTION_MGR_H__

typedef enum
{
    csSuccess = 0,
    csFailed = -1,
    csAsyncRetry = 1
} ConnectionStatus;

// 'public' Functions
// Thread management functions.
void ConnectionMgr_Initialize();
int ConnectionMgr_Start();
void ConnectionMgr_ShuttingDown();
void ConnectionMgr_Shutdown();

// connection management functions

// bForceConnection true is essentially an 'auto-reconnect' mode of operation.
ConnectionStatus ConnectionMgr_Connect(GS_BOOL bForceConnection);
int ConnectionMgr_Disconnect(char *pszReason);

// configuration functions
void SetDisconnectedPeriodBeforeReboot(double disconnectedPeriodBeforeReboot);
void PushSubscribedPropertiesAsyncSynchronizeStateCallback(char *pszEntityName, twInfoTable *pITsubscriptionInfo, void *pUserdata);

extern uint64_t g_disconnectedPeriodBeforeReboot;

#endif // __CONNECTION_MGR_H__
