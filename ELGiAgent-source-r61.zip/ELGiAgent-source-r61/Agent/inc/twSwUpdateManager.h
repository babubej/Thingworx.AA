//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  tsSwUpdateManager.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:
//      This code is the **Custom** C-SDK definition of Software Content Management (SCM)
//      It should NOT be modified.
//      This code should be removed when the C-SDK release officially supports SCM.
//
//      >>>>>>>>>  For SCM details, see SCM_Task.c <<<<<<<<<<<
//
//*****************************************************************************

/**
 * \file twSwUpdateManager.h
 *s
 * \brief ThingWorx software update structure definitions and functions
 *
 * Contains structure type definitions and function prototypes for ThingWorx
 * API software update operations.
*/

#ifndef SW_UPDATE_MANAGER_H /* Prevent multiple inclusions. */
#define SW_UPDATE_MANAGER_H

#include "twDefinitions.h"
#include "twOSPort.h"
#include "twDefaultSettings.h"
#include "twList.h"
#include "twInfoTable.h"
#include "twSwUpdateIncludes.h"

#include "twSwUpdateJob.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
 * \brief Signature of a function that is called to notify of a SW update state change.
 *
 * \param[in]     job          The SW Update job that has changed state
 *
 * \return Nothing.
*/
    typedef void (*swupdate_notify_func)(const twSwUpdateJob *job);

    /**
 * \brief Creates the ::twSwUpdateManager singleton.
 *
 * \return #TW_OK if successful, positive integral on error code (see
 * twErrors.h) if an error was encountered.
 *
 * \note The ::twSwUpdateManager singleton must be freed via
 * twSwUpdateManager_Delete().
*/
    int twSwUpdateManager_Create();

    /**
 * \brief Deletes the ::twSwUpdateManager singleton and all its owned
 * substructures.
 *
 * \return #TW_OK if successful, positive integral on error code (see
 * twErrors.h) if an error was encountered.
*/
    int twSwUpdateManager_Delete();

    /**
 * \brief Set the name of the download directory for the ::twSwUpdateManager singleton.
 *
 * \param[in]     dirName      The path to the directory.
 *
 * \return #TW_OK if successful, positive integral on error code (see
 * twErrors.h) if an error was encountered.
 *
 * \note A virtual directory named "updates" is associated with a specific ::twThing and
 * has a specific path in the underlying filesystem: /<dirName>/<ThingName>.
 *
 * \note Calling funcntion retains ownership of the dirName char *.
*/
    int twSwUpdateManager_SetDefaultDownloadlDir(char *dirName);

    /**
 * \brief Set the download function for the ::twSwUpdateManager singleton.
 *
 * \param[in]     func      A pointer to the default download funciton.
 *
 * \return #TW_OK if successful, positive integral on error code (see
 * twErrors.h) if an error was encountered.
*/
    int twSwUpdateManager_SetDownloadlFunction(swupdate_func func);

    /**
 * \brief Set the install function for the ::twSwUpdateManager singleton.
 *
 * \param[in]     func      A pointer to the default install function.
 *
 * \return #TW_OK if successful, positive integral on error code (see
 * twErrors.h) if an error was encountered.
 *
*/
    // Fix bug:  changed spelling.
    int twSwUpdateManager_SetInstallFunction(swupdate_func func);

    /**
 * \brief Register for SW update state changes.
 *
 * \param[in]     name     Only notify for SW Update event for this Thing.  Can be NULL which results in all events being sent.
 * \param[in]     callback The function to call
 *
 * \return #TW_OK if successful, positive integral on error code (see
 * twErrors.h) if an error was encountered.
 *
*/
    int twSwUpdateManager_RegisterNotification(char *name, swupdate_notify_func func);

    /**
 * \brief Unregister for SW update state changes.
 *
 * \param[in]     name     Only notify for SW Update event for this Thing.  Can be "*" which results in all events being sent.
 * \param[in]     callback The function to unregister.  Used to uniquely identify which entry to remove.
 *
 * \return #TW_OK if successful, positive integral on error code (see
 * twErrors.h) if an error was encountered.
 *
*/
    int twSwUpdateManager_UnregisterNotification(char *name, swupdate_notify_func func);

    // Fix Bug:  REMOVED FindJobXXX as public functions and change to local functions.
    //          This simplifies a mutex issue with the swUpdateMagnager.
    //          The root cause is Linux mutex should be reentrant... but not designed as such by the SDK.
    //

    /**
 * \brief The SW Update manager Task/thread function.
 *
 * \param[in]    now    Current DATETIME of the system (or ticks).
 *               params Should be NULL
 *
 * \return Nothing
 *
 * \note This function must be registered with the tasker or called in a separate thread
 *        at a relative frequent rate (50 milliseconds or so)
*/
    void twSwUpdateManager_TaskerFunction(DATETIME now, void *params);

    /** Bug Fix:  Enhancement:
    Add function to abort all jobs. 
    This is needed to manage loss of connection 
      1. Because Utilities SCM does not <currently> know how to manage a loss of connection.
      2. A job will get stuck in its current state because SCM doesn't give it the next transition.

     Note: Any message (service call) sent to the Platform will be persisted until the connection is established. 

     return:  true if one or more jobs were aborted.
              false if no jobs were aborted.
*/
    char twSwUpdateManager_AbortJobs();

    /** Bug Fix:  Enhancement:
    Add function to check if any jobs are being processed. 
    This is needed to know when there are not jobs being processed so that a modem can be disconnected.
*/
    char twSwUpdateManager_IsJobInProcess();

#ifdef __cplusplus
}
#endif

#endif
