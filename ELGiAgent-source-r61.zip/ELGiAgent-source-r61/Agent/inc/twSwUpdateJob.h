//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  tsSwUpdateManager.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:
//      This code is the **Custom** C-SDK definition of Software Content Management (SCM)
//      It should NOT be modified.
//      This code should be removed when the C-SDK release officially supports SCM.
//
//      >>>>>>>>>  For SCM details, see SCM_Task.c <<<<<<<<<<<
//
//*****************************************************************************

/**
 * \file twSwUpdateJob.h
 *
 * \brief ThingWorx Software Update Job definiton
*/

#ifndef SW_UPDATE_JOB_H
#define SW_UPDATE_JOB_H

#include "twOSPort.h"
#include "twDefinitions.h"
#include "twInfoTable.h"
#include "cJSON.h"
#include "twList.h"
#include "twSwUpdateIncludes.h"

#ifdef __cplusplus
extern "C"
{
#endif

	typedef enum twSwPackageType
	{
		TW_SWPACKAGE_FIRMWARE,
		TW_SWPACKAGE_LEGATO,
		TW_SWPACKAGE_HADRWARE,
		TW_SWPACKAGE_NEURON,
		TW_SWPACKAGE_AGENT,
		TW_SWPACKAGE_CONFIGFILES,
		TW_SWPACKAGE_GENERIC
	} twSwPackageType;

	/**
	 * \brief An enumeration containing the possible states of a SW Update Job.
     */
	typedef enum twSwUpdateState
	{
		TW_SWUPDATE_CREATED,
		TW_SWUPDATE_NOTIFIED,
		TW_SWUPDATE_WAIT_FOR_DOWNLOAD,
		TW_SWUPDATE_ABORTED,
		TW_SWUPDATE_START_DOWNLOAD,
		TW_SWUPDATE_DOWNLOADING,
		TW_SWUPDATE_DOWNLOADED,
		// Bug fix due to a bug in the ScheduleInstall service.
		//TW_SWUPDATE_WAIT_FOR_INSTALL,
		// Create 2 states.  Once to wait for the command, the other to wait for the time.
		TW_SWUPDATE_WAIT_FOR_INSTALL_COMMAND,
		TW_SWUPDATE_WAIT_FOR_INSTALL_DATETIME,
		TW_SWUPDATE_INSTALLING,
		TW_SWUPDATE_COMPLETED,
		TW_SWUPDATE_FAILED,
		TW_SWUPDATE_DONE,
		TW_SWUPDATE_UNKNOWN
	} twSwUpdateState;

	/**
	 * \brief Signature of a function that is called to perform a SW update function.
	 *        The function could be a download or install.
	 *
	 * \param[in]     script      Full path of script file to execute or, if
	 *                            enclosed by <>, the actual script
	 * \param[in]     id          The id of the SW Update job
	 * \param[in]     entityName  The name of the Thing being updated
	 * \param[in]     campaign    The name of the update campaign
	 * \param[in]     updateMgr   The name of the UpdateManager on the server
	 * \param[in]     path        The path to the update file ON THE SERVER
	 * \param[in]     downloadDir The real path to the directory that the update file(s) will be downloaded to.        
	 * \param[in]     params      A string containing a whitespace separate list of script flags and name/value pair parameters
	 * \param[in]     func_id     A pointer to an opaque identifier used by the download/install function and stored in the job structure
	 * \param[in]     abort       A if TRUE the funcntion should abort its current activity and return TW_SWU_COMPLETE_FAILED
	 *
	 * \return 0 if complete without errors, 1 if still in progress, 2 if complete with errors.
	 *
	 * \note This functon may get called multiple times if it spins off a separate process and retuns "still in progress"
	 *       It is up to the implementer to keep track of the status of the actual installation and return the proper completion code.
	 *
	 * \note The script parameter is a text field that may contain the name of a file that contains the script, or if enclosed by <>
	 *       it may contain the script itself.  Taken further, if enclosed by a <> it could be a base64 encoded binary executable that
	 *       the function will call.  The only stipulation is the the swupdate_func must understand what to do with this parameter.
	 */
	typedef int (*swupdate_func)(char *script, char *id, char *entityName, char *campaign, char *updateMgr, char *path,
								 char *downloadDir, TW_SW_UPDATE_FUNC_ID *func_id, char *params, char abort);

	/**
	 * \brief Software update job data structure.
	 */
	typedef struct twSwUpdateJob
	{
		char *id;						 /**< The id of this job. **/
		char *entityName;				 /**< The ThingName asscoiated with this job. **/
		char *campaignName;				 /**< The name of the campaign this job is associated with. **/
		char *serverUpdateMgr;			 /**< The name of the Update Manager Thing on the server. **/
		DATETIME downloadTime;			 /**< The date/time when we should start download of the file. **/
		DATETIME installTime;			 /**< The date/time when we should start the installation of the update. **/
		char *script;					 /**< The name of the script file to pass to our functions, or the script itself if surrounded with <> **/
		char *path;						 /**< The real path to the directory containing all of the files associated with this update **/
		swupdate_func downloadFunc;		 /**< Pointer to the function that should be called to download the update file.  If NULL the default is to tell the server to execute the download **/
		swupdate_func installFunc;		 /**< Pointer to the function called to perform the actual installation of the software.  CANNOT BE NULL **/
		enum twSwUpdateState state;		 /**< The current state of the job. **/
		enum twSwUpdateState prev_state; /**< The previous state of the job. This is kept to determine state changes for notification purposes **/
		DATETIME lastActivity;			 /**< The last time activity was detected on this job.  Used for timeouts **/
		TW_MUTEX swuJobMtx;				 /**< Mutex protection for the structure **/
		TW_SW_UPDATE_FUNC_ID func_id;	 /**< System specific opaque identifieer for use by the install/downlad functions **/
		char *downloadDir;				 /**< Real path to the directory where the update file(s) will be downloaded to **/
		char *scriptParams;				 /**< Whitespace delimited list of params to be sent to the actual install function **/
	} twSwUpdateJob;

	/**
	 * \brief Creates a new ::twSwUpdateJob structure.
	 *
	 * \param[in]     entityName    The name of the entity associated with this update
	 * \param[in]     json	        A ::cJSON structure containing server provided
	 *                              information for the new ::twSwUpdateJob structure.
	 * \param[in]     vdir          The virtual path to the directory that update file(s) whould be downloaded to
	 * \param[in]     downloadFunc  The function to execute for a download.  Can be NULL if default server file push is used.
	 * \param[in]     installFunc   The function to execute to perform the installation.  Must not be NULL.
	 *
	 * \return A pointer to the newly allocated ::twSwUpdateJob structure.
	 *
	 * \note The calling function retains ownership of the \p it pointer.
	 * \note The calling function gains ownership of the returned
	 * ::twSwUpdateJob structure and is responsible for freeing it via
	 * twSwUpdateJob_Delete().
	 */
	twSwUpdateJob *twSwUpdateJob_Create(const char *entityName, cJSON *json, char *vdir, swupdate_func downloadFunc, swupdate_func installFunc);

	/**
	 * \brief Frees a ::twSwUpdateJob structure an all of its members.
	 *
	 * \param[in]     job    The ::twSwUpdateJob structure to delete.
	 *
	 * \return A 0 if success or a positive integer error code if an error occurred.
	 *
	 */
	void twSwUpdateJob_Delete(void *job);

	/**
	 * \brief Applies the action to a ::twSwUpdateJob.
	 *
	 * \param[in]     job    The ::twSwUpdateJob structure to change.
	 * \param[in]     action The action to change
	 * \param[in]     params The json params recieved from the server
	 *
	 * \return A 0 if success or a positive integer error code if an error occurred.
	 *
	 */
	int twSwUpdateJob_TakeAction(twSwUpdateJob *job, char *action, cJSON *params);

	/**
	 * \brief Set the download time of a ::twSwUpdateJob.
	 *
	 * \param[in]     job    The ::twSwUpdateJob structure to change.
	 * \param[in]     time   The datetime for the download
	 *
	 * \return A 0 if success or a positive integer error code if an error occurred.
	 *
	 */
	int twSwUpdateJob_SetDownloadTime(twSwUpdateJob *job, DATETIME time);

	/**
	 * \brief Set the install time of a ::twSwUpdateJob.
	 *
	 * \param[in]     job    The ::twSwUpdateJob structure to change.
	 * \param[in]     time   The datetime for the install
	 *
	 * \return A 0 if success or a positive integer error code if an error occurred.
	 *
	 */
	int twSwUpdateJob_SetInstallTime(twSwUpdateJob *job, DATETIME time);

	/**
	 * \brief Gets the state of a ::twSwUpdateJob.
	 *
	 * \param[in]     job    The ::twSwUpdateJob structure to change.
	 *
	 * \return The current state of the job in numeric form.
	 *
	 */
	enum twSwUpdateState twSwUpdateJob_GetState(twSwUpdateJob *job);

	/**
	 * \brief Safely determines if the state of a ::twSwUpdateJob has changed
	 *
	 * \param[in]     job    The ::twSwUpdateJob structure to check.
	 *
	 * \return TRUE if the state has changed, FALSE if not.
	 *
	 * \note Calling this when the current state is not the same as the previous
	 *       state will result in TRUE being return.  However, if the state of the 
	 *       job has not changed, subsequent calls to this function will return FALSE
	 *       until the state of the job has changed again.
	 */
	char twSwUpdateJob_StateHasChanged(twSwUpdateJob *job);

	/**
	 * \brief Returns a char * with the text representation of the state of a ::twSwUpdateJob.
	 *
	 * \param[in]     state    The numeric value of the state to convert.
	 *
	 * \return A const char * with the state string or NULL if an error occurred.
	 *
	 */
	const char *twSwUpdateJob_GetStateString(enum twSwUpdateState state);

	/**
	 * \brief Processes the state machine of a ::twSwUpdateJob.
	 *
	 * \param[in]     job    The ::twSwUpdateJob structure to process.
	 *
	 * \return Nothing.
	 *
	 */
	void twSwUpdateJob_Process(twSwUpdateJob *job);

#ifdef __cplusplus
}
#endif

#endif
