//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  AgentConfig.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:  The general purpose header file for the ELGiAgent project.
//                *** This header file should be the FIRST include file for every
//                source file in the project.   ****
//
//*****************************************************************************

#ifndef __AGENT_CONFIG_H__
#define __AGENT_CONFIG_H__

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef WIN32
#ifndef _CRTDBG_MAP_ALLOC
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#if !defined ASSERT
#define ASSERT(X) _ASSERTE(X)
#endif
#endif
// inhibit tomcrypt warnings.
#define LTC_NO_PROTOTYPES
#endif

// TW-SDK main include
#include "twApi.h"
#include "twConstants.h"

// SSL includes
#ifdef WIN32
#include "twWindows-openssl.h"
#else
#include "twLinux-openssl.h"
#endif

#include <openssl/crypto.h>

// GS OS abstraction layer
#include "GsThread.h"
#include "OS_Utilities.h"

// Often used includes:

// the Gs_log.h file can go here.
#include "GeneralDefines.h"
#include "LoggingMgr.h"
#include "Utilities.h"
#include "SDK_ExtensionUtilities.h"
#include "GeneralStringDefines.h"
#include "ErrorEventMgr.h"

    // system globals
    // The thing identifier is destignated as an identifier by the leading '*'.
    // In the 'C-SDK' this is the 'thing name'.
    extern char *g_pszThingIdentifier; // Defined in: SetServerConfiguration() from reading the server_config.json file.
    extern char *g_pszRegistrationThingName;
    extern char *g_pszRegistrationServiceName;
    extern char *g_pszRemoteThingName;
    extern char *g_pszFabNumber;
    extern char *g_pszImeiNumber;
    extern char *g_pszProcessName; // This is the name of the process
    extern GS_BOOL g_bFabNumberValid;
    extern GS_BOOL g_bRunAsService;
    extern GS_BOOL g_bDaemon;
    extern GS_BOOL g_bFirstTimeBoundComplete;
    extern GS_BOOL g_bFirstTimeCallbacksSetup;
    extern GS_BOOL g_bReceivedShutdownSignal;
    extern GS_BOOL g_bPublishDataDuringFileTransfer;
    extern int g_publishMessageTimeout;
    extern GS_BOOL g_bEnableErrorEvents;
    extern GS_BOOL g_bRestartApplication;
    extern char *g_pszAgentHomeDir;
    extern char *g_pszDataLogsDir;
    extern GS_BOOL g_bDisableWebSocketCompression;
    extern GS_BOOL g_bServerHandshakingInitializationCompleted;

    // This is a helper function - will duplicate an input string and free the previous one if needed.
    int SetAgentHomeDir(char *pszHomeDir);

    // Get absolute path to the file (in optional subfolder) in agent home directory.
    char *GetFilePathInAgentHome(char *pszSubFolderName, char *pszFileName);

    // Initialize Agent Home dir path to new value (ENV or CWD) if not already set.
    GS_BOOL InitializeAgentHomeDir(void);

    int EmptyServiceCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent);

#ifndef min
#define min(a, b) (((a) < (b)) ? (a) : (b))
#endif

#ifndef max
#define max(a, b) (((a) > (b)) ? (a) : (b))
#endif

#ifdef __cplusplus
}
#endif

#endif // __AGENT_CONFIG_H__
