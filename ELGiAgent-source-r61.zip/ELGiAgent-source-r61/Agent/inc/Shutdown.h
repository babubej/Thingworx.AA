/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   :  Shutdown.h
//
//  Subsystem:  ELGiAgent
//
//  Description:  Define the public function to manage the shutdown and cleanup 
//                functionality for all modules.
//
******************************************************************************/

#ifndef __SHUTDOWN_H__
#define __SHUTDOWN_H__

/*Functions declarations*/
void Shutdown();

#endif /* __SHUTDOWN_H__ */
