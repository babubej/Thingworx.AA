/*****************************************************************************
//  Copyright © 1985-2015 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   : services.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Define standard initialize/start/stop functions for the Services module.
//
******************************************************************************/

#ifndef __SERVICES_H__
#define __SERVICES_H__

void RegisterServices();

void Services_Initialize();
int Services_Start();
void Services_Shutdown();

#endif /* __SERVICES_H__ */
