
#ifndef MODBUS_H_
#define MODBUS_H_

#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

#define JBCRC 0xFFFF /**< ModBud initial polynom. */
#define SCISIZE 255

#define Lowbyte(x) (x & 0x00FF)
#define Highbyte(x) (x >> 8)

#define JBERRADD 0x02
#define JBERRDATA 0x03
#define JBSLAVEBUSY 0x06

/* ********** External mapping ModBus (in words) ********** */
#define ADRBLESENSOR 0x124D
#if defined(LEGATO)
char *ModbusRead_SingleDataString(int portCom, int len);
ssize_t ModbusRead(int portCom, int len, int queryNum);
#endif
extern int nCount;
extern char *recdTimer1Data[255];
extern char *recdTimer2Data[255];

#endif // MODBUS
