/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   :  Initialization.h
//
//  Subsystem:  ELGiAgent
//
//  Description:
//
//      - Define public functions to initialize and start the Agent.
//
******************************************************************************/

#ifndef __INITIALIZATION_H__
#define __INITIALIZATION_H__

// Main functions to initialize and start the application.
// return TW_OK if successful.
int PreInitialize();
int Initialize();
int Start();
// For consistency between the Windows and Linux Mutex, override the Linux mutex implementation
// to use a recursive mutex.
void OverrideSDKCreateMutex();

#endif /* ACTIVATION_H_ */
