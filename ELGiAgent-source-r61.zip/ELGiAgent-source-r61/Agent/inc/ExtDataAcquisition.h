/*
 * ExtDataAcquisition.h
 *
 *  Created on: Apr 17, 2020
 *      Author: kalimuthu
 */
#ifndef DATAACQUISITION_H_
#define DATAACQUISITION_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "GeneralDefines.h"
#include "twList.h"
#include "twProperties.h"
#include "ExtSerial.h"
#include "ExtModbus.h"

#define YIELD_INTERVAL_SECOND 30

#define EXT_STR_BUFFER_SIZE 512
#define EXT_STR_SUBVAL_MAX_SIZE 32
#define EXT_STR_VALUE_MAX_SIZE 64
#define EXT_STR_TMP_SIZE 256
#define EXT_STR_LINE_SIZE 2048

extern int g_fdComPort;
extern time_t g_tRtcSyncDiff;

static char *JSONOutFile = "/home/root/ModbusData/JSONOut.txt";
static char *FabNumberCacheFilePath = "/home/root/FabNumber/FabNumber.txt";

static char *gpioExport = "echo 4 >/sys/class/gpio/export"; // Exporting GPIO pin linux command
static char *gpioDirectionset = "echo out >/sys/class/gpio/gpio4/direction";
static char *gpioHigh = "echo 1 >/sys/class/gpio/gpio4/value";
static char *gpioLow = "echo 0 >/sys/class/gpio/gpio4/value";

static char *gpioNeuExport = "echo 31 >/sys/class/gpio/export"; // Exporting GPIO pin linux command
static char *gpioNeuDirectionset = "echo out >/sys/class/gpio/gpio31/direction";
static char *gpioNeuHigh = "echo 1 >/sys/class/gpio/gpio31/value";
static char *gpioNeuLow = "echo 0 >/sys/class/gpio/gpio31/value";

static char *gpioGreenExport = "echo 37 >/sys/class/gpio/export"; // Exporting GPIO pin linux command
static char *gpioGreenDirectionset = "echo out >/sys/class/gpio/gpio37/direction";
static char *gpioGreenHigh = "echo 1 >/sys/class/gpio/gpio37/value";
static char *gpioGreenLow = "echo 0 >/sys/class/gpio/gpio37/value";

static char *gpioRedExport = "echo 32 >/sys/class/gpio/export"; // Exporting GPIO pin linux command
static char *gpioRedDirectionset = "echo out >/sys/class/gpio/gpio32/direction";
static char *gpioRedHigh = "echo 1 >/sys/class/gpio/gpio32/value";
static char *gpioRedLow = "echo 0 >/sys/class/gpio/gpio32/value";

enum TimerNum
{
	Timer1 = 1,
	Timer2 = 2,
	Timer3 = 3,
	Timer4 = 4,
	Timer5 = 5
};

enum FieldType
{
	OneByteHex = 1,
	TwoByteHex = 2,
	FourByteHex = 3,
	EightByteHex = 4,
	SignedInt = 5,
	UnsignedInt = 6,
	SignedLong = 7,
	UnSignedLong = 8,
	Float = 9,
	Double = 10,
	EightWord = 11,
	SixteenWord = 12,
	TwentyFourWord = 13
};

enum ByteOrder
{
	ABCD = 1,
	CDAB = 2,
	BADC = 3,
	DCBA = 4
};

// Structure for key-value pair
struct DataMap
{
	char key[8];
	char value[48];
};
typedef struct DataMap DataMap;

// Structure to store Communication Details
struct ComInfo
{
	char PortName[16];
	int BaudRate;
	int dataBits;
	char Parity[2];
	int stopBits;
};
extern struct ComInfo g_dataComInfo;

// Structure to store Modbus Data bits
struct ModbusDataBits
{
	int queryNum;
	int Position;
	int Type;
	int ByteOrder;
	double Multi_Factor;
	//int itemCount;
};
typedef struct ModbusDataBits ModbusDataBits;

struct ModbusQuery
{
	int queryNum;
	ModbusDataBits *dataBits;
	int numDataBits;
};
typedef struct ModbusQuery ModbusQuery;

// Structure to store Query and Device Addresses
struct DataQuery
{
	int queryNum;
	int queryCount;
	GS_BOOL queryStatus;
	int slaveId;
	int function;
	int startAddress;
	int length;
	int checkSum;
};
typedef struct DataQuery DataQuery;

// Structure to store Frequency, Interval etc
struct ModbusConfig
{
	int frequency;
	int interval;
	//int queryNum;
	ModbusQuery *modbusQueries;
	int numQueries;
};
typedef struct ModbusConfig ModbusConfig;

struct DataArrays
{
	char dataArray[SCISIZE][16];
	int dataCount;
};
typedef struct DataArrays DataArrays;

struct DataAcquisitionConfig
{
	ModbusConfig *modbusConfigs;
	int numConfigs;
	DataMap *timerData;
	int numTimers;
	DataQuery *queries;
	int numQueries;
	DataArrays *rawData;
};
typedef struct DataAcquisitionConfig DataAcquisitionConfig;

extern DataAcquisitionConfig *g_dataConfig;

static char *RTC_SEC_ADDRESS = "0x00";
static char *RTC_MIN_ADDRESS = "0x01";
static char *RTC_HRS_ADDRESS = "0x02";
static char *RTC_DAY_ADDRESS = "0x03";
static char *RTC_DAT_ADDRESS = "0x04";
static char *RTC_MON_ADDRESS = "0x05";
static char *RTC_YER_ADDRESS = "0x06";

struct RTC
{
	int Hour;
	int Min;
	int Sec;
	int Date;
	int Month;
	int Year;
};
struct RTC RTC_DateTime;

/**
 * \brief Extended property definition structure.
*/
typedef struct ExtPropertyDef
{
	/** Standard C SDK property definition */
	twPropertyDef *definition;
	/** Frequency (delay in seconds) to use between updates. */
	int frequency;
	/** Last timestamp when the property was sent to the Platform. */
	DATETIME lastUpdateTs;
	/** Ordering id for the property */
	int index;
} ExtPropertyDef;

extern int g_iMachineDetails_1;
extern int g_iMachineDetails_2;

int RTC_read(char *address);
void RTC_write(char *address, int value);
// Returns RTC Clock DateTime as a STRING
DATETIME Get_RTC_TIME();
void executeGPIOConfig(char *gpioMessage);
// This should be called after establishing network connection.
// Should be called when there is any change in Date Time
// (for instance difference between RTC and Linux Date time is 30 or more).
// This function should be called every one minute.
void RTC_Synchronize();
// Returns Device FAB Number as a STRING
char *ReadFabNumberString();

// Returns Device IMEI Number as a STRING
char *ReadDeviceIDString();

char *computeByteOrder(char *byteorder, char (*strData)[EXT_STR_SUBVAL_MAX_SIZE], int length, char *multiFactor);

void ParseData(char *position, char *type, char *byteorder, int queryNum, char *multi_factor);
void AccumulateData(int freq, int modConfig);
GS_BOOL SendRequest(int SlaveId, int Function, int addr1, int addr2, int Length, int Checksum, int queryNum);

twList *RetrieveExternalPropertyListInfo();

// Returns ModbusData as a STRING in JSON Format
twList *ReadModbusData();

// Reads Modbus configurator and stored the parsed values in dynamically allocated Global Structures
void ExtDataAcquisition_ReadConfiguration();

void ExtDataAcquisition_Initialize();
void ExtDataAcquisition_Start();
void ExtDataAcquisition_Shutdown();

void ExtDataAcquisition_ReadMachineDetailsNumbers();
GS_BOOL ExtDataAcquisition_ValidateFabNumber(char *pszFabNumber);
GS_BOOL ExtDataAcquisition_FetchFabNumber();
void ExtDataAcquisition_FetchIdNumbers();

char *subStrInPlace(char *str, int pos, int n);
char *subStr(char *str, int pos, int n);

#endif // DATAACQUISITION_H_
