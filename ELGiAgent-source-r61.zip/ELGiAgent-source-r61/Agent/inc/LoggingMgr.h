/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   	:  LoggingMgr.h
//
//  Subsystem  	:  ELGiAgent
//
//  Description:  Define the public functions used to initialize/start/stop and 
//                use the Logging Manager
//
//
******************************************************************************/
#ifndef __LOGGING_MGR_H__
#define __LOGGING_MGR_H__

#include "twList.h"

struct cJSON;
typedef struct cJSON cJSON;

// currently, we support these module names:
#define MODULE_TW_SDK "TW_SDK"
#define MODULE_GS_CONFIG "Configuration"
#define MODULE_GS_DATA "DataAcquisition"
#define MODULE_GS_SCM "SoftwareContentManagement"
#define MODULE_GS_RUNTIME "RunTime"

#define GS_LOGGER_BUF_SIZE 0x4000 /* 16KB */

// GsLogLevel is enum. Exactly same as ThingWorx for now
enum GsLogLevel
{
	GS_TRACE = TW_TRACE,
	GS_DEBUG = TW_DEBUG,
	GS_INFO = TW_INFO,
	GS_WARN = TW_WARN,
	GS_ERROR = TW_ERROR,
	GS_FORCE = TW_FORCE,
	GS_AUDIT = TW_AUDIT
};

// Logging target is bit or-ed
#define LOG_TARGET_CONSOLE 0x01 // to console
#define LOG_TARGET_FILE 0x02	// to file
#define LOG_TARGET_SYSLOG 0x04	// to syslog

// A global struct to hold global options
typedef struct GsLogOptions
{
	int m_gLevel;			 // global logging level
	int m_Target;			 // target: file, console, etc.
	char *m_TargetFile;		 // file name
	int m_MaxFileSize;		 // max size file can grow
	int m_MaxFileNumber;	 // max number of files
	TW_MUTEX m_LoggingMutex; // the mutex for logging
	twList *m_ModuleList;	 // list of modules -> moduleOptions
} GsLogOptions;

// A moldule struct to hold per module options
#define GS_LOGGING_MODULE_SIZE 64
typedef struct GsLogModuleOptions
{
	int m_mLevel;							   // Logging level.
	char m_ModuleName[GS_LOGGING_MODULE_SIZE]; // module name
} GsLogModuleOptions;

extern const char *STR_DEFAULT_MODULES_ARRAY[];
extern const int STR_DEFAULT_MODULES_ARRAY_SIZE;

// Initialize and destroy the logging
int GsLog_InitializeDefaults(); // return TW_OK or errors
int GsLog_ConfigureLogging();
void GsLog_Shutdown();

// Gs log function (with more options: moduleID - log source, target - to file, console, etc.)
void GsAppLog(enum GsLogLevel level, char *module, const char *format, ...);

TW_FILE_HANDLE GsLog_OpenLogFileForReading();
char *GsLog_GetLogFilePath();

GsLogModuleOptions *GsLog_LookupModule(const char *module);
enum LogLevel GsLog_StringToLogLevel(const char *level);
const char *GsLog_LogLevelToString(enum LogLevel level);

void GsLog_ChangeLogLevelForString(const char *moduleName, const char *level);
void GsLog_ChangeLogLevel(const char *moduleName, enum LogLevel level);
void GsLog_ChangeLogLevelInJson(cJSON *pJson, const char *moduleName, const char *level);

/* Re-initialize the logging options */
void GsLog_ReInitializeLogOptions();

#endif // __LOGGING_MGR_H__
