//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  DelayedTasksMgr.h
//
//  Subsystem  :  ELGiAgent
//
//*****************************************************************************

#ifndef __DELAYED_TASKS_H__
#define __DELAYED_TASKS_H__

#include "twApi.h"

typedef void (*task_cb)(void *pUserData);

typedef struct DelayedTaskInfo
{
    uint64_t ts;
    int timeout;
    void *pUserData;
    task_cb callback;
    unsigned short ownPointer;
} DelayedTaskInfo;

void DelayedTasks_Initialize();
int DelayedTasks_Start();
void DelayedTasks_Shutdown();
GS_BOOL DelayedTasks_IsActivated();

void DelayedTasks_AddTask(task_cb task, void *pUserData, unsigned short ownPointer);
void DelayedTasks_AddTimeout(task_cb task, void *pUserData, unsigned short ownPointer, int timeout);

#endif // __DELAYED_TASKS_H__
