/*****************************************************************************
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   : properties.h
//
//  Subsystem :  ELGiAgent
//
//  Description:
//                Define the functions realated to processing the static Properties. 
//
******************************************************************************/

#ifndef PROPERTIES_H_
#define PROPERTIES_H_

void RegisterStaticProperties();
void StaticPropertyUpdate();

#endif /* PROPERTIES_H_ */
