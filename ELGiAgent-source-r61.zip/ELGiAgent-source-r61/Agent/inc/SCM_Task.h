//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  SCM_Task.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Define the public functions used to initialize/start/stop, configure
//                and manage the  Software Content Management(SCM) task and software installation
//                functions.
//
//*****************************************************************************

#ifndef __SCM_TASK_H__
#define __SCM_TASK_H__

/* Defeubt the possible actions after a software update is completed. 
   The Values are treated as a bit pattern.
*/

#define SWUPDATE_ACTION_NONE 0x0
#define SWUPDATE_ACTION_RESTART_APP 0x1

// 'public' Functions
void SCM_Task_Initialize();
int SCM_Task_Start();
void SCM_Task_Shutdown();
void SCM_Task_SetScanRate(int iScanRate);
void SCM_Task_SetStagingDir(char *pszStagingDir);
char *SCM_Task_GetStagingDir();
void SCM_Task_SetIdleTimeout(int timeoutSeconds);
int SCM_Task_GetIdleTimeout();

#endif // __SCM_TASK_H__
