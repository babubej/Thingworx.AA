//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  ErrorEventMgr.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Define the public functions used to initialize/start/stop and use the
//                ErrorEventManager to manage the thread to queue and fire ThingWorx Events.
//
//*****************************************************************************

#ifndef __ERROR_EVENT_MGR_H__
#define __ERROR_EVENT_MGR_H__

#include "twApi.h"

// 'public' Functions
void ErrorEventMgr_Initialize();
int ErrorEventMgr_Start();
void ErrorEventMgr_Shutdown();
void ErrorEventMgr_SignalThread();
void ErrorEventMgr_FireEvent(int level, char *pszModuleName, const char *pszMessage);

#endif // __ERROR_EVENT_MGR_H__
