//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  DelayedTasksMgr.c
//
//  Subsystem  :  ELGiAgent
//
//*****************************************************************************

#include "AgentConfig.h"
#include "DelayedTasksMgr.h"

static unsigned int g_Delayed_TaskScanRate = 100; // milliseconds.
static GsThreadStruct *g_pDelayed_TaskThreadStruct = NULL;

static twList *s_pTasksList = NULL;
static TW_MUTEX s_DelayedTask_Mutex;

THREAD_FUNCTION_RETURN DelayedTasks_ThreadFunction(void *pVoid);

void DelayedTasks_Initialize()
{
	s_DelayedTask_Mutex = twMutex_Create();
	s_pTasksList = twList_Create(NULL);
	g_pDelayed_TaskThreadStruct = GsCreateThreadStruct();
	if (g_pDelayed_TaskThreadStruct)
	{
		g_pDelayed_TaskThreadStruct->m_waitMilliSec = g_Delayed_TaskScanRate;
	}
}
//>----------------------------------------------------------------------------

int DelayedTasks_Start()
{
	// start the thread
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "DelayedTasksMgr:  Initiate start of thread");
	GsStartThread(g_pDelayed_TaskThreadStruct, DelayedTasks_ThreadFunction);
	return TW_OK;
}
//>----------------------------------------------------------------------------

void DelayedTasks_Shutdown()
{
	twMutex_Delete(s_DelayedTask_Mutex);
	s_DelayedTask_Mutex = NULL;
	// stop the thread
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "DelayedTasksMgr:  Initiate shutdown");
	GsStopThread(g_pDelayed_TaskThreadStruct);
	GsDestroyThreadStruct(g_pDelayed_TaskThreadStruct);
	g_pDelayed_TaskThreadStruct = NULL;
	twList_Delete(s_pTasksList);
	s_pTasksList = NULL;
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "DelayedTasksMgr:  shutdown complete");
}
//>----------------------------------------------------------------------------

GS_BOOL DelayedTasks_IsActivated()
{
	return (s_pTasksList != NULL && g_pDelayed_TaskThreadStruct != NULL);
}
//>----------------------------------------------------------------------------

void DelayedTasks_AddTask(task_cb task, void *pUserData, unsigned short ownPointer)
{
	DelayedTasks_AddTimeout(task, pUserData, ownPointer, -1);
}
//>----------------------------------------------------------------------------

void DelayedTasks_AddTimeout(task_cb task, void *pUserData, unsigned short ownPointer, int timeout)
{
	if (timeout < 0)
		timeout = -1;
	if (s_pTasksList == NULL)
		return;
	DelayedTaskInfo *pTaskInfo = (DelayedTaskInfo *)TW_MALLOC(sizeof(DelayedTaskInfo));
	pTaskInfo->timeout = timeout;
	pTaskInfo->ts = twGetSystemMillisecondCount();
	pTaskInfo->callback = task;
	pTaskInfo->ownPointer = ownPointer;
	pTaskInfo->pUserData = pUserData;
	if (s_DelayedTask_Mutex != NULL)
		twMutex_Lock(s_DelayedTask_Mutex);
	twList_Add(s_pTasksList, pTaskInfo);
	if (s_DelayedTask_Mutex != NULL)
		twMutex_Unlock(s_DelayedTask_Mutex);
	if (g_pDelayed_TaskThreadStruct != NULL)
		GsSignalThread(g_pDelayed_TaskThreadStruct);
	twSleepMsec(5);
}
//>----------------------------------------------------------------------------

void DelayedTasks_ProcessTasks()
{
	// This will register the properties based on input list
	ListEntry *pItem = s_pTasksList->first;
	DATETIME ts = twGetSystemMillisecondCount();
	while (pItem)
	{
		DelayedTaskInfo *pTaskInfo = (DelayedTaskInfo *)pItem->value;
		if (pTaskInfo != NULL)
		{
			twMutex_Lock(s_DelayedTask_Mutex);
			if (pTaskInfo->timeout < 0 || ts - pTaskInfo->ts > pTaskInfo->timeout)
			{
				//* process task
				if (pTaskInfo->callback)
				{
					GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "DelayedTasksMgr:  Processing task with userData: %p", pTaskInfo->pUserData);
					pTaskInfo->callback(pTaskInfo->pUserData);
				}
				if (pTaskInfo->ownPointer && pTaskInfo->pUserData)
					TW_FREE(pTaskInfo->pUserData);
				memset(pTaskInfo, 0, sizeof(DelayedTaskInfo));
				twList_Remove(s_pTasksList, pItem, TRUE);
				pTaskInfo = NULL;
				pItem = s_pTasksList->first; // restart loop
			}
			twMutex_Unlock(s_DelayedTask_Mutex);
			if (!s_pTasksList->count)
				break; //! skip
			//
			// restart loop
			if (!pTaskInfo)
				continue;
		} //? got task info
		pItem = pItem->next;
	} //# while got items
}
//>----------------------------------------------------------------------------

THREAD_FUNCTION_RETURN DelayedTasks_ThreadFunction(void *pVoid)
{
	int waitReturnCondition = WAIT_OBJECT_0;
	GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid; // The void* parameter is always the thread struct pointer
	if (!pGsThreadStruct)
	{
		GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "DelayedTasksMgr:  Thread initialiation error.  Exiting thread.");
		return (THREAD_FUNCTION_RETURN)-1;
	}
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "DelayedTasksMgr:  Thread started.  Thread id = %x (hex)", pGsThreadStruct->m_threadId);
#if defined(LEGATO)
	le_thread_InitLegatoThreadData("DelayedTasksMgr");
#endif // LEGATO
	// while bRunning, continues to run
	while (pGsThreadStruct->m_bRunning)
	{
		DATETIME wakeupTime = twGetSystemTime(TRUE);
		DATETIME now;
		unsigned long loopTime;

		now = twGetSystemTime(TRUE);
		loopTime = (unsigned long)(now - wakeupTime);
		pGsThreadStruct->m_waitMilliSec = CalculateDelay(pGsThreadStruct, g_Delayed_TaskScanRate, loopTime);

		DelayedTasks_ProcessTasks();

		// Wait for signal or timeout for the next scan.
		waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);
	} //# while thread is running
	// exit
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "DelayedTasksMgr:  extiting thread");
#if defined(LEGATO)
	le_thread_CleanupLegatoThreadData();
#endif // LEGATO
	return 0;
}
//>----------------------------------------------------------------------------
