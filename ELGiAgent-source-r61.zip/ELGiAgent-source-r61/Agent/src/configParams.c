/*****************************************************************************
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   : configParams.c
//
//  Subsystem :  ELGiAgent
//
//  Description:
//
//      Reads values from JSON files and sets the parameters of SDK, 
//      network connection, logging, offline message store, file transfer & server configuration.
//      Also reads ELGiAgent 'module' configurations.
//
******************************************************************************/
#include "AgentConfig.h"
#include "cJSON.h"
#include "twFileManager.h"
#include "configParams.h"
#include "stringUtils.h"
#include "API_Task.h"
#include "MessageThreadPoolMgr.h"
#include "DataPublishingMgr.h"
#include "ExtDataAcquisition.h"
#include "SCM_Task.h"

static void SetNetworkConnectionConfiguration();
static void SetOfflineConfiguration();
static void SetFileTransferConfiguration();
static int SetServerConfiguration();
static void MessageThreadPool_ReadConfig(cJSON *pJSONContent);
static void System_ReadConfig(cJSON *pJSONContent);
static void Publish_ReadConfig(cJSON *pJSONContent);
static void SCM_ReadConfig(cJSON *pJSONContent);

// static variables accessible through getter functions
static char *g_pszHostName = NULL;
static int g_twServerPort = -1;
static char *g_pszAppKey = NULL;
static char *g_pszPemFilename = NULL;
static GS_BOOL g_bFIPSmodeEnabled = FALSE;

//*****************************************************************************
void ConfigCleanUp()
{
	TW_FREE(g_pszHostName);
	g_pszHostName = NULL;

	TW_FREE(g_pszAppKey);
	g_pszAppKey = NULL;

	TW_FREE(g_pszPemFilename);
	g_pszPemFilename = NULL;

	TW_FREE(twcfg.file_xfer_staging_dir);
	TW_FREE((char *)twcfg.offline_msg_store_dir);

	if (g_pszThingIdentifier)
	{
		TW_FREE(g_pszThingIdentifier);
		g_pszThingIdentifier = NULL;
	}
	if (g_pszRegistrationThingName)
	{
		TW_FREE(g_pszRegistrationThingName);
		g_pszRegistrationThingName = NULL;
	}
	if (g_pszRegistrationServiceName)
	{
		TW_FREE(g_pszRegistrationServiceName);
		g_pszRegistrationServiceName = NULL;
	}
	if (g_pszRemoteThingName)
	{
		TW_FREE(g_pszRemoteThingName);
		g_pszRemoteThingName = NULL;
	}
	if (g_pszImeiNumber)
	{
		TW_FREE(g_pszImeiNumber);
		g_pszImeiNumber = NULL;
	}
	if (g_pszFabNumber)
	{
		TW_FREE(g_pszFabNumber);
		g_pszFabNumber = NULL;
	}

	TW_FREE(g_pszAgentHomeDir);
	g_pszAgentHomeDir = NULL;

	TW_FREE(g_pszDataLogsDir);
	g_pszDataLogsDir = NULL;
} //> ConfigCleanUp()

//*****************************************************************************
//
// configure the various SDK and twcfg settings from various json config files.
//
int ConfigSdkSettings()
{
	int errRet = TW_OK;
	//
	// The twcfg struct is defined and initialized in the SDK.  See twApi.c twConfig twcfg =  {
	//
	// This struct has three char* fields which we need to take care of related to memory
	// const char * tw_uri;						// For now, we do not overwrite this
	// char * file_xfer_staging_dir;			// we overwrite this and need to free memory
	// const char * offline_msg_store_dir;		// we overwrite this and need to free memory
	//
	if (twcfg.file_xfer_staging_dir)
		twcfg.file_xfer_staging_dir = GsStringDup(twcfg.file_xfer_staging_dir);

	if (twcfg.offline_msg_store_dir)
		twcfg.offline_msg_store_dir = GsStringDup((char *)twcfg.offline_msg_store_dir);

	errRet = SetServerConfiguration();
	if (errRet != TW_OK)
		return errRet;
	SetNetworkConnectionConfiguration();
	SetOfflineConfiguration();
	SetFileTransferConfiguration();

	return errRet;
} //> ConfigSdkSettings()

//*****************************************************************************
// Read the server config file to set the following:
//  - ThingWorx Server hostname (URL)
//  - ThingWorx Server port #
//  - ThingWorx Server  app key
//  - ThingWorx Thing identifier.
// Note:  The server configuration settings are required by the application.  At this time they are read from a text file,
//        but ideally they are NOT read from a plain-text file.
//
/*  example file:
{
	"server_config": {
		"version": 1,
		"host_name": "pp-20160930202852108.portal.ptc.io",
		"port": 443,
		"app_key": "93520ef1-8b1d-41dc-b899-54c00b8c6525",
		"thing_identifier": "PTC_EMS_002",
		"security" : {
		   "use_pem_file": 1,
		   "pem_file_name": "",
		   "enable_FIPS_mode": 1
		}	
	}

*/

int RefreshModbusConfigurationFile(char *pszConfigContent)
{
	char *pszConfigFilePath = GetFilePathInAgentHome(MODBUS_CONFIG_FOLDER_NAME, STR_MODBUS_CONFIG_FILENAME);
	int status = GsWriteFileContent(pszConfigFilePath, pszConfigContent);
	TW_FREE(pszConfigFilePath);
	return status;
} //> RefreshModbusConfigurationFile(...)

int RefreshTagParserConfigurationFile(char *pszConfigContent)
{
	char *pszConfigFilePath = GetFilePathInAgentHome(MODBUS_CONFIG_FOLDER_NAME, STR_TAG_PARSER_CONFIG_FILENAME);
	int status = GsWriteFileContent(pszConfigFilePath, pszConfigContent);
	TW_FREE(pszConfigFilePath);
	return status;
} //> RefreshTagParserConfigurationFile(...)

void ParseRegisterServiceOutput(cJSON *pJsonResult)
{
	GS_BOOL isIgnoreData = FALSE;
	cJSON *pJsonTemp = NULL;
	pJsonTemp = cJSON_GetObjectItem(pJsonResult, STR_THING_IDENTIFIER);
	if (pJsonTemp != NULL)
	{
		SetThingIdentifier(pJsonTemp->valuestring);
		GsAppLog(GS_INFO, MODULE_GS_RUNTIME,
				 "InvokeService '%s' synchronously. Return identifier = '%s'.",
				 g_pszRegistrationServiceName, g_pszThingIdentifier);
		// overwrite
		RefreshServerConfigurationFile();
	} //# Remote Thing Identifier
	else
	{
		GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Unable to retrieve Remote Thing Identifier from Registration Response JSON.");
	}

	pJsonTemp = cJSON_GetObjectItem(pJsonResult, STR_THING_NAME);
	if (pJsonTemp != NULL)
	{
		SetRemoteThingName(pJsonTemp->valuestring);
		GsAppLog(GS_INFO, MODULE_GS_RUNTIME,
				 "First time registration pre-created '%s' Thing on the Platform.",
				 g_pszRemoteThingName);
	} //# Remote Thing Name
	else
	{
		GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Unable to retrieve Remote Thing Name from Registration Response JSON.");
	}

	pJsonTemp = cJSON_GetObjectItem(pJsonResult, STR_IGNORE_DATA);
	if (pJsonTemp != NULL)
	{
		isIgnoreData = (GS_BOOL)pJsonTemp->valueint;
	}

	if (isIgnoreData)
	{
		// no need to refresh the configuration files
		// result data is not available anyway
		return; //! skip the rest
	}

	pJsonTemp = cJSON_GetObjectItem(pJsonResult, STR_MODBUS_CONFIG);
	if (pJsonTemp != NULL)
	{
		// Open & overwrite fully the target file with new content
		// (possibly create backup ?)
		// +update only if length > 0
		if (strlen(pJsonTemp->valuestring) > 0)
			RefreshModbusConfigurationFile(pJsonTemp->valuestring);
	} //# Modbus Configuration File
	else
	{
		GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Unable to retrieve Modbus Configuration from Registration Response JSON.");
	}

	pJsonTemp = cJSON_GetObjectItem(pJsonResult, STR_TAG_PARSER);
	if (pJsonTemp != NULL)
	{
		char *stringified = cJSON_Print(pJsonTemp);
		RefreshTagParserConfigurationFile(stringified);
		TW_FREE(stringified);
	} //# Tag Parser Configuration File
	else
	{
		GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Unable to retrieve Tag Parser from Registration Response JSON.");
	}
} //> ParseRegisterServiceOutput(...)

int RefreshServerConfigurationFile()
{
	cJSON *pJSONContent = NULL;
	cJSON *pJSONServerConfig = NULL;
	cJSON *pTempJsonObj = NULL;
	int status = GS_OK;
	/* Read the server file */
	char *pszConfigFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, STR_JSON_FILE_SERVER_CONFIG);
	char *pszConfigContent = GsReadFileContent(pszConfigFilePath);
	if (!pszConfigContent)
	{
		TW_FREE(pszConfigFilePath);
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s must exist to configure communication to the ThingWorx server.", pszConfigFilePath);
		return GS_FAILED;
	}
	pJSONContent = cJSON_Parse(pszConfigContent);
	pJSONServerConfig = cJSON_GetObjectItem(pJSONContent, STR_SERVER_CONFIG);
	if (!pJSONServerConfig)
	{
		TW_FREE(pszConfigFilePath);
		TW_FREE(pszConfigContent);
		return GS_FAILED;
	}
	// Refresh Thing Identifier
	if (g_pszThingIdentifier)
	{
		pTempJsonObj = cJSON_GetObjectItem(pJSONServerConfig, STR_THING_IDENTIFIER);
		if (!pTempJsonObj)
			cJSON_AddItemToObject(pJSONServerConfig, STR_THING_IDENTIFIER, cJSON_CreateString(g_pszThingIdentifier));
		else
			cJSON_ReplaceItemInObject(pJSONServerConfig, STR_THING_IDENTIFIER, cJSON_CreateString(g_pszThingIdentifier));
	}
	// New Fab Number
	if (g_pszFabNumber)
	{
		pTempJsonObj = cJSON_GetObjectItem(pJSONServerConfig, STR_FAB_NUMBER);
		if (!pTempJsonObj)
			cJSON_AddItemToObject(pJSONServerConfig, STR_FAB_NUMBER, cJSON_CreateString(g_pszFabNumber));
		else
			cJSON_ReplaceItemInObject(pJSONServerConfig, STR_FAB_NUMBER, cJSON_CreateString(g_pszFabNumber));
	}
	// New Imei Number
	if (g_pszImeiNumber)
	{
		pTempJsonObj = cJSON_GetObjectItem(pJSONServerConfig, STR_IMEI_NUMBER);
		if (!pTempJsonObj)
			cJSON_AddItemToObject(pJSONServerConfig, STR_IMEI_NUMBER, cJSON_CreateString(g_pszImeiNumber));
		else
			cJSON_ReplaceItemInObject(pJSONServerConfig, STR_IMEI_NUMBER, cJSON_CreateString(g_pszImeiNumber));
	}
	TW_FREE(pszConfigContent);
	pszConfigContent = cJSON_Print(pJSONContent);
	status = GsWriteFileContent(pszConfigFilePath, pszConfigContent);
	// clean up memory.
	TW_FREE(pszConfigFilePath);
	TW_FREE(pszConfigContent);
	cJSON_Delete(pJSONContent);
	return status;
} // RefreshServerConfigurationFile()

int SetServerConfiguration()
{
	cJSON *pJSONContent = NULL;
	cJSON *pJSONServerConfig = NULL;
	cJSON *pJSONSecurity = NULL;
	cJSON *pTempJsonObj = NULL;

	/* Read the server file */
	char *pszConfigFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, STR_JSON_FILE_SERVER_CONFIG);
	char *pszGenericConfigContent = GsReadFileContent(pszConfigFilePath);
	if (!pszGenericConfigContent)
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s must exist to configure communication to the ThingWorx server.", pszConfigFilePath);
		return GS_FAILED;
	}
	pJSONContent = cJSON_Parse(pszGenericConfigContent);
	if (!pJSONContent)
		goto SetServerConfiguration_ErrorExit;

	// Read the configuration file version
	pTempJsonObj = GsVerifyJSONContent(pJSONContent, STR_VERSION);
	if (!pTempJsonObj || pTempJsonObj->valueint != CURRENT_CONFIG_FILE_VERSION)
		goto SetServerConfiguration_ErrorExit;

	//* SERVER CONFIG OBJ
	pJSONServerConfig = GsVerifyJSONContent(pJSONContent, STR_SERVER_CONFIG);
	if (!pJSONServerConfig)
		goto SetServerConfiguration_ErrorExit;

	//* HOST NAME (URL)
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_HOST_NAME);
	if (!pTempJsonObj)
		goto SetServerConfiguration_ErrorExit;
	g_pszHostName = GsStringDup(pTempJsonObj->valuestring);

	//* HOST PORT
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_PORT);
	if (!pTempJsonObj)
		goto SetServerConfiguration_ErrorExit;
	g_twServerPort = pTempJsonObj->valueint;

	//* APP KEY
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_APP_KEY);
	if (!pTempJsonObj)
		goto SetServerConfiguration_ErrorExit;
	g_pszAppKey = GsStringDup(pTempJsonObj->valuestring);

	//* THING IDENTIFIER
	// By pre-pending a '*' this becomes a C-SDK 'ThingName' which is actually a ThingIdentifier.
	// The  Server needs to map the ThingIdentifier to the ThingName (an alias) used at the Server.
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_THING_IDENTIFIER);
	if (pTempJsonObj != NULL && pTempJsonObj->valuestring && pTempJsonObj->valuestring[0] != 0)
	{
		// Define global ThingIdentifier (i.e. called a ThingName in SDK) which used through the code.
		SetThingIdentifier(pTempJsonObj->valuestring);
	}
	else
	{
		if (g_pszThingIdentifier)
		{
			TW_FREE(g_pszThingIdentifier);
			g_pszThingIdentifier = NULL;
		}
		GsAppLog(GS_INFO, MODULE_GS_CONFIG, "Thing Identifier is missing from the configuration - it will be set upon first remote registration.");
	}

	//* REGISTRATION THING NAME
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_REGISTRATION_THING_NAME);
	if (!pTempJsonObj)
		goto SetServerConfiguration_ErrorExit;
	if (pTempJsonObj->valuestring && pTempJsonObj->valuestring[0] != 0)
	{
		// Define global ThingIdentifier (i.e. called a ThingName in SDK) which used through the code.
		SetRegistrationThingName(pTempJsonObj->valuestring);
	}
	else
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "The %s value in file %s must have a value.  It is the source for the Registration Thing Name.",
				 STR_REGISTRATION_THING_NAME, pszConfigFilePath);
		goto SetServerConfiguration_ErrorExit;
	}

	//* REGISTRATION SERVICE NAME
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_REGISTRATION_SERVICE_NAME);
	if (pTempJsonObj != NULL && pTempJsonObj->valuestring && pTempJsonObj->valuestring[0] != 0)
	{
		SetRegistrationServiceName(pTempJsonObj->valuestring);
	}
	else
	{
		SetRegistrationServiceName(STR_REGISTER_SERVICE_DEFAULT); // default
	}
	//* FAB NUMBER
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_FAB_NUMBER);
	if (pTempJsonObj != NULL && pTempJsonObj->valuestring && pTempJsonObj->valuestring[0] != 0)
	{
		// Define global Fab Number which is used through the code.
		SetFabNumber(pTempJsonObj->valuestring);
	}
	else
	{
		if (g_pszFabNumber)
		{
			TW_FREE(g_pszFabNumber);
			g_pszFabNumber = NULL;
		}
		GsAppLog(GS_INFO, MODULE_GS_CONFIG, "Fab Number is missing from the configuration - it will be set upon first run.");
	}

	//* IMEI NUMBER
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_IMEI_NUMBER);
	if (pTempJsonObj != NULL && pTempJsonObj->valuestring && pTempJsonObj->valuestring[0] != 0)
	{
		// Define global Imei Number which is used through the code.
		SetImeiNumber(pTempJsonObj->valuestring);
	}
	else
	{
		if (g_pszImeiNumber)
		{
			TW_FREE(g_pszImeiNumber);
			g_pszImeiNumber = NULL;
		}
		GsAppLog(GS_INFO, MODULE_GS_CONFIG, "Imei Number is missing from the configuration - it will be set upon first run.");
	}

	//* CUSTOM MACHINE DETAILS 1 (optional / no fail)
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_MACHINE_DETAILS_1);
	if (pTempJsonObj != NULL && pTempJsonObj->type == cJSON_Number)
	{
		g_iMachineDetails_1 = pTempJsonObj->valueint;
	}

	//* CUSTOM MACHINE DETAILS 2 (optional / no fail)
	pTempJsonObj = GsVerifyJSONContent(pJSONServerConfig, STR_MACHINE_DETAILS_2);
	if (pTempJsonObj != NULL && pTempJsonObj->type == cJSON_Number)
	{
		g_iMachineDetails_2 = pTempJsonObj->valueint;
	}

	// read security object.
	pJSONSecurity = GsVerifyJSONContent(pJSONServerConfig, STR_SECURITY);
	if (!pJSONSecurity)
		goto SetServerConfiguration_ErrorExit;

	// Read pem file name used with certificates.
	pTempJsonObj = GsVerifyJSONContent(pJSONSecurity, STR_USE_PEM_FILE);
	if (!pTempJsonObj)
		goto SetServerConfiguration_ErrorExit;

	// If pem file is to be used, then read the name of the pem file.
	// If the pem file name is NULL or empty, then pem files are not use\
	// and use of CA certificates are disabled.
	if (pTempJsonObj->valueint)
	{
		pTempJsonObj = GsVerifyJSONContent(pJSONSecurity, STR_PEM_FILE_NAME);
		if (!pTempJsonObj)
			goto SetServerConfiguration_ErrorExit;
		if (pTempJsonObj->valuestring == NULL || pTempJsonObj->valuestring[0] == 0)
		{
			GsAppLog(GS_WARN, MODULE_GS_CONFIG, "The definition of %s in file %s is empty. The use of certificates is disabled!",
					 STR_PEM_FILE_NAME, pszConfigFilePath);
		}
		else
		{
			// Use CA certificates in communications.
			g_pszPemFilename = GsStringDup(pTempJsonObj->valuestring);
		}
	}

	// Read if FIPS mode is enable.
	pTempJsonObj = GsVerifyJSONContent(pJSONSecurity, STR_ENABLE_FIPS_MODE);
	if (!pTempJsonObj)
		goto SetServerConfiguration_ErrorExit;
	g_bFIPSmodeEnabled = (pTempJsonObj->valueint) ? TRUE : FALSE;

	// clean up memory.
	TW_FREE(pszConfigFilePath);
	TW_FREE(pszGenericConfigContent);
	cJSON_Delete(pJSONContent);

	return GS_OK;

SetServerConfiguration_ErrorExit:
	GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Error reading file %s.  Exiting application.", pszConfigFilePath);
	// clean up memory.
	TW_FREE(pszConfigFilePath);
	TW_FREE(pszGenericConfigContent);
	cJSON_Delete(pJSONContent);
	return GS_FAILED;
} //> SetServerConfiguration()

//*****************************************************************************
// return the pointer to the static host name.
char *GetThingWorxHostName()
{
	return g_pszHostName;
}

//*****************************************************************************
int GetThingWorxPort()
{
	return g_twServerPort;
}

//*****************************************************************************
void GetAppKeyCallback(char *appKeyBuffer, unsigned int maxLength)
{
	strncpy(appKeyBuffer, g_pszAppKey, maxLength);
}

//*****************************************************************************
// Get .pem file naem.  Will be NULL if not used.
char *GetPemFileName()
{
	return g_pszPemFilename;
}

//*****************************************************************************
GS_BOOL IsFIPSmodeEnabled()
{
	return g_bFIPSmodeEnabled;
}

void SetStringValueHelper(char **pszTarget, char *pszInput)
{
	if (!pszTarget)
		return;
	const unsigned int length = strlen(pszInput);
	char *pszThingTemp = (char *)TW_MALLOC(length + 1);
	memset(pszThingTemp, 0, length + 1);
	strncpy(pszThingTemp, pszInput, length);
	if (*pszTarget)
	{
		TW_FREE(*pszTarget);
		*pszTarget = NULL;
	}
	*pszTarget = pszThingTemp;
} //> SetRemoteThingName(...)

//*****************************************************************************
// Sets the global pointer to the static system identifier: g_pszThingIdentifier
// This is used as the Thing identifier which needs to be mapped to
// the user-friendly Thing Name at the Thingworx Server
void SetThingIdentifier(char *pszIdentifierRoot)
{
	unsigned int length = strlen(pszIdentifierRoot);
	char *pszStringTemp = (char *)TW_MALLOC(length + 2);
	memset(pszStringTemp, 0, length + 2);
	// The key to a global thing name using the identifier is to preface with a '*'
	// By pre-pending a '*' this becomes a C-SDK 'ThingName' which is actually a ThingIdentifier.
	// The  Server needs to map the ThingIdentifier to the ThingName (an alias) used at the Server.
	if (!length || (length > 0 && pszIdentifierRoot[0] != '*'))
		strcpy(pszStringTemp, "*");
	strcat(pszStringTemp, pszIdentifierRoot);
	SetStringValueHelper(&g_pszThingIdentifier, pszStringTemp);
	TW_FREE(pszStringTemp);
} //> SetThingIdentifier(...)

void SetRegistrationThingName(char *pszRegistrationThing)
{
	/*const unsigned int length = strlen(pszInput);
	char *pszStringTemp = (char *)TW_MALLOC(length + 1);
	memset(pszStringTemp, 0, length + 1);
	strncpy(pszStringTemp, pszInput, length);
	if (g_pszRegistrationThingName)
	{
		TW_FREE(g_pszRegistrationThingName);
		g_pszRegistrationThingName = NULL;
	}*/
	SetStringValueHelper(&g_pszRegistrationThingName, pszRegistrationThing);
} //> SetRegistrationThingName(...)

void SetRegistrationServiceName(char *pszServiceName)
{
	SetStringValueHelper(&g_pszRegistrationServiceName, pszServiceName);
} //> SetRegistrationServiceName(...)

void SetRemoteThingName(char *pszRemoteName)
{
	/*const unsigned int length = strlen(pszInput);
	char *pszThingTemp = (char *)TW_MALLOC(length + 1);
	memset(pszThingTemp, 0, length + 1);
	strncpy(pszThingTemp, pszInput, length);
	if (g_pszRemoteThingName)
	{
		TW_FREE(g_pszRemoteThingName);
		g_pszRemoteThingName = NULL;
	}*/
	SetStringValueHelper(&g_pszRemoteThingName, pszRemoteName);
} //> SetRemoteThingName(...)

void SetFabNumber(char *pszInput)
{
	/*const unsigned int length = strlen(pszInput);
	char *pszStringTemp = (char *)TW_MALLOC(length + 1);
	memset(pszStringTemp, 0, length + 1);
	strncpy(pszStringTemp, pszInput, length);
	if (g_pszFabNumber)
	{
		TW_FREE(g_pszFabNumber);
		g_pszFabNumber = NULL;
	}*/
	SetStringValueHelper(&g_pszFabNumber, pszInput);
} //> SetFabNumber(...)

void SetImeiNumber(char *pszInput)
{
	/*const unsigned int length = strlen(pszInput);
	char *pszStringTemp = (char *)TW_MALLOC(length + 1);
	memset(pszStringTemp, 0, length + 1);
	strncpy(pszStringTemp, pszInput, length);
	if (g_pszImeiNumber)
	{
		TW_FREE(g_pszImeiNumber);
		g_pszImeiNumber = NULL;
	}*/
	SetStringValueHelper(&g_pszImeiNumber, pszInput);
} //> SetImeiNumber(...)

//*****************************************************************************
//    ***************   Support   Functions   *********************
//*****************************************************************************

//*****************************************************************************
/*
* Fetches the value from WS_connection.json & sets the values of network parameters
*/
void SetNetworkConnectionConfiguration()
{
	cJSON *pJSONContent = NULL;
	cJSON *pJSONSubContent = NULL;
	GS_BOOL bJSONValid = FALSE;
	/* Read the server file */
	char *pszConfigFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, STR_JSON_FILE_WS_CONNECTION);
	char *pszGenericConfigContent = GsReadFileContent(pszConfigFilePath);
	TW_FREE(pszConfigFilePath);
	// Check version
	if (pszGenericConfigContent)
	{
		pJSONContent = cJSON_Parse(pszGenericConfigContent);
		TW_FREE(pszGenericConfigContent);
		if (pJSONContent)
		{
			/* Read the configuration file version */
			cJSON *pVersion = cJSON_GetObjectItem(pJSONContent, STR_VERSION);
			if (pVersion && pVersion->valueint == CURRENT_CONFIG_FILE_VERSION)
				bJSONValid = TRUE;
			else
				GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s must have a %s of %i", STR_JSON_FILE_WS_CONNECTION, STR_VERSION, CURRENT_CONFIG_FILE_VERSION);
		}
	}
	// post error if json not valid
	if (bJSONValid == FALSE)
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s is invalid, correct the information and restart Agent", STR_JSON_FILE_WS_CONNECTION);
	}
	else
	{
		cJSON *pJSONTemp = NULL;
		pJSONSubContent = cJSON_GetObjectItem(pJSONContent, STR_WS_CONNECTION);
		if (pJSONSubContent)
		{
			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_CONNECTION_TIMEOUT);
			if (pJSONTemp)
				twcfg.connect_timeout = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_DUTY_CYCLE);
			if (pJSONTemp)
				twcfg.duty_cycle = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_PING_RATE);
			if (pJSONTemp)
				twcfg.ping_rate = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_PINGPONG_TO);
			if (pJSONTemp)
				twcfg.pong_timeout = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_MAX_MSG_SIZE);
			if (pJSONTemp)
				twcfg.max_message_size = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_MSG_CHUNK_SIZE);
			if (pJSONTemp)
				twcfg.message_chunk_size = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_CONNECT_RETRY_INTERVAL);
			if (pJSONTemp)
				twcfg.connect_retry_interval = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_MAX_MESSAGES);
			if (pJSONTemp)
				twcfg.max_messages = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_MAX_CONNECT_DELAY);
			if (pJSONTemp)
				twcfg.max_connect_delay = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_VERBOSE);
			if (pJSONTemp)
				twLogger_SetIsVerbose(pJSONTemp->type);

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_FRAME_READ_TIMEOUT);
			if (pJSONTemp)
				twcfg.frame_read_timeout = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_DEFAULT_MESSAGE_TIMEOUT);
			if (pJSONTemp)
				twcfg.default_message_timeout = pJSONTemp->valueint;

			/* Disable compression while communicating to TW platform */
			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_DISABLE_WEB_SOCKET_COMPRESSION);
			if (pJSONTemp)
				g_bDisableWebSocketCompression = (GS_BOOL)pJSONTemp->valueint;

			// For optimization of throughput effeciency, change SDK default read timeout to a configurable value & default to 10 ms.
			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_SOCKET_READ_TIMEOUT);
			twcfg.socket_read_timeout = (pJSONTemp) ? pJSONTemp->valueint : 10;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_ENABLE_TLS_HOSTNAME_VALIDATION);
			twcfg.enable_tls_hostname_validation = (pJSONTemp) ? (GS_BOOL)pJSONTemp->valueint : FALSE;
#ifdef ENABLE_CERT
			GsAppLog(GS_DEBUG, MODULE_GS_CONFIG, "Enabling of TLS hostname validation of CN field in server certificate validation is set to %s",
					 (twcfg.enable_tls_hostname_validation) ? "true" : "false");
#endif
		}
	}
	cJSON_Delete(pJSONContent);
} //> SetNetworkConnectionConfiguration()

//*****************************************************************************
/*
* Fetches the value from offline_msg_store.json & sets the values of offline parameters
* */
void SetOfflineConfiguration()
{
	cJSON *pJSONContent = NULL;
	cJSON *pJSONSubContent = NULL;
	GS_BOOL bJSONValid = FALSE;

	/* Read the server file */
	char *pszConfigFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, STR_JSON_FILE_OFFLINE_MSG);
	char *pszGenericConfigContent = GsReadFileContent(pszConfigFilePath);
	TW_FREE(pszConfigFilePath);

	// Check version
	if (pszGenericConfigContent)
	{
		pJSONContent = cJSON_Parse(pszGenericConfigContent);
		TW_FREE(pszGenericConfigContent);
		if (pJSONContent)
		{
			/*Read the configuration file version */
			cJSON *pVersion = cJSON_GetObjectItem(pJSONContent, STR_VERSION);
			if (pVersion && pVersion->valueint == CURRENT_CONFIG_FILE_VERSION)
				bJSONValid = TRUE;
			else
				GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s must have a %s of %i", STR_JSON_FILE_OFFLINE_MSG, STR_VERSION, CURRENT_CONFIG_FILE_VERSION);
		}
	}
	// post error if json not valid
	if (bJSONValid == FALSE)
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s is invalid, correct the information and restart Agent", STR_JSON_FILE_OFFLINE_MSG);
	}
	else
	{
		cJSON *pJSONTemp = NULL;
		pJSONSubContent = cJSON_GetObjectItem(pJSONContent, STR_OFFLINE_MSG_STORAGE);
		if (pJSONSubContent)
		{
			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_MAX_SIZE);
			if (pJSONTemp)
				twcfg.offline_msg_queue_size = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_DIRECTORY);
			if (pJSONTemp)
			{
				TW_FREE((char *)twcfg.offline_msg_store_dir); // free initialized value.
				twcfg.offline_msg_store_dir = GsCreateRelOrAbsDir(pJSONTemp->valuestring, g_pszAgentHomeDir);
			}
		}
	}
	cJSON_Delete(pJSONContent);
} //> SetOfflineConfiguration()

//*****************************************************************************
/*
* Fetches the value from filetransfer.json & sets the value of filetransfer parameters
* */
void SetFileTransferConfiguration()
{
	cJSON *pJSONContent = NULL;
	cJSON *pJSONSubContent = NULL;
	GS_BOOL bJSONValid = FALSE;
	char *pszVirDirName = NULL;
	char *pszVirDirPath = NULL;
	char *pszPath = NULL;

	/* Read the file transfer file  which defines virtual directories */
	char *pszConfigFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, STR_JSON_FILE_FILE_TRANSFER);
	char *pszGenericConfigContent = GsReadFileContent(pszConfigFilePath);
	TW_FREE(pszConfigFilePath);
	// Check version
	if (pszGenericConfigContent)
	{
		pJSONContent = cJSON_Parse(pszGenericConfigContent);
		TW_FREE(pszGenericConfigContent);
		if (pJSONContent)
		{
			/*Read the configuration file version */
			cJSON *pVersion = cJSON_GetObjectItem(pJSONContent, STR_VERSION);
			if (pVersion && pVersion->valueint == CURRENT_CONFIG_FILE_VERSION)
				bJSONValid = TRUE;
			else
				GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s must have a %s of %i", STR_JSON_FILE_FILE_TRANSFER, STR_VERSION, CURRENT_CONFIG_FILE_VERSION);
		}
	}
	// post error if json not valid
	if (bJSONValid == FALSE)
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s is invalid, correct the information and restart Agent", STR_JSON_FILE_FILE_TRANSFER);
	}
	else
	{
		cJSON *pVirtualDirArray = NULL;
		int iVirtualDirSize = 0;
		cJSON *pJSONTemp = NULL;
		int i;
		pJSONSubContent = cJSON_GetObjectItem(pJSONContent, STR_FILE);
		if (pJSONSubContent)
		{
			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_BUFFER_SIZE);
			if (pJSONTemp)
				twcfg.file_xfer_block_size = pJSONTemp->valueint;

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_FILE_TRANSFER_TIMEOUT);
			if (pJSONTemp)
				twcfg.file_xfer_timeout = pJSONTemp->valueint;
			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_MAX_FILE_SIZE);
			if (pJSONTemp)
			{
				// convert double in MG to int64 in Bytes
				double dBytes = pJSONTemp->valuedouble * 1024 * 1024;
				twcfg.file_xfer_max_file_size = (uint64_t)dBytes;
			}
			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_STAGING_DIR);
			if (pJSONTemp)
			{
				TW_FREE((char *)twcfg.file_xfer_staging_dir);
				twcfg.file_xfer_staging_dir = GsCreateRelOrAbsDir(pJSONTemp->valuestring, g_pszAgentHomeDir);
			}
			// Initialize the TW SDK file manager.
			twFileManager_Create();
			/*Setting the File transfer  parameters to the twcfg structure.*/
			pVirtualDirArray = cJSON_GetObjectItem(pJSONSubContent, STR_VIRTUAL_DIR);
			if (pVirtualDirArray)
			{
				iVirtualDirSize = cJSON_GetArraySize(pVirtualDirArray);
				for (i = 0; i < iVirtualDirSize; i++)
				{
					cJSON *pVirtualDir = cJSON_GetArrayItem(pVirtualDirArray, i);
					pszVirDirName = pVirtualDir->child->string;
					pszVirDirPath = pVirtualDir->child->valuestring;
					if (pszVirDirName != NULL && strcmp(pszVirDirName, "") != 0 && pszVirDirPath != NULL && strcmp(pszVirDirPath, "") != 0)
					{
						// Virtual directories are local to agent home directory.
						pszPath = GsCreateRelOrAbsDir(pszVirDirPath, g_pszAgentHomeDir);
						twFileManager_AddVirtualDir(g_pszThingIdentifier, pszVirDirName, pszPath);
						TW_FREE(pszPath);
					}
				}
			}
		}
	}
	cJSON_Delete(pJSONContent);
} //> SetFileTransferConfiguration()

// *****************************************************************************
// Read configuration files.
// NOTE:  This is done as part of Activation - initialize, but before all other modules
// are initialized.
// Agent initialization is done here centrally and the results distrubuted to the modules;
// note:  the modules donot  read their own configuration files (with the exception of properties.json).
void ReadGenericConfigFiles()
{
	cJSON *pJSONContent = NULL;
	cJSON *pJSONSubContent = NULL;
	GS_BOOL bJSONValid = FALSE;

	/* Read the Agent configuration  file */
	char *pszConfigFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, STR_JSON_FILE_AGENT_CONFIG);
	char *pszGenericConfigContent = GsReadFileContent(pszConfigFilePath);
	TW_FREE(pszConfigFilePath);

	// Check version
	if (pszGenericConfigContent)
	{
		pJSONContent = cJSON_Parse(pszGenericConfigContent);
		TW_FREE(pszGenericConfigContent);

		if (pJSONContent)
		{
			/*Read the configuration file version */
			cJSON *pVersion = cJSON_GetObjectItem(pJSONContent, STR_VERSION);
			if (pVersion && pVersion->valueint == CURRENT_CONFIG_FILE_VERSION)
				bJSONValid = TRUE;
			else
				GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s must have a %s of %i", STR_JSON_FILE_AGENT_CONFIG, STR_VERSION, CURRENT_CONFIG_FILE_VERSION);
		}
	}
	// post error if json not valid
	if (bJSONValid == FALSE)
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s is invalid, correct the information and restart Agent", STR_JSON_FILE_AGENT_CONFIG);
	}
	// process the json file only if Version is correct
	else
	{
		cJSON *pJSONTemp = NULL;
		// api_tasker
		/* example config
	        "api_tasker": {
		        "scan_rate": 5,
		        "task_iterations": 5		
	        },

        */
		pJSONSubContent = cJSON_GetObjectItem(pJSONContent, STR_API_TASKER);
		if (pJSONSubContent)
		{
			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_SCAN_RATE);
			if (pJSONTemp)
				API_Task_SetScanRate(pJSONTemp->valueint);

			pJSONTemp = cJSON_GetObjectItem(pJSONSubContent, STR_TASK_ITERATIONS);
			if (pJSONTemp)
				API_Task_SetTaskIterations(pJSONTemp->valueint);
		}
		// message_thread_pool
		pJSONSubContent = cJSON_GetObjectItem(pJSONContent, STR_MESSAGE_THREAD_POOL);
		if (pJSONSubContent)
			MessageThreadPool_ReadConfig(pJSONSubContent);

		/* System configuration */
		pJSONSubContent = cJSON_GetObjectItem(pJSONContent, STR_SYSTEM);
		if (pJSONSubContent)
			System_ReadConfig(pJSONSubContent);

		/* Data publish to platform configuration */
		pJSONSubContent = cJSON_GetObjectItem(pJSONContent, STR_PUBLISHING);
		if (pJSONSubContent)
			Publish_ReadConfig(pJSONSubContent);

		/* SCM configuration */
		pJSONSubContent = cJSON_GetObjectItem(pJSONContent, STR_SCM);
		if (pJSONSubContent)
			SCM_ReadConfig(pJSONSubContent);
	}
	cJSON_Delete(pJSONContent);
} //> ReadGenericConfigFiles()

//*****************************************************************************
/* example config
	"message_thread_pool": {
		"scan_rate": 15,
		"pool_size": 4,
		"task_iterations": 5		
	},
*/
void MessageThreadPool_ReadConfig(cJSON *pJSONContent)
{
	cJSON *pJSONTemp;

	// scan rate
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_SCAN_RATE);
	if (pJSONTemp)
		MessageThreadPool_SetThreadScanPeriod(pJSONTemp->valueint);

	// pool size
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_POOL_SIZE);
	if (pJSONTemp)
		MessageThreadPool_SetPoolSize(pJSONTemp->valueint);

	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_TASK_ITERATIONS);
	if (pJSONTemp)
		MessageThreadPool_SetTaskIterations(pJSONTemp->valueint);
} //> MessageThreadPool_ReadConfig(...)

//*****************************************************************************
/*System settings configuration.  Example:
	"system": {
		"publish_message_timeout": -1,
		"enable_error_events": false,
		"data_logs_dir" : ".\\data_logs"
	},

*/
void System_ReadConfig(cJSON *pJSONContent)
{
	cJSON *pJSONTemp;

	/*Enable publish data during file transfer*/
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_PUBLISH_DATA_DURING_FILE_TRANSFER_ENABLED);
	if (pJSONTemp)
		g_bPublishDataDuringFileTransfer = (GS_BOOL)pJSONTemp->valueint;

	/*Publish message timeout used for push and write property(s)*/
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_PUBLISH_MESSAGE_TIMEOUT);
	if (pJSONTemp)
		g_publishMessageTimeout = pJSONTemp->valueint;

	/*Enable error events*/
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_ENABLE_ERROR_EVENTS);
	if (pJSONTemp)
		g_bEnableErrorEvents = (GS_BOOL)pJSONTemp->valueint;

	// Define directory for optional data logs (.csv files created to record data publishing information and statistics)
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_DATA_LOGS_DIR);
	if (pJSONTemp)
	{
		TW_FREE(g_pszDataLogsDir);
		g_pszDataLogsDir = GsCreateRelOrAbsDir(pJSONTemp->valuestring, g_pszAgentHomeDir);
	}
	else if (g_pszDataLogsDir)
	{
		// this is as a fallback to default value
		twDirectory_CreateDirectory(g_pszDataLogsDir);
	}
} //> System_ReadConfig(...)

//*****************************************************************************
/* example json 
	"publishing": {
		"min_property_queue_size": 1,
		"property_publishing_delay": 0,
		"max_property_queue_size":2200,
		"data_buffer_output_enable":false
	},

*/
void Publish_ReadConfig(cJSON *pJSONContent)
{
	cJSON *pJSONTemp;
	/*Minimum property queue size for publishing to platform */
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_MIN_PROPERTY_QUEUE_SIZE);
	if (pJSONTemp)
		DataPublishingMgr_SetMinPropertyQueueSize(pJSONTemp->valueint);

	/*Property publishing delay (in seconds) to the platform */
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_PROPERTY_PUBLISHING_DELAY);
	if (pJSONTemp)
		DataPublishingMgr_SetPropertyPublishingDelay(pJSONTemp->valueint);

	/*Maximum property queue size before data publishing loss of data.*/
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_MAX_PROPERTY_QUEUE_SIZE);
	if (pJSONTemp)
		DataPublishingMgr_SetMaxPropertyQueueSize(pJSONTemp->valueint);

	// Check if logging of properties to file is enabled. Default is disabled.
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_DATA_BUFFER_OUTPUT_ENABLE);
	if (pJSONTemp)
	{
		DataPublishingMgr_SetDataBufferOutput(pJSONTemp->valueint);
	}
} //> Publish_ReadConfig(...)

//*****************************************************************************
/*SCM settings configuration.  Example:
	"scm": {
		"scan_rate" : 50,
		"staging_dir": "c:\\temp\\scm_update",
		"idle_timeout_hours": 24
	}

*/
void SCM_ReadConfig(cJSON *pJSONContent)
{
	cJSON *pJSONTemp;

	/*SCM scan rate*/
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_SCAN_RATE);
	if (pJSONTemp)
		SCM_Task_SetScanRate(pJSONTemp->valueint);

	/* target update [temporary] directory for SCM */
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_SCM_STAGING_DIR);
	if (pJSONTemp)
	{
		char *pszStagingPath = GsCreateRelOrAbsDir(pJSONTemp->valuestring, g_pszAgentHomeDir);
		SCM_Task_SetStagingDir(pszStagingPath);
		TW_FREE(pszStagingPath);
	}
	/*  SCM package idle timeout.  Convert hours to seconds */
	pJSONTemp = cJSON_GetObjectItem(pJSONContent, STR_SCM_IDLE_TIMEOUT);
	if (pJSONTemp)
		SCM_Task_SetIdleTimeout(pJSONTemp->valueint * 60 * 60);
} //> SCM_ReadConfig(...)
