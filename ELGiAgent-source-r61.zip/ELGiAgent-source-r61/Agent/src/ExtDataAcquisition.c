
#include "AgentConfig.h"
#include "configParams.h"
#if defined(LEGATO)
#include "legato.h"
#include "interfaces.h"
#endif // LEGATO
#include "twProperties.h"
#include "ExtDataAcquisition.h"
#include "DataPublishingMgr.h"

struct ComInfo g_dataComInfo;
int g_fdComPort = 0;
int g_prevSlaveId = -1;

/*
S.No		Model			Machine_details_1	Machine_details_2
1		N3_EPSAC_C				4160				0
2		N3_EPSAC_C_Sump			4160				1
3		N3_EPSAC_CD				4160				8
4		N3_EPSAC_CD_Sump		4160				9
5		N3_EPSAC_CV20			4160				6
6		N3_EPSAC_CV20_Sump		4160				7
7		N3_EPSAC_CV40			4160				2
8		N3_EPSAC_CV40_Sump		4160				3
9		N3_EPSAC_CVD20			4160				14
10		N3_EPSAC_CVD20_Sump		4160				15
11		N3_EPSAC_CVD40			4160				10
12		N3_EPSAC_CVD40_Sump		4160				11
*/

int g_iMachineDetails_1 = 4160;
int g_iMachineDetails_2 = 10;

GS_BOOL s_bIsModbusSimulated = FALSE;

// Full configuration contents for the data acquisition module
DataAcquisitionConfig *g_dataConfig = NULL;
// Tag parser JSON parsed & cached contents
static cJSON *s_tagParserJSONConfig = NULL;
// Last read & parsing time for the tag parser
static time_t s_tagParserLastReadTime = 0;
static char *s_pszTagParserFilePath = NULL;
static char s_strDataBuffer[EXT_STR_BUFFER_SIZE];
static char s_interimValueData[4][EXT_STR_SUBVAL_MAX_SIZE];
static char s_strIterimValue[EXT_STR_VALUE_MAX_SIZE];

static GsThreadStruct *g_pDataExtThreadStruct = NULL;
static DATETIME g_dataExtWakeupTime = 0;
static unsigned int g_acquisitionRate = 5050;

twList *g_pExtPropertyInfoList = NULL;
time_t g_tRtcSyncDiff = 0;

DATETIME g_deviceDateTime = 0;

// function prototypes
THREAD_FUNCTION_RETURN DataExtThreadFunction(void *pVoid);

// Replacement for SDK's twApi_AddPropertyToList in order to define the Property quality
int AddExtPropertyDefToList(propertyList *pPropertyList, char *pszName, char *pszDescription, int index,
							enum BaseType type, char *pszPushType, double pushThreshold, int frequency);

// Replacement for SDK's twApi_CreatePropertyList in order to define the Property quality
propertyList *CreateExtPropertyDefList(char *pszName, char *pszDescription, int index, enum BaseType type,
									   char *pszPushType, double pushThreshold, int frequency);

enum msgCodeEnum ModbusExt_PropertyCallback(const char *entityName, const char *pszPropertyName,
											twInfoTable **ppInfoTable, char isWrite, void *pUserdata);

//> ---------------------------------------------------------------------------

char *removeChars(char *str, bool isRemovePunct)
{
	int i = 0;
	int len = strlen(str);

	while (str[i] != '\0')
	{
		char c = str[i];
		if (c == ' ' || (isRemovePunct && (c == '\"' || c == ',' || c == ':' || c == '\n' || c == '\t')))
		{
			for (int j = i; j < len; j++)
			{
				str[j] = str[j + 1];
			}
			len--;
			i--;
		}
		i++;
	}
	return str;
} //> removeChars(...)

char *fixPropertyName(char *str)
{
	if (!str)
	{
		return NULL;
	}
	int idx = 0;
	int len = strlen(str);
	if (!len)
	{
		return NULL;
	}
	while (str[idx] != '\0')
	{
		char c = str[idx];
		if (c == ' ' || c == ',' || c == ':' || c == '.')
		{
			str[idx] = '_';
		}
		idx++;
		if (idx >= len)
		{
			break;
		}
	}
	return str;
} //> fixPropertyName(...)

// inline function to swap two numbers
void swap(char *x, char *y)
{
	char t = *x;
	*x = *y;
	*y = t;
}

// function to reverse buffer[i..j]
char *reverse(char *buffer, int i, int j)
{
	while (i < j)
		swap(&buffer[i++], &buffer[j--]);

	return buffer;
}

// Iterative function to implement itoa() function in C
char *itoa(int value, char *buffer, int base)
{
	// invalid input
	if (base < 2 || base > 32)
		return buffer;
	// consider absolute value of number
	int n = abs(value);
	int i = 0;
	while (n)
	{
		int r = n % base;
		if (r >= 10)
			buffer[i++] = 65 + (r - 10);
		else
			buffer[i++] = 48 + r;
		n = n / base;
	}
	// if number is 0
	if (i == 0)
		buffer[i++] = '0';
	// If base is 10 and value is negative, the resulting string
	// is preceded with a minus sign (-)
	// With any other base, value is always considered unsigned
	if (value < 0 && base == 10)
		buffer[i++] = '-';
	buffer[i] = '\0'; // null terminate string
	// reverse the string and return it
	return reverse(buffer, 0, i - 1);
}

int count(char *s, char c)
{
	// Count variable
	int res = 0;
	for (unsigned int i = 0; i < strlen(s); i++)
	{
		// checking character in string
		if (s[i] == c)
			res++;
	}
	return res;
}

int findStr(char *str, char *sub)
{
	unsigned int i = 0;
	unsigned int len = strlen(sub);
	while (str[i] != '\0' && strlen(str) - i >= len)
	{
		char ch = str[i];
		if (ch == sub[0])
		{
			for (unsigned int j = 1; j < len; j++)
			{
				if (str[i + j] != sub[j])
					break;
				else if (j == len - 1)
					return i + 1;
			}
		}
		i++;
	}
	return -1;
}

int findChar(char *str, char c)
{
	int i = 0;
	while (str[i] != '\0')
	{
		char ch = str[i];
		if (c == ch)
		{
			return i + 1;
		}
		i++;
	}
	return -1;
}

char *delChars(char *str, int pos, unsigned int n)
{
	size_t len = strlen(str);
	if ((n + pos) <= len && len > 0 && pos >= 0)
	{
		for (int i = pos; i < len && n + i < len; i++)
		{
			str[i] = str[n + i];
		}
	}
	if (len > 0)
		str[len - 1] = 0;
	//strcpy(&str[pos], &str[n + pos]);
	return str;
}

char *subStr(char *str, int pos, int n)
{
	char *newStr = GsStringDup(str);
	newStr = delChars(newStr, 0, pos);
	newStr = delChars(newStr, n, strlen(newStr) - n);
	return newStr;
}

char *subStrInPlace(char *str, int pos, int n)
{
	char *newStr = (str); // the same string
	newStr = delChars(newStr, 0, pos);
	newStr = delChars(newStr, n, strlen(newStr) - n);
	return newStr;
}

char *convertLongIntToString(char *val1, char *val2, char *val3, char *val4)
{
	char *valStr = (char *)TW_MALLOC(sizeof(char) * (strlen(val1) + strlen(val2) + strlen(val3) + strlen(val4) + 1));
	sprintf(valStr, "%s%s%s%s", val3, val4, val1, val2);
	return valStr;
}

char *convertUnsignedIntToString(char *val1, char *val2)
{
	char *valStr = (char *)TW_MALLOC(sizeof(char) * (strlen(val1) + strlen(val2) + 1));
	sprintf(valStr, "%s%s", val2, val1);
	return valStr;
}

char *convertDoubleToString(double doubleValue, char *output)
{
	if (!output)
	{
		output = (char *)TW_MALLOC(32);
		memset(output, 0, 32);
		sprintf(output, "%.2lf", doubleValue);
		return output;
	}
	else
	{
		sprintf(output, "%.2lf", doubleValue);
		return output;
	}
}

unsigned int convertStringToUnsignedInt(int temp1, int temp2)
{
	char val1 = temp1;
	char val2 = temp2;
	unsigned int retVal = ((val1 & 0xFF) << 8) | (val2 & 0xFF);
	return retVal;
}

char *computeByteOrder(char *byteorder, char (*strData)[EXT_STR_SUBVAL_MAX_SIZE], int length, char *multiFactor)
{
	char *strItem = (char *)TW_MALLOC(32);
	int byteOrder = atoi(byteorder);
	double multi_factor = strtod(multiFactor, 0);

	switch (byteOrder)
	{
	case ABCD:
		if (length == 4)
		{
			sprintf(strItem, "%s%s%s%s", strData[0], strData[1], strData[2], strData[3]);
			unsigned long uLongvalue = strtoul(strItem, 0, 16);
			double dlItem = (double)uLongvalue * multi_factor;
			strItem = convertDoubleToString(dlItem, strItem);
			strcat(strItem, ",");
		}
		else if (length == 2)
		{
			int temp1 = (int)strtol(strData[0], NULL, 16);
			int temp2 = (int)strtol(strData[1], NULL, 16);
			unsigned int uIntvalue = convertStringToUnsignedInt(temp1, temp2);
			double dlItem = (double)uIntvalue * multi_factor;
			strItem = convertDoubleToString(dlItem, strItem);
			strcat(strItem, ",");
		}
		break;
	case BADC:
		if (length == 4)
		{
			sprintf(strItem, "%s%s%s%s", strData[1], strData[0], strData[3], strData[2]);
			unsigned long uLongvalue = strtoul(strItem, 0, 16);
			double dlItem = (double)uLongvalue * multi_factor;
			strItem = convertDoubleToString(dlItem, strItem);
			strcat(strItem, ",");
		}
		else if (length == 2)
		{
			int temp1 = (int)strtol(strData[0], NULL, 16);
			int temp2 = (int)strtol(strData[1], NULL, 16);
			unsigned int uIntvalue = convertStringToUnsignedInt(temp1, temp2);
			double dlItem = (double)uIntvalue * multi_factor;
			strItem = convertDoubleToString(dlItem, strItem);
			strcat(strItem, ",");
		}
		break;
	case CDAB:
		if (length == 4)
		{
			sprintf(strItem, "%s%s%s%s", strData[2], strData[3], strData[0], strData[1]); // Fix Me
			unsigned long uLongvalue = strtoul(strItem, 0, 16);
			double dlItem = (double)uLongvalue * multi_factor;
			strItem = convertDoubleToString(dlItem, strItem);
			strcat(strItem, ",");
		}
		else if (length == 2)
		{
			int temp1 = (int)strtol(strData[0], NULL, 16);
			int temp2 = (int)strtol(strData[1], NULL, 16);
			unsigned int uIntvalue = convertStringToUnsignedInt(temp1, temp2);
			double dlItem = (double)uIntvalue * multi_factor;
			strItem = convertDoubleToString(dlItem, strItem);
			strcat(strItem, ",");
		}
		break;
	case DCBA:
		if (length == 4)
		{
			sprintf(strItem, "%s%s%s%s", strData[3], strData[2], strData[1], strData[0]);
			unsigned long uLongvalue = strtoul(strItem, 0, 16);
			double dlItem = (double)uLongvalue * multi_factor;
			strItem = convertDoubleToString(dlItem, strItem);
			strcat(strItem, ",");
		}
		else if (length == 2)
		{
			int temp1 = (int)strtol(strData[0], NULL, 16);
			int temp2 = (int)strtol(strData[1], NULL, 16);
			unsigned int uIntvalue = convertStringToUnsignedInt(temp1, temp2);
			double dlItem = (double)uIntvalue * multi_factor;
			strItem = convertDoubleToString(dlItem, strItem);
			strcat(strItem, ",");
		}
		break;
	} //# switch byteOrder
	return strItem;
} //> computeByteOrder(...)
//> ---------------------------------------------------------------------------

void DeleteDataAcquisitionConfig(void)
{
	if (!g_dataConfig)
	{
		return; // nothing to do
	}
	GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME, "Releasing internal structures for Data Acquisition Configuration");
	ModbusConfig *pModbusConfigs = g_dataConfig->modbusConfigs;
	const int numConfigs = g_dataConfig->numConfigs;
	for (int cIdx = 0; cIdx < numConfigs; cIdx++)
	{
		if (!pModbusConfigs)
		{
			break;
		}
		ModbusConfig *pModbusConfig = &pModbusConfigs[cIdx];
		const int numQueries = pModbusConfig->numQueries;
		for (int qIdx = 0; qIdx < numQueries; qIdx++)
		{
			if (!pModbusConfig->modbusQueries)
			{
				break;
			}
			ModbusQuery *pQuery = &(pModbusConfig->modbusQueries[qIdx]);
			if (pQuery->dataBits)
			{
				TW_FREE(pQuery->dataBits);
				pQuery->dataBits = NULL;
			}
		} //# for each query
		if (pModbusConfig->modbusQueries)
		{
			// FIXME
			TW_FREE(pModbusConfig->modbusQueries);
			pModbusConfig->modbusQueries = NULL;
		}
	} //# for each modbus config
	if (pModbusConfigs)
	{
		TW_FREE(pModbusConfigs);
		g_dataConfig->modbusConfigs = NULL;
		g_dataConfig->numConfigs = 0;
	}
	if (g_dataConfig->queries)
	{
		TW_FREE(g_dataConfig->queries);
		g_dataConfig->queries = NULL;
		g_dataConfig->numQueries = 0;
	}
	if (g_dataConfig->timerData)
	{
		TW_FREE(g_dataConfig->timerData);
		g_dataConfig->timerData = NULL;
		g_dataConfig->numTimers = 0;
	}
	if (g_dataConfig->rawData)
	{
		TW_FREE(g_dataConfig->rawData);
		g_dataConfig->rawData = NULL;
	}
	TW_FREE(g_dataConfig);
	g_dataConfig = NULL;
} //> DeleteDataAcquisitionConfig()
//> ---------------------------------------------------------------------------

void PrepareDataAcquisitionConfig(int numQueries, int numConfigs, int numTimers)
{
	DeleteDataAcquisitionConfig(); // free all
	g_dataConfig = (DataAcquisitionConfig *)TW_MALLOC(sizeof(DataAcquisitionConfig));
	memset(g_dataConfig, 0, sizeof(DataAcquisitionConfig));

	g_dataConfig->numQueries = numQueries;
	g_dataConfig->queries = (DataQuery *)TW_MALLOC(sizeof(DataQuery) * numQueries);
	memset(g_dataConfig->queries, 0, sizeof(DataQuery) * numQueries);
	g_dataConfig->rawData = (DataArrays *)TW_MALLOC(sizeof(DataArrays) * numQueries);
	memset(g_dataConfig->rawData, 0, sizeof(DataArrays) * numQueries);

	g_dataConfig->numConfigs = numConfigs;
	g_dataConfig->modbusConfigs = (ModbusConfig *)TW_MALLOC(sizeof(ModbusConfig) * numConfigs);
	memset(g_dataConfig->modbusConfigs, 0, sizeof(ModbusConfig) * numConfigs);

	g_dataConfig->numTimers = numTimers;
	g_dataConfig->timerData = (DataMap *)TW_MALLOC(sizeof(DataMap) * numTimers);
	memset(g_dataConfig->timerData, 0, sizeof(DataMap) * numTimers);

	memset(s_strDataBuffer, 0, EXT_STR_BUFFER_SIZE);
} //> PrepareDataAcquisitionConfig(...)
//> ---------------------------------------------------------------------------

int RTC_read(char *address)
{
#if defined(LEGATO)
	char cmd[EXT_STR_BUFFER_SIZE];
	char line[EXT_STR_TMP_SIZE];
	char *out = NULL;
	unsigned int value = 0;
	FILE *fp = NULL;
	memset(cmd, 0, EXT_STR_BUFFER_SIZE);
	memset(line, 0, EXT_STR_TMP_SIZE);
	strcpy(cmd, "/usr/sbin/i2cget -y 4 0x68 ");
	strcat(cmd, address);
	usleep(5);
	fp = popen(cmd, "r");
	if (!fp)
	{
		return -1;
	}
	if (fp != NULL)
	{
		while (fgets(line, EXT_STR_TMP_SIZE, fp) != NULL)
		{
			out = subStrInPlace(line, 2, 2); // calls GsStringDup
			if ((address != RTC_SEC_ADDRESS) && (address != RTC_MIN_ADDRESS) && (address != RTC_HRS_ADDRESS))
			{
				value = atoi(out);
			}
			else
			{
				value = atoi(out);
			}
			memset(line, EXT_STR_TMP_SIZE, 0);
		} //# for each line
		fclose(fp);
	}
	if (strcmp(address, RTC_YER_ADDRESS) == 0)
	{
		value = value + 1900 + 100;
	}
	return (int)value;
#endif // LEGATO
#if defined(WIN32)
	SYSTEMTIME sys_time;
	GetLocalTime(&sys_time);
	int out = -1;
	if (strcmp(address, RTC_SEC_ADDRESS) == 0)
	{
		out = sys_time.wSecond;
	}
	else if (strcmp(address, RTC_MIN_ADDRESS) == 0)
	{
		out = sys_time.wMinute;
	}
	else if (strcmp(address, RTC_HRS_ADDRESS) == 0)
	{
		out = sys_time.wHour;
	}
	else if (strcmp(address, RTC_DAY_ADDRESS) == 0)
	{
		out = sys_time.wDay;
	}
	else if (strcmp(address, RTC_DAT_ADDRESS) == 0)
	{
		out = sys_time.wDay;
	}
	else if (strcmp(address, RTC_MON_ADDRESS) == 0)
	{
		out = sys_time.wMonth;
	}
	else if (strcmp(address, RTC_YER_ADDRESS) == 0)
	{
		out = sys_time.wYear;
	}
	return out;
#endif // WIN32
#if defined(LINUX) && !defined(LEGATO)
	time_t my_time;
	struct tm *timeinfo;
	time(&my_time);
	timeinfo = localtime(&my_time);
	int out = -1;
	if (strcmp(address, RTC_SEC_ADDRESS) == 0)
	{
		out = timeinfo->tm_sec;
	}
	else if (strcmp(address, RTC_MIN_ADDRESS) == 0)
	{
		out = timeinfo->tm_min;
	}
	else if (strcmp(address, RTC_HRS_ADDRESS) == 0)
	{
		out = timeinfo->tm_hour;
	}
	else if (strcmp(address, RTC_DAY_ADDRESS) == 0)
	{
		out = timeinfo->tm_mday;
	}
	else if (strcmp(address, RTC_DAT_ADDRESS) == 0)
	{
		out = timeinfo->tm_mday;
	}
	else if (strcmp(address, RTC_MON_ADDRESS) == 0)
	{
		out = timeinfo->tm_mon + 1;
	}
	else if (strcmp(address, RTC_YER_ADDRESS) == 0)
	{
		out = timeinfo->tm_year + 1900;
	}
	return out;
#endif // LINUX
} //> RTC_read(...)
//> ---------------------------------------------------------------------------

void RTC_write(char *address, int value)
{
#if defined(LEGATO)
	char cmd[EXT_STR_TMP_SIZE];
	memset(cmd, 0, EXT_STR_TMP_SIZE);
	sprintf(cmd, "/usr/sbin/i2cset -y 4 0x68 %s 0x%d", address, value);
	system(cmd);
	LE_INFO("cmd %s", cmd);
#endif // LEGATO
} //> RTC_write(...)
//> ---------------------------------------------------------------------------

DATETIME Get_RTC_TIME()
{
	DATETIME dt = 0, diff = 0, rtc_ms = 0;
	time_t rtc_sec = 0;
	struct tm conv;
	GS_BOOL status = TRUE;
	dt = twGetSystemTime(TRUE);
	RTC_DateTime.Sec = RTC_read(RTC_SEC_ADDRESS);
	RTC_DateTime.Min = RTC_read(RTC_MIN_ADDRESS);
	RTC_DateTime.Hour = RTC_read(RTC_HRS_ADDRESS);
	RTC_DateTime.Date = RTC_read(RTC_DAT_ADDRESS);
	RTC_DateTime.Month = RTC_read(RTC_MON_ADDRESS);
	RTC_DateTime.Year = RTC_read(RTC_YER_ADDRESS);
	int *parts = (int *)&RTC_DateTime;
	for (int i = 0; i < 6; i++)
	{
		if (parts[i] < 0)
			status = FALSE;
	}
	if (!status)
	{
		g_deviceDateTime = dt;
		return 0;
	}
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "Get_RTC_TIME: %d/%02d/%02d %02d:%02d:%02d", RTC_DateTime.Year, RTC_DateTime.Month, RTC_DateTime.Date,
			 RTC_DateTime.Hour, RTC_DateTime.Min, RTC_DateTime.Sec);
	//sprintf(dateTimeString, "%s%s%s%s%s%s%s%s%s%s%s", RTC_DateTime.Year, "-", RTC_DateTime.Month, "-",
	//		RTC_DateTime.Date, " ", RTC_DateTime.Hour, ":", RTC_DateTime.Min, ":", RTC_DateTime.Sec);
	conv.tm_hour = (RTC_DateTime.Hour);
	conv.tm_min = (RTC_DateTime.Min);
	conv.tm_sec = (RTC_DateTime.Sec);
	conv.tm_mday = (RTC_DateTime.Date);
	conv.tm_mon = (RTC_DateTime.Month) - 1;
	conv.tm_year = (RTC_DateTime.Year) - 1900;
	conv.tm_wday = 0;
	conv.tm_yday = 0;
	conv.tm_isdst = 0;
	rtc_sec = mktime(&conv);
	if (rtc_sec != (time_t)-1)
	{
		rtc_ms = (rtc_sec * 1000LL) + 0LL; // 0 ms?
		g_deviceDateTime = rtc_ms;
	}
	else
	{
		rtc_ms = dt; // force it
		g_deviceDateTime = dt;
	}
	if (rtc_ms > dt)
		diff = rtc_ms - dt;
	else
		diff = dt - rtc_ms;
	if (diff > 59 * 60 * 1000)
	{
		diff = (DATETIME)abs((int)diff - 60 * 60 * 1000);
	}
	g_tRtcSyncDiff = diff;
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "Get_RTC_TIME: diff='%lld' dt='%lld' rtc_ms='%lld'", diff, dt, rtc_ms);
	return rtc_ms;
} //> Get_RTC_TIME()
//> ---------------------------------------------------------------------------

void RTC_Synchronize()
{
	struct RTC syncRTC;
	struct tm ts;
	time_t seconds = 0;
#if defined(LEGATO)
	le_clk_Time_t time_clk = le_clk_GetAbsoluteTime();
	seconds = time_clk.sec;
#else
	seconds = time(NULL);
#endif // LEGATO
	ts = *localtime(&seconds);
	syncRTC.Date = ts.tm_mday;
	syncRTC.Month = ts.tm_mon + 1;
	syncRTC.Year = ts.tm_year - 100; // To get only the second part of the year
	syncRTC.Hour = ts.tm_hour;
	syncRTC.Min = ts.tm_min;
	syncRTC.Sec = ts.tm_sec;
	DATETIME rtc = Get_RTC_TIME();
	int64_t diff = abs(rtc / 1000 - seconds);
	if (diff >= 3600LL && diff < 7200LL)
		diff = diff - 3600LL;
	if (diff < 10LL)
	{
		GsAppLog(GS_DEBUG, MODULE_GS_DATA, "SyncRTCTime: skipped, difference is too small (diff = %llds)", diff);
		return;
	}
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "SyncRTCTime: 20%d/%02d/%02d %02d:%02d:%02d (diff = %llds)", syncRTC.Year, syncRTC.Month, syncRTC.Date,
			 syncRTC.Hour, syncRTC.Min, syncRTC.Sec, diff);
//return;		//#FIXME
// Check RTC time and Network/Linux Time if there is difference in both.
// Need to call  the below Statements.
#if defined(LEGATO)
	RTC_write(RTC_YER_ADDRESS, syncRTC.Year); // To get only the second part of the year
	usleep(5);
	RTC_write(RTC_MON_ADDRESS, syncRTC.Month);
	usleep(5);
	RTC_write(RTC_DAT_ADDRESS, syncRTC.Date);
	usleep(5);
	RTC_write(RTC_HRS_ADDRESS, syncRTC.Hour);
	usleep(5);
	RTC_write(RTC_MIN_ADDRESS, syncRTC.Min);
	usleep(5);
	RTC_write(RTC_SEC_ADDRESS, syncRTC.Sec);
#endif // LEGATO
} //> RTC_Synchronize()
//> ---------------------------------------------------------------------------

void executeGPIOConfig(char *gpioMessage)
{
#if defined(LEGATO)
	if (gpioMessage != NULL)
	{
		char cmd[EXT_STR_TMP_SIZE];
		memset(cmd, 0, EXT_STR_TMP_SIZE);
		strcpy(cmd, gpioMessage);
		system(cmd);
	}
#else
	GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "GPIO MESSAGE (DUMMY): '%s'", gpioMessage);
#endif
} //> executeGPIOConfig(...)
//> ---------------------------------------------------------------------------

char *ReadFabNumberString()
{
#if defined(LEGATO)
	if (!s_bIsModbusSimulated)
	{
		char *fabNumberString = NULL;
		unsigned char sendBuffer[8];
		sendBuffer[0] = 01;
		sendBuffer[1] = 03;
		sendBuffer[2] = 17;
		sendBuffer[3] = 06;
		sendBuffer[4] = 0;
		sendBuffer[5] = 06;
		sendBuffer[6] = 32;
		sendBuffer[7] = 245;

		int dataLen = 6 * 2 + 5;
		usleep(2000000);
		tcflush(g_fdComPort, TCIOFLUSH);
		SendFabNumberBuf(g_fdComPort, (const char *)sendBuffer, (int)sizeof(sendBuffer));
		usleep(100000);
		executeGPIOConfig(gpioLow);
		usleep(350000);
		char *strFab = GsStringDup(ModbusRead_SingleDataString(g_fdComPort, dataLen));
		if (strFab != NULL)
		{
			fabNumberString = removeChars(subStr(strFab, 3, strlen(strFab) - 5), FALSE);
		}
		return fabNumberString;
	}
#endif // LEGATO
	if (s_bIsModbusSimulated)
	{
		int idx = 0;
		char *dummyValue = (char *)TW_MALLOC(16);
		memset(dummyValue, 0, 16);
		// BDHS030461
		// 4 chars + 6 nums
		for (; idx < 4; idx++)
		{
			dummyValue[idx] = rand() % 26 + 65;
		}
		for (; idx < 10; idx++)
		{
			dummyValue[idx] = rand() % 10 + 48;
		}
		return dummyValue;
	}
	return NULL;
} //> ReadFabNumberString()
//> ---------------------------------------------------------------------------

char *ReadDeviceIDString()
{
	char *deviceIdValue = NULL;
#if defined(LEGATO)
	if (!s_bIsModbusSimulated)
	{
		deviceIdValue = (char *)TW_MALLOC(LE_INFO_IMEI_MAX_BYTES);
		memset(deviceIdValue, 0, LE_INFO_IMEI_MAX_BYTES);
		char deviceIdArray[LE_INFO_IMEI_MAX_BYTES];
		memset(deviceIdArray, 0, LE_INFO_IMEI_MAX_BYTES);
		if (le_info_GetImei(deviceIdArray, sizeof(deviceIdArray)) != LE_OK)
		{
			TW_FREE(deviceIdValue);
			return NULL;
		}
		strcpy(deviceIdValue, deviceIdArray);
		return deviceIdValue;
	}
#endif // LEGATO
	if (s_bIsModbusSimulated)
	{
		int idx = 0;
		deviceIdValue = (char *)TW_MALLOC(20);
		memset(deviceIdValue, 0, 20);
		for (; idx < 15; idx++)
		{
			deviceIdValue[idx] = rand() % 10 + 48;
		}
		return deviceIdValue;
	}
	return NULL;
} //> ReadDeviceIDString()
  //> ---------------------------------------------------------------------------

ExtPropertyDef *ExtPropertyDef_Create(char *pszName, char *pszDescription, int index, enum BaseType type,
									  char *pszPushType, double pushThreshold, int frequency)
{
	ExtPropertyDef *tmp = NULL;
	if (!pszName)
	{
		GsAppLog(GS_ERROR, MODULE_GS_DATA, "ExtPropertyDef_Create: NULL name pointer passed in");
		return NULL;
	}
	tmp = (ExtPropertyDef *)TW_CALLOC(sizeof(ExtPropertyDef), 1);
	if (!tmp)
	{
		GsAppLog(GS_ERROR, MODULE_GS_DATA, "twPropertyDef_Create: Error allocating memory");
		return NULL;
	}
	memset(tmp, 0, sizeof(ExtPropertyDef));
	tmp->definition = twPropertyDef_Create(pszName, type, pszDescription, pszPushType, pushThreshold);
	tmp->frequency = frequency;
	tmp->index = index;
	return tmp;
} //> ExtPropertyDef_Create(...)
//> ---------------------------------------------------------------------------

void ExtPropertyDef_Delete(void *input)
{
	if (input)
	{
		ExtPropertyDef *tmp = (ExtPropertyDef *)input;
		tmp->lastUpdateTs = 0;
		tmp->frequency = 0;
		tmp->index = 0;
		twPropertyDef_Delete(tmp->definition);
		tmp->definition = NULL;
		TW_FREE(tmp);
	}
} //> ExtPropertyDef_Delete(...)
//> ---------------------------------------------------------------------------

// Replacement for SDK's twApi_AddPropertyToList in order to define the Property quality
int AddExtPropertyDefToList(propertyList *pPropertyList, char *pszName, char *pszDescription, int index,
							enum BaseType type, char *pszPushType, double pushThreshold, int frequency)
{
	ExtPropertyDef *pProperty;
	pProperty = ExtPropertyDef_Create(pszName, pszDescription, index, type,
									  pszPushType, pushThreshold, frequency);
	return twList_Add(pPropertyList, pProperty);
} //> AddExtPropertyDefToList(...)
//> ---------------------------------------------------------------------------

// Replacement for SDK's twApi_CreatePropertyList in order to define the Property quality
propertyList *CreateExtPropertyDefList(char *pszName, char *pszDescription, int index, enum BaseType type,
									   char *pszPushType, double pushThreshold, int frequency)
{
	propertyList *pPropertyList = twList_Create(ExtPropertyDef_Delete);
	AddExtPropertyDefToList(pPropertyList, pszName, pszDescription, index, type,
							pszPushType, pushThreshold, frequency);
	return pPropertyList;
} //> CreateExtPropertyDefList(...)
//> ---------------------------------------------------------------------------

ExtPropertyDef *GetExtPropertyDefByName(const char *pszName)
{
	if (!pszName || !g_pExtPropertyInfoList)
	{
		return NULL;
	}
	ListEntry *pItem = g_pExtPropertyInfoList->first;
	while (pItem)
	{
		ExtPropertyDef *pPropertyDef = (ExtPropertyDef *)pItem->value;
		if (pPropertyDef != NULL && pPropertyDef->definition != NULL)
		{
			if (strcmp(pPropertyDef->definition->name, pszName) == 0)
				return pPropertyDef;
		}
		pItem = pItem->next;
	} //# while got items
	return NULL;
} //> GetExtPropertyDefByName(...)
//> ---------------------------------------------------------------------------

void RegisterModbusExtProperty(ExtPropertyDef *pPropertyDef)
{
	if (!pPropertyDef)
	{
		return;
	}
	twPropertyDef *pDefinition = pPropertyDef->definition;
	if (!pDefinition)
	{
		return;
	}
	char *pszPushType = TW_PUSH_TYPE_ALWAYS;
	cJSON *pInnerItem = pDefinition->aspects != NULL ? cJSON_GetObjectItem(pDefinition->aspects, "pushType") : NULL;
	if (pInnerItem != NULL && pInnerItem->type == cJSON_String)
	{
		pszPushType = pInnerItem->valuestring;
	}
	double pushThreshold = TW_PUSH_THRESHOLD_NONE;
	pInnerItem = pDefinition->aspects != NULL ? cJSON_GetObjectItem(pDefinition->aspects, "pushThreshold") : NULL;
	if (pInnerItem != NULL && pInnerItem->type == cJSON_Number)
	{
		pushThreshold = pInnerItem->valuedouble;
	}
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "Registering Modbus External Property [%d]: '%s'", pPropertyDef->index, pDefinition->name);
	twApi_RegisterProperty(TW_THING, g_pszThingIdentifier, pDefinition->name,
						   pDefinition->type, pDefinition->description, pszPushType, pushThreshold,
						   ModbusExt_PropertyCallback, (void *)NULL);
} //> RegisterModbusExtProperty(...)
//> ---------------------------------------------------------------------------

// Unregister a ModbusExt property with the ThingWorx server.
// This is only requried for writable properties.
void UnregisterModbusExtProperty(char *pszPropertyName)
{
	twApi_UnregisterPropertyCallback(g_pszThingIdentifier, pszPropertyName, (void *)NULL);
} //> UnregisterModbusExtProperty(...)
//> ---------------------------------------------------------------------------

// Callback invoked by a proeprty write.
enum msgCodeEnum ModbusExt_PropertyCallback(const char *entityName, const char *pszPropertyName,
											twInfoTable **ppInfoTable, char isWrite, void *pUserdata)
{
	if (!isWrite || ppInfoTable == NULL)
		return TWX_SUCCESS;
	if (*ppInfoTable == NULL)
		return TWX_SUCCESS;
	twInfoTable *pContent = *ppInfoTable;
	twInfoTableRow *pRow;
	twPrimitive *pValue = NULL;
	int colIndex = 0, idx = 0;
	uint32_t length = pContent->rows->count;
	char valueStr[128];
	if (length > 0 && twDataShape_GetEntryIndex(pContent->ds, pszPropertyName, &colIndex) == TW_INDEX_NOT_FOUND)
		colIndex = -1;
	for (; idx < length && colIndex != -1; idx++)
	{
		pRow = twInfoTable_GetEntry(pContent, idx);
		pValue = twInfoTableRow_GetEntry(pRow, colIndex);
		if (!pValue)
			continue;
		memset(valueStr, 0, 128);
		if (pValue->type == TW_STRING)
			sprintf(valueStr, "%s", pValue->val.bytes.data);
		else if (pValue->type == TW_INTEGER)
			sprintf(valueStr, "%d", pValue->val.integer);
		else if (pValue->type == TW_NUMBER)
			sprintf(valueStr, "%.2f", pValue->val.number);
		else if (pValue->type == TW_BOOLEAN)
			sprintf(valueStr, "%s", pValue->val.boolean ? "true" : "false");
		else if (pValue->type == TW_DATETIME)
			twGetTimeString(pValue->val.datetime, valueStr, "%Y-%m-%d %H:%M:%S", 128, 1, 1);
		break;
	} //# for each input it row
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, ">> >> >> Updating property '%s' = '%s'", pszPropertyName, valueStr);
	return TWX_SUCCESS;
} //> ModbusExt_PropertyCallback(...)
//> ---------------------------------------------------------------------------

void RegisterModbusExtProperties(twList *pPropertyDefList)
{
	GsAppLog(GS_INFO, MODULE_GS_DATA, "Registering Modbus External properties (count: %d)",
			 (pPropertyDefList != NULL ? pPropertyDefList->count : 0));
	if (!pPropertyDefList)
	{
		return; // skip!
	}
	// This will register the properties based on input list
	ListEntry *pItem = pPropertyDefList->first;
	while (pItem)
	{
		ExtPropertyDef *pPropertyDef = (ExtPropertyDef *)pItem->value;
		if (pPropertyDef != NULL)
		{
			RegisterModbusExtProperty(pPropertyDef);
		}
		pItem = pItem->next;
	} //# while got items
} //> RegisterModbusExtProperties(...)
//> ---------------------------------------------------------------------------

void UnregisterModbusExtProperties(twList *pPropertyDefList)
{
	GsAppLog(GS_INFO, MODULE_GS_DATA, "Unregistering Modbus External properties (count: %d)");
	if (!pPropertyDefList)
	{
		return; // skip!
	}
	// This will register the properties based on input list
	ListEntry *pItem = pPropertyDefList->first;
	while (pItem)
	{
		ExtPropertyDef *pPropertyDef = (ExtPropertyDef *)pItem->value;
		if (pPropertyDef != NULL && pPropertyDef->definition != NULL)
		{
			UnregisterModbusExtProperty(pPropertyDef->definition->name);
		}
		pItem = pItem->next;
	} //# while got items
} //> UnregisterModbusExtProperties(...)
//> ---------------------------------------------------------------------------

void AppendToModbusPropertyInfoList(twList **ppPropertyList, char *pszName, char *pszDescription, int index,
									enum BaseType type, char *pszPushType, double pushThreshold, int frequency)
{
	if (*ppPropertyList == NULL)
	{
		*ppPropertyList = CreateExtPropertyDefList(pszName, pszDescription, index, type,
												   pszPushType, pushThreshold, frequency);
	}
	else
	{
		AddExtPropertyDefToList(*ppPropertyList, pszName, pszDescription, index, type,
								pszPushType, pushThreshold, frequency);
	}
} //> AppendToModbusPropertyInfoList(...)
//> ---------------------------------------------------------------------------

void AppendToRemotePropertyList(propertyList **ppPropertyList, char *pszName, twPrimitive *pValue, DATETIME dt)
{
	if (!pValue)
	{
		return;
	}
	if (*ppPropertyList == NULL)
	{
		*ppPropertyList = GsCreatePropertyList(pszName, pValue, dt, TW_QUALITY_GOOD);
	}
	else
	{
		GsAddPropertyToList(*ppPropertyList, pszName, pValue, dt, TW_QUALITY_GOOD);
	}
} //> AppendToRemotePropertyList(...)
//> ---------------------------------------------------------------------------

cJSON *ReadAndCacheTagParserConfigFile(bool force)
{
	cJSON *pJSONConfig = NULL;
	bool shouldParse = force;
	struct stat fstat;
	time_t curTime = 0;
	cJSON *pInnerTag = NULL;
	cJSON *pArrayItem = NULL;
	cJSON *pKeyItem = NULL;
	cJSON *pNameItem = NULL;
	int numArrayItems = 0;
	if (!s_pszTagParserFilePath)
	{
		s_pszTagParserFilePath = GetFilePathInAgentHome(MODBUS_CONFIG_FOLDER_NAME, STR_TAG_PARSER_CONFIG_FILENAME);
	}
	char *pszConfigContent = GsReadFileContent(s_pszTagParserFilePath);
	if (!pszConfigContent)
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s must exist to properly configure remote properties.", s_pszTagParserFilePath);
		return NULL;
	}
	// at this point - check the time stamps and refresh the file
	if (!shouldParse)
	{
		stat(s_pszTagParserFilePath, &fstat);
		time_t curTime = (time_t)(twGetSystemTime(TRUE) / 1000);
		if (curTime - fstat.st_mtime < 30 * 1000)
		{
			shouldParse = TRUE;
		}
		else if (s_tagParserLastReadTime == 0 || curTime - s_tagParserLastReadTime > 30 * 60 * 1000)
		{
			shouldParse = TRUE;
		}
	}
	if (!shouldParse)
	{
		TW_FREE(pszConfigContent);
		// no need to parse?
		// just return existing value
		return s_tagParserJSONConfig;
	}
	pJSONConfig = cJSON_Parse(pszConfigContent);
	if (!pJSONConfig)
	{
		// In this case it's not needed to overwrite existing configuration file (if it's cached)
		// - the function will still return NULL to indicate that there's an issue.
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Error reading file %s: %s. Unable to retrieve the list of remote properties.", s_pszTagParserFilePath, cJSON_GetErrorPtr());
		TW_FREE(pszConfigContent);
		return NULL;
	}
	{
		pInnerTag = GsVerifyJSONContent(pJSONConfig, "slave_id");
		if (!pInnerTag)
		{
			GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Error reading file %s: Missing 'slave_id' definitions.", s_pszTagParserFilePath);
		}
		if (pInnerTag != NULL && pInnerTag->type != cJSON_Array)
		{
			GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Error reading file %s: Inner 'slave_id' property is not an array.", s_pszTagParserFilePath);
			pInnerTag = NULL; // force it
		}
		if (pInnerTag != NULL)
		{
			numArrayItems = cJSON_GetArraySize(pInnerTag);
			if (!numArrayItems)
				GsAppLog(GS_WARN, MODULE_GS_CONFIG, "Issue in file %s: Inner 'slave_id' array is empty!", s_pszTagParserFilePath);
		}
	}
	if (s_tagParserJSONConfig)
	{
		cJSON_Delete(s_tagParserJSONConfig); // free cached version
	}
	if (!pInnerTag)
	{
		// this means failure
		cJSON_Delete(pJSONConfig);
		pJSONConfig = NULL;
		numArrayItems = 0;
	}
	// overwrite the config in memory
	s_tagParserJSONConfig = pJSONConfig;
	s_tagParserLastReadTime = twGetSystemTime(TRUE) / 1000;
	for (int idx = 0; idx < numArrayItems; idx++)
	{
		pArrayItem = cJSON_GetArrayItem(pInnerTag, idx);
		if (!pArrayItem)
			break; // skip!
		pKeyItem = pArrayItem->child;
		while (pKeyItem)
		{
			if (strcasecmp(pKeyItem->string, "id") == 0)
			{
				pKeyItem = pKeyItem->next; //! next
				// skip id for now
				continue;
			}
			if (pKeyItem->type == cJSON_String)
			{
				fixPropertyName(pKeyItem->valuestring);
			}
			else if (pKeyItem->type == cJSON_Object)
			{
				pNameItem = cJSON_GetObjectItem(pKeyItem, "name");
				if (pNameItem != NULL && pNameItem->type == cJSON_String)
				{
					fixPropertyName(pNameItem->valuestring);
				}
			}
			pKeyItem = pKeyItem->next; //! next
		}
	} //# for each json array item
	TW_FREE(pszConfigContent);
	return s_tagParserJSONConfig;
} //> ReadAndCacheTagParserConfigFile(...)
//> ---------------------------------------------------------------------------

twList *RetrieveExternalPropertyListInfo()
{
	cJSON *pInnerTag = NULL;
	cJSON *pArrayItem = NULL;
	cJSON *pKeyItem = NULL;
	cJSON *pInnerItem = NULL;
	char *pszPushType, *pszName;
	double pushThreshold = 0.0;
	enum BaseType baseType = TW_NOTHING;
	int numArrayItems = 0;
	int frequency = 5;
	GS_BOOL gotDeviceTime = FALSE;
	twList *pResultList = NULL;
	cJSON *pJSONConfig = ReadAndCacheTagParserConfigFile(true); // retrieve the config
	if (!pJSONConfig)
	{
		return NULL; // error messages are already printed
	}
	pInnerTag = GsVerifyJSONContent(pJSONConfig, "slave_id");
	numArrayItems = cJSON_GetArraySize(pInnerTag);
	for (int aIdx = 0; aIdx < numArrayItems; aIdx++)
	{
		pArrayItem = cJSON_GetArrayItem(pInnerTag, aIdx);
		if (!pArrayItem)
			break; // skip!
		pKeyItem = pArrayItem->child;
		while (pKeyItem)
		{
			pszName = NULL;
			if (strcasecmp(pKeyItem->string, "id") == 0)
			{
				pKeyItem = pKeyItem->next; //! next
				// skip id for now
				continue;
			}
			if (pKeyItem->type != cJSON_String && pKeyItem->type != cJSON_Object)
			{
				pKeyItem = pKeyItem->next; //! next
				continue;
			}
			if (pKeyItem->type == cJSON_String)
			{
				// fallback!
				pszName = pKeyItem->valuestring;
				pushThreshold = TW_PUSH_THRESHOLD_NONE;
				pszPushType = TW_PUSH_TYPE_ALWAYS;
				baseType = TW_NUMBER;
			}
			else if (pKeyItem->type == cJSON_Object)
			{
				pInnerItem = cJSON_GetObjectItem(pKeyItem, "name");
				if (pInnerItem != NULL && pInnerItem->type == cJSON_String)
				{
					pszName = pInnerItem->valuestring;
				}
				pInnerItem = cJSON_GetObjectItem(pKeyItem, "type");
				if (pInnerItem != NULL && pInnerItem->type == cJSON_String)
				{
					lowercase(pInnerItem->valuestring);
					char *pszType = pInnerItem->valuestring;
					if (strcasecmp(pszType, "number") == 0)
						baseType = TW_NUMBER;
					else if (strcasecmp(pszType, "integer") == 0)
						baseType = TW_INTEGER;
					else if (strcasecmp(pszType, "boolean") == 0)
						baseType = TW_BOOLEAN;
					else if (strcasecmp(pszType, "string") == 0)
						baseType = TW_STRING;
					else if (strcasecmp(pszType, "datetime") == 0)
						baseType = TW_DATETIME;
				}
				else
				{
					baseType = TW_NUMBER;
				}
				frequency = 5; // should default to 5? or 0?
				pInnerItem = cJSON_GetObjectItem(pKeyItem, "frequency");
				if (pInnerItem != NULL && pInnerItem->type == cJSON_Number)
				{
					frequency = pInnerItem->valueint;
				}
				pInnerItem = cJSON_GetObjectItem(pKeyItem, "publish");
				if (pInnerItem != NULL && pInnerItem->type == cJSON_String)
				{
					lowercase(pInnerItem->valuestring);
					if (strcmp(pInnerItem->valuestring, "onchange") == 0)
					{
						pszPushType = TW_PUSH_TYPE_VALUE;
						pushThreshold = 0.001;
					}
					else
					{
						pszPushType = TW_PUSH_TYPE_ALWAYS;
						pushThreshold = 0.0;
					}
				}
			}
			int propIdx = atoi(pKeyItem->string); //? lost for now
			// Property name is in item -> valuestring
			if (pszName != NULL)
			{
				if (!gotDeviceTime && strcasecmp(pszName, "device_time") == 0)
					gotDeviceTime = TRUE;
				AppendToModbusPropertyInfoList(&pResultList, pszName, "", propIdx, baseType,
											   pszPushType, pushThreshold, frequency);
			}
			pKeyItem = pKeyItem->next; //! next
		}
	} //# for each json array item
	// just null the pointer
	pJSONConfig = NULL;
	if (!gotDeviceTime)
	{
		int propIdx = -1;
		ListEntry *pItem = pResultList->first;
		while (pItem)
		{
			ExtPropertyDef *pPropertyDef = (ExtPropertyDef *)pItem->value;
			if (pPropertyDef != NULL && pPropertyDef->definition != NULL)
			{
				propIdx = max(pPropertyDef->index, propIdx);
			}
			pItem = pItem->next;
		} //# while got items
		propIdx++;
		AppendToModbusPropertyInfoList(&pResultList, "device_time", "", propIdx, TW_DATETIME,
									   TW_PUSH_TYPE_ALWAYS, TW_PUSH_THRESHOLD_NONE, 5);
	}
	return pResultList;
} //> RetrieveExternalPropertyListInfo()
//> ---------------------------------------------------------------------------

propertyList *ParseBufferedDataToPropertyList(void)
{
	// The tag parser configuration file can be read & parsed once when needed
	// so only on known file change (startup, registration, forced updated, scm)
	// additional check might be needed for timestamp, so if the file was last
	// time read one hour ago - read & parse it again. Also check for file's
	// modification time (via stat).
	propertyList *pResultList = NULL;
	DATETIME acqTimestamp = twGetSystemTime(TRUE);
	int _cntBytes = 0;
	cJSON *pInnerTag = NULL;
	cJSON *pNameItem = NULL;
	cJSON *pArrayItem = NULL;
	cJSON *pKeyItem = NULL;
	cJSON *pJSONConfig = ReadAndCacheTagParserConfigFile(false); // retrieve the config
	if (!pJSONConfig)
	{
		GsAppLog(GS_ERROR, MODULE_GS_DATA, "Unable to parse the accumulated data - Tag Parser information is missing!");
		return NULL; // error messages are already printed
	}
	_cntBytes = sizeof(char) * strlen(s_strDataBuffer) + 1;
	char *pInput = (char *)TW_MALLOC(_cntBytes);
	memset(pInput, 0, _cntBytes);
	strcpy(pInput, s_strDataBuffer);
	char **tempStrings = (char **)TW_CALLOC(count(pInput, '|') + 1, sizeof(char *));
	int countCommas = count(pInput, ',');
	// for now hold on to property names (need more info further on)
	_cntBytes = sizeof(char *) * (countCommas + 1);
	char **propertyNames = (char **)TW_MALLOC(_cntBytes);
	memset(propertyNames, 0, _cntBytes);
	int propertyCount = 0;
	int numSplitParts = 0;
	int numArrayItems = 0;
	int propertyIdx = 0;
	char pszSlaveId[16];
	memset(pszSlaveId, 0, 16);
	char *pszSplitPart = NULL;
	char *pszPropertyName = NULL;
	char *temp = strtok(pInput, "|");
	while (temp)
	{
		_cntBytes = sizeof(char) * (strlen(temp) + 1);
		tempStrings[numSplitParts] = (char *)TW_MALLOC(_cntBytes);
		memset(tempStrings[numSplitParts], 0, _cntBytes);
		strcpy(tempStrings[numSplitParts], temp);
		temp = strtok(NULL, "|");
		numSplitParts++;
	} //# for each split pattern
	_cntBytes = sizeof(char *) * (countCommas + 1);
	// >> |1,6000036,6100036,6000034|2,5.5,96,0,5
	pInnerTag = GsVerifyJSONContent(pJSONConfig, "slave_id");
	numArrayItems = cJSON_GetArraySize(pInnerTag);
	for (int aIdx = 0; aIdx < numArrayItems; aIdx++)
	{
		pArrayItem = cJSON_GetArrayItem(pInnerTag, aIdx);
		if (!pArrayItem)
			break; // skip!
		// search only for id / name mapping
		//
		pKeyItem = pArrayItem->child;
		while (pKeyItem)
		{
			if (strcasecmp(pKeyItem->string, "id") == 0)
			{
				pKeyItem = pKeyItem->next; //! next
				// skip the rest now
				continue;
			}
			if (pKeyItem->type != cJSON_String && pKeyItem->type != cJSON_Object)
			{
				pKeyItem = pKeyItem->next; //! next
				continue;
			}
			// Property name is in item -> valuestring
			int cIdx = 0;
			while (isdigit(pKeyItem->string[cIdx]))
				++cIdx;
			if (cIdx == strlen(pKeyItem->string))
			{
				if (pKeyItem->type == cJSON_String)
				{
					propertyNames[atoi(pKeyItem->string) - 1] = pKeyItem->valuestring;
				}
				else if (pKeyItem->type == cJSON_Object)
				{
					pNameItem = cJSON_GetObjectItem(pKeyItem, "name");
					if (pNameItem != NULL && pNameItem->type == cJSON_String)
					{
						//printf("Adding property name: '%s'[%d]\n", pNameItem->valuestring, atoi(pKeyItem->string) - 1);
						propertyNames[atoi(pKeyItem->string) - 1] = pNameItem->valuestring;
					}
				}
				propertyCount++;
			}
			pKeyItem = pKeyItem->next; //! next
		}
		// search for 'id' key to split over
		//
		pKeyItem = pArrayItem->child;
		while (pKeyItem)
		{
			if (strcasecmp(pKeyItem->string, "id") == 0)
			{
				// slaveId is stored directly in 'id' prop
				const int slaveId = atoi(pKeyItem->valuestring);
				sprintf(pszSlaveId, "%d,", slaveId);
				propertyIdx = 0;
				for (int splitIdx = 0; splitIdx < numSplitParts; splitIdx++)
				{
					pszSplitPart = tempStrings[splitIdx];
					if (strstr(pszSplitPart, pszSlaveId) == NULL)
					{
						continue;
					}
					pszSplitPart = delChars(pszSplitPart, 0, strlen(pszSlaveId));
					temp = strtok(pszSplitPart, ",");
					while (temp)
					{
						pszPropertyName = NULL;
						if (propertyIdx < countCommas + 1)
							pszPropertyName = propertyNames[propertyIdx];
						if (pszPropertyName && strcmp(pszPropertyName, "") != 0)
						{
							ExtPropertyDef *pPropertyDef = GetExtPropertyDefByName(pszPropertyName);
							if (pPropertyDef != NULL)
							{
								if (acqTimestamp - pPropertyDef->lastUpdateTs > pPropertyDef->frequency * 1000 && pPropertyDef->frequency != 0)
								{
									pPropertyDef->lastUpdateTs = acqTimestamp;
									GsAppLog(GS_DEBUG, MODULE_GS_DATA, "Scanned Modbus property: [%d] %s = '%s'", propertyIdx + 1, pszPropertyName, temp);
									if (strcmp(pszPropertyName, "device_time") != 0)
									{
										AppendToRemotePropertyList(&pResultList, pszPropertyName,
																   twPrimitive_CreateFromNumber(atof(temp)), acqTimestamp);
									}
								}
							}
							else
							{
								//? ignore
							}
						}
						propertyIdx++;
						temp = strtok(NULL, ",");
					} //# for each split value token
					break;
				} //# for each split portion
				// reset property names holder (what about type?!)
				memset(propertyNames, 0, _cntBytes);
				propertyCount = 0;
				break;
			} //? got id key
			//! next
			pKeyItem = pKeyItem->next;
		}
	} //# for each json array item
	TW_FREE(pInput);
	TW_FREE(propertyNames);
	for (int idx = 0; idx < numSplitParts; idx++)
		TW_FREE(tempStrings[idx]);
	TW_FREE(tempStrings);
	AppendToRemotePropertyList(&pResultList, "device_time",
							   twPrimitive_CreateFromDatetime(g_deviceDateTime), acqTimestamp);
	return pResultList;
} //> ParseBufferedDataToPropertyList(...)
//> ---------------------------------------------------------------------------

void ParseData(char *position, char *type, char *byteorder, int queryNum, char *multi_factor)
{
	int length = 0;
	int sType = atoi(type);
	int pos = atoi(position);
	switch (sType)
	{
	case Double:
		break;
	case EightByteHex:
		break;
	case EightWord:
		break;
	case Float:
		break;
	case FourByteHex:
		break;
	case OneByteHex:
		break;
	case SignedInt:
		length = 2;
		break;
	case SignedLong:
		break;
	case SixteenWord:
		break;
	case TwentyFourWord:
		break;
	case TwoByteHex:
		break;
	case UnSignedLong:
		length = 4;
		break;
	case UnsignedInt:
		length = 2;
		break;
	}
	memset(s_strIterimValue, 0, EXT_STR_VALUE_MAX_SIZE);
	for (int idx = 0; idx < 4; idx++)
	{
		memset(s_interimValueData[idx], 0, EXT_STR_SUBVAL_MAX_SIZE);
	}
	for (int idx = pos; idx < pos + length; idx++)
	{
		strcpy(s_interimValueData[idx - pos], g_dataConfig->rawData[queryNum - 1].dataArray[idx]);
	}
	////LE_INFO("strData: %s", strdata[0].c_str());
	//printf("\n%s,%s,%d,%s", byteorder, s_interimValueData[3], length, multi_factor);
	// comma is also appended here
	char *valueRecv = computeByteOrder(byteorder, s_interimValueData, length, multi_factor);
	if (s_bIsModbusSimulated)
	{
		sprintf(valueRecv, "%.2f,", (float)(rand() % 1000) / 10.0f + 25.0f * (pos % 10));
	}
	const int slaveId = g_dataConfig->queries[queryNum - 1].slaveId;
	if (g_prevSlaveId != slaveId)
	{
		// remove the last comma, to add vert line
		delChars(s_strDataBuffer, strlen(s_strDataBuffer) - 1, 1);
		sprintf(s_strIterimValue, "|%d,%s", slaveId, valueRecv);
	}
	else
	{
		// append the value directly
		strcat(s_strIterimValue, valueRecv);
	}
	g_prevSlaveId = slaveId;
	strcat(s_strDataBuffer, s_strIterimValue);
	TW_FREE(valueRecv);
} //> ParseData(...)
//> ---------------------------------------------------------------------------

void AccumulateData(int freq, int modConfig)
{
	//LE_INFO("modConfig: %d", modConfig);
	//	std::string fileName = "mod_conf_T";
	//	fileName += std::to_string(modConfig+1);
	//	fileName += "_";
	//	struct tm  ts;
	//	char buf[80];
	//	ts = *localtime(&timeclk.sec);
	//	strftime(buf, sizeof(buf), "%Y%m%d", &ts);
	//	std::string dateString(buf);
	//	fileName += dateString;
	char frequencyStr[16];
	memset(frequencyStr, 0, 16);
	itoa(freq, frequencyStr, 10);
	//?
	//?
	// can use directly the data stored in g_dataConfig->modbusConfigs[0].modbusQueries[0].dataBits[30]
	// contains the same values as in timerData - not as string, but in struct and per config/query
	for (int tdIdx = 0; tdIdx < g_dataConfig->numTimers; tdIdx++)
	{
		DataMap *pTimerData = &(g_dataConfig->timerData[tdIdx]);
		if (strcmp(pTimerData->key, frequencyStr) != 0)
		{
			continue;
		}
		int bufferSize = sizeof(char) * (strlen(pTimerData->value) + 2);
		char *strQueryStream = (char *)TW_MALLOC(bufferSize);
		char *strQueryStream2 = strQueryStream;
		memset(strQueryStream, 0, bufferSize);
		strcpy(strQueryStream, pTimerData->value);
		char *strPos = (char *)TW_MALLOC(bufferSize);
		memset(strPos, 0, bufferSize);
		char *strType = (char *)TW_MALLOC(bufferSize);
		memset(strType, 0, bufferSize);
		char *strByte = (char *)TW_MALLOC(bufferSize);
		memset(strByte, 0, bufferSize);
		char *strQueryNum = (char *)TW_MALLOC(bufferSize);
		memset(strQueryNum, 0, bufferSize);
		char *strMultiFactor = (char *)TW_MALLOC(bufferSize);
		memset(strMultiFactor, 0, bufferSize);
		strQueryStream = strtok(strQueryStream, ",");
		for (int tc = 1; tc <= 5; tc++)
		{
			if (strQueryStream == NULL)
				strQueryStream = "";
			if (tc == 1)
			{
				strcpy(strQueryNum, strQueryStream);
			}
			else if (tc == 2)
			{
				strcpy(strPos, strQueryStream);
			}
			else if (tc == 3)
			{
				strcpy(strType, strQueryStream);
			}
			else if (tc == 4)
			{
				strcpy(strByte, strQueryStream);
			}
			else if (tc == 5)
			{
				strcpy(strMultiFactor, strQueryStream);
			}
			strQueryStream = strtok(NULL, ",");
		}
		//LE_INFO("\n%s,%s,%s,%s,%s,%s", strQueryNum, strPos, strType, strByte, strPers, strMultiFactor);
		ParseData(strPos, strType, strByte, atoi(strQueryNum), strMultiFactor);
		TW_FREE(strQueryStream2);
		TW_FREE(strPos);
		TW_FREE(strType);
		TW_FREE(strByte);
		TW_FREE(strQueryNum);
		TW_FREE(strMultiFactor);
	} //# for each timer data
} //> AccumulateData(...)
//> ---------------------------------------------------------------------------

GS_BOOL SendRequest(int slaveId, int function, int addr1, int addr2, int length, int checksum, int queryNum)
{
#if defined(LEGATO)
	unsigned char sendBuffer[8];
	sendBuffer[0] = slaveId;
	sendBuffer[1] = function;
	sendBuffer[2] = addr1;
	sendBuffer[3] = addr2;
	sendBuffer[4] = 0;
	sendBuffer[5] = length;
	sendBuffer[6] = 128;
	sendBuffer[7] = 225;
	GsAppLog(GS_TRACE, MODULE_GS_DATA, "SendRequest: slaveId='%d' address='%x %x' length='%d' query='%d'",
			 slaveId, addr1, addr2, length, queryNum);
	int dataLen = length * 2 + 5;
	executeGPIOConfig(gpioHigh);
	executeGPIOConfig(gpioNeuHigh);
	SendBuf(g_fdComPort, (const char *)sendBuffer, sizeof(sendBuffer), dataLen, queryNum);
	usleep(10000);
	executeGPIOConfig(gpioLow);
	usleep(350000);
	ssize_t bytesRead = ModbusRead(g_fdComPort, dataLen, queryNum);
	executeGPIOConfig(gpioNeuLow);
	usleep(50000);
	return (bytesRead >= dataLen); // fail if not enough bytes read?
#else
	return TRUE;
#endif // LEGATO
} //> SendRequest(...)
//> ---------------------------------------------------------------------------

propertyList *ReadModbusData(void)
{
	GS_BOOL status = TRUE;
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "Attempting to read data from Modbus...");
	memset(s_strDataBuffer, 0, EXT_STR_BUFFER_SIZE);
#if defined(LEGATO)
	if (!s_bIsModbusSimulated)
	{
		char *addr1 = "";
		char *addr2 = "";
		int address1, address2;
		//int queryCnt = Queries[0].QueryCount;
		const int numQueries = g_dataConfig->numQueries;
		for (int qIdx = 0; qIdx < numQueries; qIdx++)
		{
			DataQuery *pQuery = &(g_dataConfig->queries[qIdx]);
			int hex_addr = pQuery->startAddress;
			hex_addr -= 1;
			int n = snprintf(NULL, 0, "%x", hex_addr);
			char *hexAddress = (char *)TW_MALLOC(sizeof(char) * (n + 1));
			memset(hexAddress, 0, n + 1);
			sprintf(hexAddress, "%x", hex_addr);
			addr1 = subStr(hexAddress, 0, 2);
			addr2 = subStr(hexAddress, 2, 2);
			TW_FREE(hexAddress);
			address1 = strtol(addr1, 0, 16);
			address2 = strtol(addr2, 0, 16);
			status = SendRequest(pQuery->slaveId, pQuery->function, address1, address2, pQuery->length, pQuery->checkSum, qIdx);
			if (!status)
			{
				GsAppLog(GS_ERROR, MODULE_GS_DATA, "Not enough bytes read from id='%d' address='%x %x' query='%d'. Ignoring retrieved data.",
						 pQuery->slaveId, address1, address2, qIdx);
				break;
			}
		} //# for each query
		if (!status)
		{
			return NULL;
		}
		for (int cfgIdx = 0; cfgIdx < g_dataConfig->numConfigs; cfgIdx++)
		{
			AccumulateData(g_dataConfig->modbusConfigs[cfgIdx].frequency, cfgIdx);
		} //# for each modbus config
	}
#else
	for (int cfgIdx = 0; cfgIdx < g_dataConfig->numConfigs; cfgIdx++)
	{
		AccumulateData(g_dataConfig->modbusConfigs[cfgIdx].frequency, cfgIdx);
	} //# for each modbus config
#endif // LEGATO
	// removes the extra comma from ParseData->computeByteOrder
	delChars(s_strDataBuffer, strlen(s_strDataBuffer) - 1, 1);
	// propertyList is a newly generated twList with multiple elements
	// it has to be freed on demand when not needed anymore
	propertyList *pPropertyList = ParseBufferedDataToPropertyList();
	g_prevSlaveId = -1;
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "Received & parsed string buffer: '%s'", s_strDataBuffer);
	memset(s_strDataBuffer, 0, EXT_STR_BUFFER_SIZE);
	return pPropertyList;
} //> ReadModbusData()
//> ---------------------------------------------------------------------------

void ExtDataAcquisition_ReadConfiguration()
{
	char strLine[EXT_STR_LINE_SIZE];
	char *pszConfigFilePath = GetFilePathInAgentHome(MODBUS_CONFIG_FOLDER_NAME, STR_MODBUS_CONFIG_FILENAME);
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "Reading in Data Acquisition configuration file at: '%s'", pszConfigFilePath);
	FILE *configFile = fopen(pszConfigFilePath, "r");
	TW_FREE(pszConfigFilePath); // #FIXME
	if (!configFile)
	{
		return; // skip;
	}
	char *tagName = NULL;
	char *strTemp = NULL;
	char *dataStr = NULL;
	char issx[EXT_STR_LINE_SIZE], *iss2;
	char strSplitx[EXT_STR_LINE_SIZE], *strSplit2;
	char issQueryNox[EXT_STR_LINE_SIZE];
	char strDtx[EXT_STR_LINE_SIZE];
	int curConfigIdx = 0;
	int curQueryIdx = 0;
	int tCnt = 0;
	int numLines = 0;
	int queryCount = 0, cfgCount = 0, timerDataCount = 0;
	// Need to change this condition and Query structure loading
	// to make it work with multiple config file reads. Reading
	// modbus config file again should properly reset queries.
	while (!feof(configFile))
	{
		memset(strLine, 0, EXT_STR_LINE_SIZE);
		fscanf(configFile, "%[^\n]\n", strLine);
		if (strstr(strLine, "mod_conf") != NULL)
			timerDataCount = timerDataCount + count(strLine, '&') + count(strLine, '|') + 1;
		if (strstr(strLine, "Query") != NULL)
		{
			queryCount++;
		}
		if (strstr(strLine, "mod_conf") != NULL)
		{
			cfgCount++;
		}
		numLines++;
		// remove preserved pointer (avoid strtok shadow)
	} //# while not end of file
	fseek(configFile, 0, SEEK_SET);
	// this will free any already existing data (deep removal)
	// any existing data will be lost
	PrepareDataAcquisitionConfig(queryCount, cfgCount, timerDataCount);
	for (int lineIdx = 0; lineIdx < numLines; lineIdx++)
	{
		memset(strLine, 0, EXT_STR_LINE_SIZE);
		memset(issx, 0, EXT_STR_LINE_SIZE);
		fscanf(configFile, "%[^\n]\n", strLine);
		puts(strLine); // debug #FIXME
		delChars(strLine, 0, 1);
		delChars(strLine, strlen(strLine) - 1, 1);

		strcpy(issx, strLine);
		iss2 = issx;

		tagName = strtok(iss2, ":");
		iss2 = strtok(NULL, "");
		if (strcmp(tagName, "ComPort") == 0)
		{
			iss2 = strtok(iss2, ",");
			for (int tc = 1; tc <= 5; tc++)
			{
				if (iss2 == NULL)
					iss2 = "";
				if (tc == 1)
				{
					strcpy(g_dataComInfo.PortName, iss2);
				}
				else if (tc == 2)
				{
					g_dataComInfo.BaudRate = atoi(iss2);
				}
				else if (tc == 3)
				{
					g_dataComInfo.dataBits = atoi(iss2);
				}
				else if (tc == 4)
				{
					strcpy(g_dataComInfo.Parity, iss2);
				}
				else if (tc == 5)
				{
					g_dataComInfo.stopBits = atoi(iss2);
				}
				iss2 = strtok(NULL, ",");
			} //# for each token
		}
		else if (strstr(tagName, "Query") != NULL)
		{
			if (curQueryIdx < g_dataConfig->numQueries)
			{
				DataQuery *pQuery = &(g_dataConfig->queries[curQueryIdx]);
				strTemp = strtok(iss2, "@");
				iss2 = strtok(NULL, "");
				pQuery->queryNum = atoi(strTemp); //stoi
				strTemp = strtok(iss2, ">");
				iss2 = strtok(NULL, "");
				memset(strSplitx, 0, EXT_STR_LINE_SIZE);
				strcpy(strSplitx, strTemp);
				strSplit2 = strtok(strSplitx, ",");
				for (int tc = 1; tc <= 5; tc++)
				{
					if (strSplit2 == NULL)
						strSplit2 = "";
					if (tc == 1)
					{
						pQuery->slaveId = atoi(strSplit2);
					}
					else if (tc == 2)
					{
						pQuery->function = atoi(strSplit2);
					}
					else if (tc == 3)
					{
						pQuery->startAddress = atoi(strSplit2);
					}
					else if (tc == 4)
					{
						pQuery->length = atoi(strSplit2);
					}
					else if (tc == 5)
					{
						pQuery->checkSum = atoi(strSplit2);
					}
					strSplit2 = strtok(NULL, ",");
				} //# for each token
				pQuery->queryCount = queryCount;
				curQueryIdx++;
			} //? can add more queries
		}
		else if (strstr(tagName, "mod_conf") != NULL)
		{
			if (curConfigIdx < g_dataConfig->numConfigs)
			{
				ModbusConfig *pModbusConfig = &(g_dataConfig->modbusConfigs[curConfigIdx]);
				strTemp = strtok(iss2, "@");
				iss2 = strtok(NULL, "");
				memset(strSplitx, 0, EXT_STR_LINE_SIZE);
				strcpy(strSplitx, strTemp);
				pModbusConfig->frequency = atoi(strtok(strSplitx, ","));
				pModbusConfig->interval = atoi(strtok(NULL, ","));
				pModbusConfig->numQueries = count(strLine, '|') + 1;
				pModbusConfig->modbusQueries = (ModbusQuery *)TW_MALLOC(sizeof(ModbusQuery) * pModbusConfig->numQueries);
				memset(pModbusConfig->modbusQueries, 0, sizeof(ModbusQuery) * pModbusConfig->numQueries);
				for (int mqIdx = 0; mqIdx < pModbusConfig->numQueries; mqIdx++)
				{
					ModbusQuery *pModbusQuery = &(pModbusConfig->modbusQueries[mqIdx]);
					strTemp = strtok(iss2, "|");
					iss2 = strtok(NULL, "");
					dataStr = strTemp;
					memset(issQueryNox, 0, EXT_STR_LINE_SIZE);
					strcpy(issQueryNox, dataStr);
					char *strQueryNo = strtok(issQueryNox, "*");
					pModbusQuery->queryNum = atoi(strQueryNo);
					pModbusQuery->numDataBits = count(dataStr, '&') + 1;
					pModbusQuery->dataBits = (ModbusDataBits *)TW_MALLOC(sizeof(ModbusDataBits) * pModbusQuery->numDataBits);
					memset(pModbusQuery->dataBits, 0, sizeof(ModbusDataBits) * pModbusQuery->numDataBits);

					dataStr = strtok(dataStr, "*");
					dataStr = strtok(NULL, "");
					memset(strDtx, 0, EXT_STR_LINE_SIZE);
					strcpy(strDtx, dataStr);
					char *strDt = strtok(strDtx, "&");
					char **tempStrings = (char **)TW_MALLOC(pModbusQuery->numDataBits * sizeof(char *));
					for (int ts = 0; ts < pModbusQuery->numDataBits; ts++)
					{
						tempStrings[ts] = (char *)TW_MALLOC(sizeof(char) * 32);
						memset(tempStrings[ts], 0, 32);
					}
					int tc = 0;
					while (strDt)
					{
						strcpy(tempStrings[tc++], strDt);
						strDt = strtok(NULL, "&");
					}
					tc = 0;
					for (int dbIdx = 0; dbIdx < pModbusQuery->numDataBits; dbIdx++)
					{
						ModbusDataBits *pDataBits = &(pModbusQuery->dataBits[dbIdx]);
						pDataBits->queryNum = pModbusQuery->queryNum;
						char *strDt_ = strtok(tempStrings[dbIdx], ",");
						for (int tc = 1; tc <= 5; tc++)
						{
							if (strDt_ == NULL)
								strDt_ = "";
							int iStrDt_val = atoi(strDt_);
							if (tc == 1)
							{
								pDataBits->Position = iStrDt_val;
							}
							else if (tc == 2)
							{
								pDataBits->Type = iStrDt_val;
							}
							else if (tc == 3)
							{
								pDataBits->ByteOrder = iStrDt_val;
							}
							else if (tc == 4)
							{
								pDataBits->Multi_Factor = atof(strDt_);
							}
							strDt_ = strtok(NULL, ",");
						} //# for each data bit token
						tc = 0;

						DataMap *pTimerData = &(g_dataConfig->timerData[tCnt]);
						sprintf(pTimerData->key, "%d", pModbusConfig->frequency);
						sprintf(pTimerData->value, "%d%s%d%s%d%s%d%s%.4f",
								pDataBits->queryNum, ",",
								pDataBits->Position, ",",
								pDataBits->Type, ",",
								pDataBits->ByteOrder, ",",
								pDataBits->Multi_Factor);
						puts(pTimerData->value); //debug
						++tCnt;
					} //# for each data bit
					for (int ts = 0; ts < pModbusQuery->numDataBits; ts++)
					{
						memset(tempStrings[ts], 0, 32);
						TW_FREE(tempStrings[ts]);
					}
					TW_FREE(tempStrings);
				} //# for each modbus query
			}
			for (int qIdx = 0; qIdx < g_dataConfig->numQueries; qIdx++)
			{
				g_dataConfig->queries[qIdx].queryStatus = false;
			} //# for each query
			curConfigIdx++;
		} //? mod_conf
		  // free preserved pointer
	}	  //# for each file line
	fclose(configFile);
} //> ExtDataAcquisition_ReadConfiguration()
//> ---------------------------------------------------------------------------

void ExtDataAcquisition_Initialize()
{
	GsAppLog(GS_INFO, MODULE_GS_DATA, "Initializing external (Modbus) Data Acquisition Subsystem");
	if (!s_pszTagParserFilePath)
	{
		s_pszTagParserFilePath = GetFilePathInAgentHome(MODBUS_CONFIG_FOLDER_NAME, STR_TAG_PARSER_CONFIG_FILENAME);
		GsAppLog(GS_INFO, MODULE_GS_DATA, "Internal Tag Parser file assumed to be at: '%s'", STR_TAG_PARSER_CONFIG_FILENAME);
	}
#if defined(LEGATO)
	executeGPIOConfig(gpioGreenExport);
	executeGPIOConfig(gpioGreenDirectionset);
	executeGPIOConfig(gpioGreenHigh);

	executeGPIOConfig(gpioRedExport);
	executeGPIOConfig(gpioRedDirectionset);

	executeGPIOConfig(gpioExport);
	executeGPIOConfig(gpioDirectionset);
	executeGPIOConfig(gpioHigh);

	executeGPIOConfig(gpioNeuExport);
	executeGPIOConfig(gpioNeuDirectionset);

	ExtDataAcquisition_ReadConfiguration();

	// Open the serial port.
	CloseComport(0);
	g_fdComPort = OpenComport(0, g_dataComInfo.BaudRate); //9600
	//LE_FATAL_IF(g_fdComPort != 0, "open failed with errno %d (%m)", errno);

	if (g_fdComPort == 0)
	{
		//LE_INFO("Device Opened");
	}
#else
	s_bIsModbusSimulated = TRUE;
	ExtDataAcquisition_ReadConfiguration();
#endif // LEGATO

	g_pDataExtThreadStruct = GsCreateThreadStruct();
	g_pDataExtThreadStruct->m_waitMilliSec = g_acquisitionRate;
} //> ExtDataAcquisition_Initialize()
//> ---------------------------------------------------------------------------

void ExtDataAcquisition_Start()
{
	g_pExtPropertyInfoList = RetrieveExternalPropertyListInfo();
	if (!g_pExtPropertyInfoList)
	{
		GsAppLog(GS_ERROR, MODULE_GS_DATA, "Retrieved an empty Modbus property list on start.");
	}
	else
	{
		RegisterModbusExtProperties(g_pExtPropertyInfoList);
	}
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "ExtDataAcquisition:  Initiate start of thread");
	GsStartThread(g_pDataExtThreadStruct, DataExtThreadFunction);
} //> ExtDataAcquisition_Start()
//> ---------------------------------------------------------------------------

void ExtDataAcquisition_Shutdown()
{
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "ExtDataAcquisition:  Initiate shutdown");
	if (!g_pExtPropertyInfoList)
		g_pExtPropertyInfoList = RetrieveExternalPropertyListInfo();
	if (g_pExtPropertyInfoList != NULL)
	{
		UnregisterModbusExtProperties(g_pExtPropertyInfoList);
		twList_Delete(g_pExtPropertyInfoList);
	}
	TW_FREE(s_pszTagParserFilePath);
	s_pszTagParserFilePath = NULL;
	if (s_tagParserJSONConfig)
	{
		cJSON_Delete(s_tagParserJSONConfig);
		s_tagParserJSONConfig = NULL;
	}
	DeleteDataAcquisitionConfig(); // cleanup config
	s_tagParserLastReadTime = 0;   // reset
	GsStopThread(g_pDataExtThreadStruct);
	GsDestroyThreadStruct(g_pDataExtThreadStruct);
	GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME, "ExtDataAcquisition:  shutdown complete");
} //> ExtDataAcquisition_Shutdown()
//> ---------------------------------------------------------------------------

void ExtDataAcquisition_ReadMachineDetailsNumbers()
{
// 01 03 13 00 00 02 C0 8F
#if defined(LEGATO)
	unsigned char sendBuffer[8];
	sendBuffer[0] = 0x01;
	sendBuffer[1] = 0x03;
	sendBuffer[2] = 0x13;
	sendBuffer[3] = 0x00;
	sendBuffer[4] = 0x00;
	sendBuffer[5] = 0x02;
	sendBuffer[6] = 0xC0; // 192
	sendBuffer[7] = 0x8F; // 143
	int dataLen = 4;
	usleep(2000000);
	tcflush(g_fdComPort, TCIOFLUSH);
	SendFrame(g_fdComPort, (const char *)sendBuffer, (int)sizeof(sendBuffer));
	usleep(100000);
	executeGPIOConfig(gpioLow);
	usleep(350000);
	uint8_t *strBuffer = (uint8_t *)GsStringDup(ModbusRead_SingleDataString(g_fdComPort, dataLen));
	uint16_t machineDetails_1 = (uint16_t)strBuffer[0] | (uint16_t)strBuffer[1] << 8;
	uint16_t machineDetails_2 = (uint16_t)strBuffer[2] | (uint16_t)strBuffer[2] << 8;
	GsAppLog(GS_INFO, MODULE_GS_DATA, "Retrieved Machine Details: %d / %d", (int)machineDetails_1, (int)machineDetails_2);
	TW_FREE(strBuffer);
#endif
} //> ExtDataAcquisition_ReadMachineDetailsNumbers()
//> ---------------------------------------------------------------------------

void ExtDataAcquisition_ReadAndUpdateSignalStrength()
{
#if defined(LEGATO)
	uint32_t quality = 0;
	le_result_t res = le_mrc_GetSignalQual(&quality);
	if (res == LE_OK)
	{
		if (quality > 3)
		{
			executeGPIOConfig(gpioGreenHigh);
			executeGPIOConfig(gpioRedLow);
		}
		else if (quality < 3)
		{
			executeGPIOConfig(gpioGreenLow);
			executeGPIOConfig(gpioRedHigh);
		}
		else
		{
			executeGPIOConfig(gpioGreenHigh);
			executeGPIOConfig(gpioRedHigh);
		}
		GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ExtDataAcquisition: Signal quality: %d", quality);
	}
#endif // LEGATO
} //> ExtDataAcquisition_ReadAndUpdateSignalStrength()

// *****************************************************************************
// Thread to manage all External Data Acquisition.
//
THREAD_FUNCTION_RETURN DataExtThreadFunction(void *pVoid)
{
	int seedIx = 0;
	int waitReturnCondition = WAIT_OBJECT_0;
	GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid; // The void* parameter is always the thread struct pointer
	if (!pGsThreadStruct)
	{
		GsAppLog(GS_ERROR, MODULE_GS_DATA, "ExtDataAcquisition:  Thread initialiation error.  Exiting thread.");
		return (THREAD_FUNCTION_RETURN)-1;
	}
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "ExtDataAcquisition:  Thread started.  Thread id = %x (hex)", pGsThreadStruct->m_threadId);
#if defined(LEGATO)
	le_thread_InitLegatoThreadData("ExtDataAcquisition");
#endif // LEGATO
	// while bRunning, continues to run
	while (pGsThreadStruct->m_bRunning)
	{
		unsigned long loopTime = 0;
		unsigned long waitTime = 0; // init to no wait.
		// Wait for signal or timeout for the next acquisition scan.
		waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);
		GsAppLog(GS_TRACE, MODULE_GS_DATA, "ExtDataAcquisition: %s running(%s)",
				 (waitReturnCondition == WAIT_OBJECT_0 ? "Signal received." : "Thread wakup due to timeout."),
				 (pGsThreadStruct->m_bRunning ? "true" : "false"));
		if (!pGsThreadStruct->m_bRunning)
			break;
		g_dataExtWakeupTime = twGetSystemTime(TRUE);

		DATETIME dt = Get_RTC_TIME();

		// This function will exit immediately if ReadModbusData returns NULL
		DataPublishingMgr_PublishProperties(ReadModbusData(), FALSE);

		// Calculate the total time within the acquisition loop.
		loopTime = (unsigned long)(twGetSystemTime(TRUE) - g_dataExtWakeupTime);
		if (loopTime < g_acquisitionRate)
			waitTime = g_acquisitionRate - loopTime;
		g_pDataExtThreadStruct->m_waitMilliSec = waitTime;
		ExtDataAcquisition_ReadAndUpdateSignalStrength();
	} //# while loop is running
	GsAppLog(GS_DEBUG, MODULE_GS_DATA, "ExtDataAcquisition:  extiting thread");
#if defined(LEGATO)
	le_thread_CleanupLegatoThreadData();
#endif // LEGATO
	return 0;
} //> DataExtThreadFunction()
//> ---------------------------------------------------------------------------

GS_BOOL ExtDataAcquisition_ValidateFabNumber(char *pszFabNumber)
{
	if (!pszFabNumber)
	{
		GsAppLog(GS_ERROR, MODULE_GS_DATA, "Received invalid Fab Number (null).");
		return FALSE;
	}
	if (!pszFabNumber[0])
	{
		GsAppLog(GS_ERROR, MODULE_GS_DATA, "Received empty Fab Number.");
		return FALSE;
	}
	int length = strnlen(pszFabNumber, 16);
	if (length != 10)
	{
		GsAppLog(GS_ERROR, MODULE_GS_DATA, "Received Fab Number of invalid length: %d.", length);
		return FALSE;
	}
	for (int idx = 0; idx < 10; idx++)
	{
		int c = (int)pszFabNumber[idx];
		// contains a char that is not alpha or digit
		if (!isalpha(c) && !isdigit(c))
		{
			GsAppLog(GS_ERROR, MODULE_GS_DATA, "Received Fab Number with invalid characters.");
			return FALSE;
		}
	} //# for each char
	  // no fail?
	return TRUE;
} //> ExtDataAcquisition_ValidateFabNumber(...)
//> ---------------------------------------------------------------------------

GS_BOOL ExtDataAcquisition_FetchFabNumber()
{
	char *fabNumber = NULL;
	if (!g_pszFabNumber)
		fabNumber = ReadFabNumberString();
	if (fabNumber)
	{
		g_bFabNumberValid = ExtDataAcquisition_ValidateFabNumber(fabNumber);
		SetFabNumber(fabNumber);
		TW_FREE(fabNumber);
		fabNumber = NULL;
	}
	return g_bFabNumberValid;
} //> ExtDataAcquisition_FetchFabNumber()
//> ---------------------------------------------------------------------------

void ExtDataAcquisition_FetchIdNumbers()
{
	GsAppLog(GS_INFO, MODULE_GS_DATA, "Fetching identification numbers...");
	ExtDataAcquisition_FetchFabNumber();
	char *imeiNumber = ReadDeviceIDString();
	if (imeiNumber)
	{
		SetImeiNumber(imeiNumber);
		TW_FREE(imeiNumber);
		imeiNumber = NULL;
	}
	GsAppLog(GS_INFO, MODULE_GS_DATA, "Received identification numbers: fabNumber='%s' imeiNumber='%s'", g_pszFabNumber, g_pszImeiNumber);
} //> ExtDataAcquisition_FetchIdNumbers()
//> ---------------------------------------------------------------------------
