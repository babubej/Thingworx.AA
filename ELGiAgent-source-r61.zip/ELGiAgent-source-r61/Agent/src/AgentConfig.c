
#include "AgentConfig.h"

char *g_pszAgentHomeDir = NULL;
char *g_pszDataLogsDir = NULL;

// This is a helper internal function to check and set the agent home directory
int SetAgentHomeDir(char *pszHomeDir)
{
    // This part of the code is before general configuration even took place (cannot use GsAppLog)
    if (pszHomeDir == NULL || strlen(pszHomeDir) == 0)
    {
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Agent initialization: provided home path is empty.");
        return -1;
    }
    if (twDirectory_FileExists(pszHomeDir) == FALSE)
    {
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Agent initialization: provided home path does not exist.");
        return -1;
    }
    if (g_pszAgentHomeDir != NULL)
        TW_FREE(g_pszAgentHomeDir);              // free the previous value!
    g_pszAgentHomeDir = GsStringDup(pszHomeDir); // store!
    return TW_OK;                                // success
} //> SetAgentHomeDir(...)
//>----------------------------------------------------------------------------

char *GetFilePathInAgentHome(char *pszSubFolderName, char *pszFileName)
{
    char *pszAbsoluteFilePath;
    char *pszCwd = NULL;
    char *pszAgentHomeDir = g_pszAgentHomeDir;
    if (pszAgentHomeDir == NULL)
    {
        pszCwd = GsGetCwd(); // fallback to CWD
        pszAgentHomeDir = pszCwd;
    }
    pszAbsoluteFilePath = GsAppendFolderNameToPath(pszAgentHomeDir, pszSubFolderName);
    if (pszFileName)
    {
        strcat(pszAbsoluteFilePath, TW_FILE_DELIM_STR);
        strcat(pszAbsoluteFilePath, pszFileName);
    }
    if (pszCwd)
        TW_FREE(pszCwd);
    return pszAbsoluteFilePath;
} //> GetFilePathInAgentHome(...)
//>----------------------------------------------------------------------------

// Initialize Agent Home directory path if not already set.
GS_BOOL InitializeAgentHomeDir(void)
{
    GS_BOOL status;
    if (g_pszAgentHomeDir == NULL || strlen(g_pszAgentHomeDir) == 0)
    {
        // This will be NULL if -home argument was not provided - try to extract the environment variable
        char *pszValue = GsGetEnvironmentVariable(STR_AGENT_HOME_ENV_VAR);
        if (pszValue != NULL)
        {
            status = (GS_BOOL)(SetAgentHomeDir(pszValue) != TW_OK);
            TW_FREE(pszValue);
            if (status)
            {
                GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "'%s' environment variable contains invalid path to Agent home directory.", STR_AGENT_HOME_ENV_VAR);
                return FALSE;
            }
        }
    } //? agent home dir empty
#if defined(LINUX) || defined(LEGATO)
    if (g_pszAgentHomeDir == NULL || strlen(g_pszAgentHomeDir) == 0)
    {
        SetAgentHomeDir(STR_AGENT_DEFAULT_HOME_PATH);
    }
#endif // LEGATO / LINUX
    if (g_pszAgentHomeDir == NULL || strlen(g_pszAgentHomeDir) == 0)
    {
        if (!GsIsPathAbsolute(g_pszProcessName))
        {
            char *pszCwd = GsGetCwd();
            // Agent was executed from different directory using relative path.
            // For example: ./bin/ELGiAgent - need to combine them for a complete path.
            char *pszRelativePath = GsGetPathPortion(g_pszProcessName);
            char *pszPathToUse = pszRelativePath;
            if (pszRelativePath[0] == '.' && pszRelativePath[1] == TW_FILE_DELIM)
                pszPathToUse += 2; // skip
            g_pszAgentHomeDir = GsAppendFolderNameToPath(pszCwd, pszPathToUse);
            TW_FREE(pszRelativePath);
            TW_FREE(pszCwd);
        }
        else
        {
            // Process name contains absolute path (can set Agent Home to this path)
            g_pszAgentHomeDir = GsGetPathPortion(g_pszProcessName); // current directory of executable
            // Last fallback, set as current working directory.
            // This will work only if the Agent exe was ran from this place (./ELGiAgent)
            //g_pszAgentHomeDir = pszCwd; // store it directly without string dup
        }
    } //? agent home dir still empty
    return TRUE;
} //> InitializeAgentHomeDir()
//>----------------------------------------------------------------------------
