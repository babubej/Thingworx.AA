/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   :  Initialization.c
//
//  Subsystem:  ELGiAgent
//
//  Description:  Implement the functions to start and initialize the ELGiAgent.
//          - Read configuration files
//          - Initialize logging, variables and SDK callbacks.
//          - Initialize SDK  
//          - Initialize Agent functional modules
//          - Start Agent modules (threads) responsible for processing SDK tasks.
//          - Connect with Thingworx Platform (via ConnectionMgr) and binding the agent as a "Thing"
//          - Start modules (threads) responsible for Data acquistion and publishing of properties
//
******************************************************************************/
#include "AgentConfig.h"
#include "twApiStubs.h"
#include "Initialization.h"
#include "FileMonitor.h"
#include "configParams.h"
#include "properties.h"
#include "API_Task.h"
#include "MessageThreadPoolMgr.h"
#include "DataSimulatorMgr.h"
#include "SCM_Task.h"
#include "twSwUpdateManager.h"
#include "DataPublishingMgr.h"
#include "ConnectionMgr.h"
#include "services.h"
#include "ExtDataAcquisition.h"
#include "DelayedTasksMgr.h"

// Function Prototypes fpr local functions
static int RetrieveThingIdentifierCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *content);
static void InitalizeShutdownHooks();
static int InitSecureConnection(); // return error on failure.
static int ConnectToTWPlatform_Initalize();
static int ConnectToTWPlatform_Start();
static void LogBanner();
static int SetupProxyServer();
static GS_BOOL InitializeGlobalVariables();
// return TW_OK if the Agent can access the ThingName.  This requires the Thing to be defined and assocatiated
// with the Thing Identifier via ThingWorx Composer.
static int LogServerThingName();

static GS_BOOL s_isPropertyValuesRead = FALSE;

// ****************************************************************************
// **************************    Global  Function    ***********************
// ****************************************************************************

int PreInitialize()
{
    // define the randomization seed.
    srand(twGetSystemTime(TRUE) % 10000);
    // This will also initialize Agent Home directory path based on environment variable.
    // That's why this has to be called before GsLog_ConfigureLogging() - which will read the
    // logging.json file in default ConfigFiles folder.
    if (!InitializeGlobalVariables())
        return !TW_OK; // force initialization error
    ExtDataAcquisition_Initialize();
    int err = TW_OK;
    InitalizeShutdownHooks();
    // This will load the logging configuration file and setup log settings for each module.
    GsLog_ConfigureLogging();
    LogBanner();
    // Read General configuraition files
    // This defines the global variable for the ThingName.
    err = ConfigSdkSettings();
    if (err)
        return err;
    //RetrieveExternalPropertyListInfo();
    ExtDataAcquisition_ReadMachineDetailsNumbers();
    ExtDataAcquisition_FetchIdNumbers();
    RefreshServerConfigurationFile(); // This will store Fab / Imei numbers if changed

    // Read all general configuration files.
    ReadGenericConfigFiles();
    return err;
} //> PreInitialize()

// ****************************************************************************
/* Initialize all modules */
int Initialize()
{
    DelayedTasks_Initialize();
    int err = TW_OK;
    err = ConnectToTWPlatform_Initalize();
    if (err)
        return err;
    // NOTE:  initialize is called AFTER configuration files are loaded.
    // Initialize the background threds that process messages and keep the connection alive.
    API_Task_Initialize();
    MessageThreadPoolMgr_Initialize();
    SCM_Task_Initialize();
    ConnectionMgr_Initialize();
    Services_Initialize();
    DataPublishingMgr_Initialize();
    // Before initializing, check if simulator is to be used.
    DataSimulatorMrg_ReadConfiguration();
    //if (g_bSimulatorEnabled)
    //{
    //    DataSimulatorMgr_Initialize();
    //}
    return err;
} //> Initialize()

// ****************************************************************************
// Start all modules
int Start()
{
    int err = TW_OK;
    int waitCounter = 0;
    DATETIME logNameTick = twGetSystemTime(TRUE);
    // start the TW API and message thread-pool task  1st.
    DelayedTasks_Start();
    API_Task_Start();
    MessageThreadPoolMgr_Start();
    SCM_Task_Start();
    ConnectionMgr_Start();
    err = ConnectToTWPlatform_Start();
    if (err != TW_OK)
        return err;
    // Start manager responsible for publishing error events.
    if (g_bEnableErrorEvents)
        ErrorEventMgr_Start();
    Services_Start();
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Communication messaging started");

    // Wait until the "Thing" instance at the ThingWorx Core has been bound to this Thing-Identifier before continuing.
    // Programmer Note:  This code needs to be modified if the app is managing multiple things.
    GsAppLog(GS_INFO, MODULE_GS_CONFIG, "Waiting for the ThingWorx Server 'Thing' name to be associated with the Agent's defined Thing Identifier before starting continuing...");
    // Get the actual Thing Name and log it for the record.
    LogServerThingName();
    while (!s_isPropertyValuesRead)
    {
        twSleepMsec(2500);
        if (twGetSystemTime(TRUE) - logNameTick > 2500)
        {
            if (!s_isPropertyValuesRead)
                LogServerThingName(); // try again
            logNameTick = twGetSystemTime(TRUE);
        }
        if (g_bReceivedShutdownSignal)
        {
            return TW_OK;
        }
    }
    // Have a short sleep while waiting for ThingWorx Platform <--> Agent initial handshacking to be completed.
    twSleepMsec(2500);
    // Check if the "Thing" defined in ThingWorx Composer has subscribed to property updates.
    // g_bServerHandshakingInitializationCompleted is set by the Synchronized State Callback when more than 0 properties are bound.
    if (!g_bServerHandshakingInitializationCompleted)
    {
        GsAppLog(GS_INFO, MODULE_GS_CONFIG, "Reminder:  You need to 'manage remote bindings' for your 'Thing' to receive the properties that are being published.");
    }
    // Start data acquistion and publishing.
    DataPublishingMgr_Start();
    //if (g_bSimulatorEnabled)
    //{
    //    DataSimulatorMgr_Start();
    //}
    GsAppLog(GS_FORCE, MODULE_GS_RUNTIME, "Initialization: data acquisition is started!");
    return err;
} //> Start()

// ****************************************************************************
// **************************    Support  Function    ***********************
// ****************************************************************************

// ****************************************************************************
int ConnectToTWPlatform_Initalize()
{
    int err = TW_OK;
    int16_t port = 0;
    char *pszHostName = NULL;
    port = GetThingWorxPort();
    pszHostName = GetThingWorxHostName();
    if (!pszHostName)
    {
        return GS_FAILED;
    }
    twcfg.enable_tls_hostname_validation = FALSE;
    // Log that we are about to connect.
    GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "Initialization: ConnectToTWPlatform_Initalize, connecting to %s using port: %i.", pszHostName, port);
    /* Initialize the API.
	   Note:  autoreconenct is 'disabled' because we manage that via the ConnectionMgr module.
	*/
    err = twApi_Initialize(pszHostName, port, TW_URI, GetAppKeyCallback, NULL,
                           twcfg.message_chunk_size, twcfg.message_chunk_size, FALSE);
    if (err)
    {
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Initialization: ConnectToTWPlatform_Initalize, error initializing the API");
        return (err);
    }
    // set proxy server if enabled
    SetupProxyServer();
    // Initialize secure conenction
    err = InitSecureConnection();
    // ******************
    // register callbacks
    // ******************
    // register to be notified when the ThingWorx Server and the edge has synchronized all registered properties.
    //twApi_RegisterSynchronizeStateEventCallback(g_pszThingIdentifier,
    //PushSubscribedPropertiesAsyncSynchronizeStateCallback, NULL);
    // Register the file transfer callback function. See fileWatcher.c
    twFileManager_RegisterFileCallback(OnFileCompleteCallbackFunc, NULL, FALSE, NULL);
    return err;
} //> ConnectToTWPlatform_Initalize()

// ****************************************************************************
void InitalizeShutdownHooks()
{
    GsInstallOSShutdownSignalHandler();
    GsInitializeShutdownEvent();
} //> InitalizeShutdownHooks()

// ****************************************************************************
int ConnectToTWPlatform_Start()
{
    int err = GS_FAILED;
    // This is blocking version - it will try to connect in place as long as possible
    // After that? It should resume normal initialization, but without
    // Connection to ThingWorx server is required to proceed.
    ConnectionStatus connectionStatus = ConnectionMgr_Connect(TRUE);
    if (connectionStatus == csFailed)
    {
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Initialization: ***Critical Failure:*** Could not connect to the ThingWorx Server.  Exiting...");
        ConnectionMgr_Disconnect(" "); // this disables 'auto-reconnect'.
        return GS_FAILED;
    }
    else if (connectionStatus == csAsyncRetry)
    {
        // In this case it will try to reconnect using the dedicated thread.
        // All of the other threads will start normally and at this point it will
        // proceed with data acquisition and offline cache.
        // If offline time limit is exceeded the agent will try to restart forcefully.
        GsAppLog(GS_WARN, MODULE_GS_CONFIG, "Initialization: *** Could not connect to the ThingWorx Server. Will retry in a separate thread.");
    }
    // Log if web socket compression was accepted by the server.
    GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "Initialization: Web Socket compression is %s",
             tw_api->mh->ws->bSupportsPermessageDeflate ? "in use." : "not in use.");
    return TW_OK;
} //> ConnectToTWPlatform_Start()

/*****************************************************************************
* Initializing the certification details
******************************************************************************/
int InitSecureConnection()
{
    int err = TW_OK;
    // check if FIPS mode is to be enabled.
    if (IsFIPSmodeEnabled())
    {
        int err = twApi_EnableFipsMode();
        if (err)
        {
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Error enabling FIPS mode.  Error code: %d", err);
            return err;
        }
    }
    // Use .pem CA (certificate authority) file if it exists
    if (GetPemFileName())
    {
        char *pszPEMFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, GetPemFileName());
        err = twApi_LoadCACert(pszPEMFilePath, 1);
        TW_FREE(pszPEMFilePath);
    }
    else
    {
        twApi_DisableCertValidation();
    }
    const int port = GetThingWorxPort();
    if (port == 80 || port == 8080 || port == 8888)
    {
        twApi_DisableEncryption();
    }
    /* Disable web socket compression if set to true */
    if (g_bDisableWebSocketCompression)
    {
        twApi_DisableWebSocketCompression();
    }
    GsAppLog(GS_INFO, MODULE_GS_CONFIG, "Initialization: Configuration for bandwidth compression is %s.",
             tw_api->mh->ws->bDisableCompression == TRUE ? "Disabled" : "Enabled");
    return err;
} //> InitSecureConnection()

// ****************************************************************************
void LogBanner()
{
    GsAppLog(GS_FORCE, MODULE_GS_CONFIG,
             "**************************************************************************");
    GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "%s Version:  %s", AGENT_NAME, AGENT_VERSION);
    GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "ThingWorx SDK version:  %s", twApi_GetVersion());
    GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "OpenSSL version:  %s", SSLeay_version(SSLEAY_VERSION));
    if (g_bDaemon)
        GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "Running '%s' as a daemon.", AGENT_NAME);
    GsAppLog(GS_FORCE, MODULE_GS_CONFIG,
             "**************************************************************************\n");
    GsAppLog(GS_INFO, MODULE_GS_CONFIG, "Agent home directory path set to: '%s'", g_pszAgentHomeDir);
} //> LogBanner()

// ****************************************************************************
//
// void SetupProxyServer() set up proxy server to communicate with the platform
//
int SetupProxyServer()
{
    int rc = TW_OK;
    return rc;
} //> SetupProxyServer()

// ****************************************************************************
// Initialize global variables (defined in main.c)
// Only need to initialize global string variables that are dynamic (changed via config files)
// so that the memory be correctly managed.
GS_BOOL InitializeGlobalVariables()
{
    // This function will update the Agent home dir only if it's not set (-home parameter missing)
    if (!InitializeAgentHomeDir())
        return FALSE;
    // default path for data logs - force to be relative to agent home - store as absolute path.
    g_pszDataLogsDir = GetFilePathInAgentHome(STR_DEFAULT_DATA_LOG_DIRECTORY, NULL);
    return TRUE;
} //> InitializeGlobalVariables()

// ****************************************************************************
void PushSubscribedPropertiesAsyncSynchronizeStateCallback(char *pszEntityName, twInfoTable *pITsubscriptionInfo,
                                                           void *pUserdata)
{
    // Notes: the infotable has a count of all the server side subscribed properties.
    //        Based on Server's property's managed bindings configuration,
    //        the count may or may not relate to the number of properties that
    //        the Agent has registered.
    //
    //        this function can be called multiple times if the server (e.g. user) subscribes
    //        for additional property updates over time.
    //
    //        The implementation needs to be updated if the app is managing multiple things.
    //
    // Programmer Note:
    //      The ELGiAgent only shows an example of receiving the callback;
    //      if desired, you can maintain a data structure that tracks if a given ‘property’ acquired
    //      by the data source is subscribed to (bound) by the Platform.
    //      This will enable you to optimize your acquisition to obtain only the properties that are
    //      requested by the Platform.
    //
    int countOfServerSubscribedPropeties = pITsubscriptionInfo->rows->count;
    if (countOfServerSubscribedPropeties)
    {
        g_bServerHandshakingInitializationCompleted = TRUE;
    }
    GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%i properties have been subscribed to by the ThingWorx Server.", countOfServerSubscribedPropeties);
} //> PushSubscribedPropertiesAsyncSynchronizeStateCallback(...)

int RetrieveThingIdentifierCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *content)
{
    const int length = (content != NULL ? content->rows->count : -1);
    int nameIndex = -1;
    if (length > 0 && twDataShape_GetEntryIndex(content->ds, "name", &nameIndex) == TW_INDEX_NOT_FOUND)
        nameIndex = -1;
    if (code == TWX_SUCCESS && length > 0 && nameIndex != -1)
    {
        //twInfoTableRow *pRow = twInfoTable_GetEntry(pItResult, 0);
        char *name = NULL;
        twInfoTable_GetString(content, "name", 0, &name);
        if (name != NULL)
        {
            GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "ThingWorx Server thing name: '%s'", name);
            TW_FREE(name);
        }
    }
    twInfoTable_Delete(content);
    s_isPropertyValuesRead = TRUE;
    return TW_OK;
} //> RetrieveThingIdentifierCallback(...)

// ****************************************************************************
// return TW_OK if the Agent can access the ThingName.  This requires the Thing to be defined and assocatiated
// with the Thing Identifier via ThingWorx Composer.
int LogServerThingName()
{
    if (!g_pszThingIdentifier)
    {
        GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "Remote Thing Identifier is still not available. Waiting for registration...", g_pszThingIdentifier);
        twSleepMsec(2500); // slight delay - connection is still being established
        return 0;
    }
    //twInfoTable *pItResult = NULL;
    // Read the server's thing name.  This assumes that the Thing instance is created and associated with the identifier.
    GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "Retrieving Thing Name for Identifier: '%s'", g_pszThingIdentifier);
    uint32_t msgId = 0;
    int rc = twApi_InvokeServiceAsync(TW_THING, g_pszThingIdentifier,
                                      "GetPropertyValues", NULL, TRUE, RetrieveThingIdentifierCallback, &msgId);
    /*int rc = twApi_InvokeService(TW_THING, g_pszThingIdentifier,
                                 "GetPropertyValues", NULL,
                                 &pItResult, g_publishMessageTimeout, FALSE);
    if (rc == TW_OK && pItResult)
    {
        twInfoTableRow *pRow = twInfoTable_GetEntry(pItResult, 0);
        char *name = NULL;
        twInfoTable_GetString(pItResult, "name", 0, &name);
        if (name != NULL)
        {
            GsAppLog(GS_FORCE, MODULE_GS_CONFIG, "ThingWorx Server thing name: '%s'", name);
            TW_FREE(name);
        }
        twInfoTable_Delete(pItResult);
    }*/
    return rc;
} //> LogServerThingName()

// ****************************************************************************
// For consistency between the Windows and Linux Mutex, override the Linux mutex implementation
// to use a recursive mutex.
// This is done in two ways
//   1. By changing the SDK's stub pointer or # define.
//   2. Overwriting the actual SDK implementation.  This is needed because the SDK is NOT
//      consistent in using the stub pointer when creating its own mutex.
//      The Agent overwrites the Linux mutex in the file:  GS-tw-c-sdk\src\porting\twLinux.c
//      Ideally #2 is not necessary... but you have to do what you have to do.
//
//   Note:  not having consistency in the Linux implementation can cause challenges (problems, dead-locks, etc)
//          when writing cross-platform compatible code.
void OverrideSDKCreateMutex()
{
    // Since we start logging  BEFORE the ThingWorx api is initialized,  API stubs need to be
    // created so support API functions can be called.
    twApi_CreateStubs();
    // Override the SDK's CreateMutex stub... or define.
    // If TW_STUBS is defined when building the SDK, the twApi_stub pointer will populated.
    if (twApi_stub)
    {
        // This is essentially treating the twApi_stub pointer like a virtual function in C++.
        twApi_stub->twMutex_Create = GS_RecursiveMutex_Create;
    }
    else
    {
#ifdef s_twMutex_Create
#undef s_twMutex_Create
#define s_twMutex_Create GS_RecursiveMutex_Create
#endif
    }
} //> OverrideSDKCreateMutex()
