//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  API_Task.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Define the thread to manage the SDK's twApi_TaskerFunction().
//
//  This code follows the standard pattern for a functional module with global functions for:  initialize, start and shutdown
//  This ELGiAgent defines ENABLE_TASKER = 0 and uses a dedicated thread
//  to invoke the twApi_TaskerFunction() function.  The wake up period for the thread is defined in the agent_config.json file.
//
//  In order to facilitate a high througput system, for each thread cycle the SDK's twApi_TaskerFunction() is invoked
//  multiple times (see agent_config.json api_tasker->task_iterations).
//
//*****************************************************************************

#include "AgentConfig.h"

// private (locally global) variables
static unsigned int g_API_TaskScanRate = 10; // milliseconds.
static GsThreadStruct *g_pAPI_TaskThreadStruct = NULL;
static int g_API_TaskIterations = 5; // # of time to iterate the SDK task in a single thread cycle.

// function prototypes

THREAD_FUNCTION_RETURN API_TaskThreadFunction(void *pVoid);

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

/*****************************************************************************
 set API tasker scan rate
 - input:  scan rate in milli-seconds
 *****************************************************************************/
void API_Task_SetScanRate(int iScanRate)
{
	g_API_TaskScanRate = iScanRate;
}

//*****************************************************************************
void API_Task_SetTaskIterations(int iIterations)
{
	if (iIterations < 1)
		iIterations = 5;
	g_API_TaskIterations = iIterations;
}

//*****************************************************************************
void API_Task_Initialize()
{
	g_pAPI_TaskThreadStruct = GsCreateThreadStruct();
	if (g_pAPI_TaskThreadStruct)
	{
		g_pAPI_TaskThreadStruct->m_waitMilliSec = g_API_TaskScanRate;
	}
}

//*****************************************************************************
int API_Task_Start()
{
	// start the thread
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "API_Task:  Initiate start of thread");
	GsStartThread(g_pAPI_TaskThreadStruct, API_TaskThreadFunction);

	return TW_OK;
}

//*****************************************************************************
void API_Task_Shutdown()
{
	// stop the thread
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "API_Task:  Initiate shutdown");
	GsStopThread(g_pAPI_TaskThreadStruct);
	GsDestroyThreadStruct(g_pAPI_TaskThreadStruct);
	g_pAPI_TaskThreadStruct = NULL;
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "API_Task:  shutdown complete");
}

//*****************************************************************************
// Thread to manage API tasker
THREAD_FUNCTION_RETURN API_TaskThreadFunction(void *pVoid)
{
	int waitReturnCondition = WAIT_OBJECT_0;

	GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid; // The void* parameter is always the thread struct pointer
	if (!pGsThreadStruct)
	{
		GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "API_Task:  Thread initialiation error.  Exiting thread.");
		return (THREAD_FUNCTION_RETURN)-1;
	}
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "API_Task:  Thread started.  Thread id = %x (hex)", pGsThreadStruct->m_threadId);
#if defined(LEGATO)
	le_thread_InitLegatoThreadData("API_Task");
#endif // LEGATO
	// while bRunning, continues to run
	while (pGsThreadStruct->m_bRunning)
	{
		DATETIME wakeupTime = twGetSystemTime(TRUE);
		DATETIME now;
		unsigned long loopTime;
		int i = 0;

		// Compensate for Windows threading not being real-time, optimize the throughput of the tasker function by
		// iterating multiple times over the SDK task in a given thread cycle.
		for (i = 0; i < g_API_TaskIterations; i++)
		{
			// execute before wait
			twApi_TaskerFunction(wakeupTime, NULL);
		}

		// calculate wait time.
		now = twGetSystemTime(TRUE);
		loopTime = (unsigned long)(now - wakeupTime);
		pGsThreadStruct->m_waitMilliSec = CalculateDelay(pGsThreadStruct, g_API_TaskScanRate, loopTime);

		// Wait for signal or timeout for the next acquisition scan.
		waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);
	}

	// exit
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "API_Task:  extiting thread");
#if defined(LEGATO)
	le_thread_CleanupLegatoThreadData();
#endif // LEGATO
	return 0;
}
