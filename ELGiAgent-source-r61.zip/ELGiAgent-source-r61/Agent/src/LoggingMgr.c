/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   	:  LoggingMgr.c
//
//  Subsystem  	:  ELGiAgent
//
//  Description:  Manages all logging to console and to file for the SDK and the ELGiAgent modules.

    The logging manager
    - is configured logging.json and provides logging granularity per module and per logging level.
    - if overrides the SDK logging function, so all SDK logging goes through the LoggingMgr
    - Logs to both file and console (configable) with a set of 'n' (configurable) rolling log files of configurable size.
    - Logs per the CALLERS thread using its local mutex for thread saftey.  See:  g_pGsLogOptions->m_LoggingMutex.
    - Notifies the ErrorEventMgr (if enabled) for all logged messages.

    Essential global functions:
    - GsAppLog:  General purpose logging function used throughout the ELGiAgent.

    Programmer Note:
    - The LoggerMgr can be used 'as is' in your application.  
      Optionally, you can add your own 'modules' to the logging.json file... and just start logging with the module name.
      But, it is recommended for clean code that you add your module name and default level in the function CreateDefaultModules() 
      and define the name in LoggingMgr.h.  

*/
//
// ******************************************************************************
#include "AgentConfig.h"
#include "cJSON.h"
#include "configParams.h"
#include "stringUtils.h"

#ifndef WIN32
#include <stdarg.h>
#endif

// The only one logging option struct
static GsLogOptions *g_pGsLogOptions = NULL;
static GS_BOOL g_bLogShuttingDown = FALSE;

// Local string helper array to use with DoLogging function
static const char *STR_LOG_LEVEL_ARRAY[] = {
	"TRACE ",
	"DEBUG ",
	"INFO ",
	"WARN ",
	"ERROR ",
	"FORCE ",
	"AUDIT "};

static const int STR_LOG_LEVEL_ARRAY_SIZE = sizeof(STR_LOG_LEVEL_ARRAY) / sizeof(const char *);

// Helper array used when initializing default modules options
const char *STR_DEFAULT_MODULES_ARRAY[] = {
	MODULE_TW_SDK,
	MODULE_GS_CONFIG,
	MODULE_GS_DATA,
	MODULE_GS_SCM,
	MODULE_GS_RUNTIME};

const int STR_DEFAULT_MODULES_ARRAY_SIZE = sizeof(STR_DEFAULT_MODULES_ARRAY) / sizeof(const char *);

// work horse function for logging
static void DoLogging(int level, char *module, const char *timestamp, const char *message);

// helpers
static int InitializeModuleOptionsFromConfig();
static void OutputMessage(int target, TW_FILE_HANDLE hFile, const char *message);
static void ReadLoggerObject(cJSON *pLogger);
static int CreateDefaultModules();
static TW_FILE_HANDLE OpenLoggingFile(int iTargets);
static void MoveLoggingFiles();
// Override ThingsWorx log function (with the same signature)
static void GsTwLog(enum LogLevel level, const char *timestamp, const char *message);

// ****************************************************************************
/*
* Returns the integer values for the each log levels
* */
enum LogLevel GsLog_StringToLogLevel(const char *level)
{
	if (strcmp(level, "TRACE") == 0)
		return TW_TRACE;
	else if (strcmp(level, "DEBUG") == 0)
		return TW_DEBUG;
	else if (strcmp(level, "INFO") == 0)
		return TW_INFO;
	else if (strcmp(level, "WARN") == 0)
		return TW_WARN;
	else if (strcmp(level, "ERROR") == 0)
		return TW_ERROR;
	else if (strcmp(level, "FORCE") == 0)
		return TW_FORCE;
	else if (strcmp(level, "AUDIT") == 0)
		return TW_AUDIT;
	else
		return TW_ERROR; /* setting default log level as ERROR .*/
}

/**
 * @brief
 * 
 * @param level Input LogLevel enumeration value (integer in real)
 * @return const char* This is a const string that needs to be duplicated if needed. 
 */
const char *GsLog_LogLevelToString(enum LogLevel level)
{
	if (level == TW_TRACE)
		return "TRACE";
	else if (level == TW_DEBUG)
		return "DEBUG";
	else if (level == TW_INFO)
		return "INFO";
	else if (level == TW_WARN)
		return "WARN";
	else if (level == TW_ERROR)
		return "ERROR";
	else if (level == TW_FORCE)
		return "FORCE";
	else if (level == TW_AUDIT)
		return "AUDIT";
	return "ERROR";
}

// ****************************************************************************
// Initialize default options for logging (this does not read the configuration file)
int GsLog_InitializeDefaults()
{
	int iReturn = TW_OK;
	if (g_pGsLogOptions)
		return TW_OK;

	g_pGsLogOptions = (GsLogOptions *)TW_MALLOC(sizeof(GsLogOptions));
	if (g_pGsLogOptions == 0)
		return TW_ERROR_ALLOCATING_MEMORY;

	// set some defaults. Will be in config file
	g_pGsLogOptions->m_gLevel = GS_INFO;
	g_pGsLogOptions->m_Target = LOG_TARGET_CONSOLE | LOG_TARGET_FILE;
	g_pGsLogOptions->m_MaxFileSize = 0X100000; // 1 meg
	g_pGsLogOptions->m_MaxFileNumber = 5;	   // allow 5 file only
	g_pGsLogOptions->m_TargetFile = GsConvertPath(STR_DEFAULT_LOGFILE_DIRECTORY);
	g_pGsLogOptions->m_LoggingMutex = GS_RecursiveMutex_Create();
	// Programmer Note:  If you 'crash' here, it is because the Logger is initialized
	// before the SDK.  So, make sure to call twApi_CreateStubs() before logger initialization.
	// The ELGiAgent release version does this in OverrideSDKCreateMutex()
	g_pGsLogOptions->m_ModuleList = twList_Create(NULL);
	if (!g_pGsLogOptions->m_LoggingMutex || !g_pGsLogOptions->m_ModuleList)
	{
		GsLog_Shutdown();
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	iReturn = CreateDefaultModules();
	if (iReturn != TW_OK)
		GsLog_Shutdown();
	// set Gs logging function
	twLogger_SetFunction(GsTwLog);
	g_bLogShuttingDown = FALSE;

	return iReturn;
}

// ****************************************************************************
// Configure final values for logging (this reads the configuration file)
int GsLog_ConfigureLogging()
{
	int iReturn = TW_OK;
	if (!g_pGsLogOptions)
		return -1;
	// initialize per module options from the logging configuration JSON file.
	iReturn = InitializeModuleOptionsFromConfig();
	// create log directory.
	GsCreateFolderForFile(g_pGsLogOptions->m_TargetFile);
	// Since logging of errors fire events, the Event Manager MUST be initialzied.
	ErrorEventMgr_Initialize();

	return iReturn;
}

// ****************************************************************************
void GsLog_Shutdown()
{
	// Make sure no logging occurs during shutdown.
	g_bLogShuttingDown = TRUE;

	if (g_pGsLogOptions)
	{
		if (g_pGsLogOptions->m_LoggingMutex)
			twMutex_Delete(g_pGsLogOptions->m_LoggingMutex);
		if (g_pGsLogOptions->m_ModuleList)
			twList_Delete(g_pGsLogOptions->m_ModuleList);
		if (g_pGsLogOptions->m_TargetFile)
			TW_FREE(g_pGsLogOptions->m_TargetFile);

		TW_FREE(g_pGsLogOptions);
	}
	g_pGsLogOptions = NULL;
}

// ****************************************************************************
int InitializeModuleOptionsFromConfig()
{
	// read the Json file
	char *pszConfigFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, STR_JSON_FILE_LOGGING);
	char *pszBufLogging = GsReadFileContent(pszConfigFilePath);
	cJSON *pJsonLogging = NULL;
	GS_BOOL bJSONValid = FALSE;

	TW_FREE(pszConfigFilePath);
	if (pszBufLogging)
	{
		pJsonLogging = cJSON_Parse(pszBufLogging);
		if (pJsonLogging)
		{
			cJSON *pVersion = cJSON_GetObjectItem(pJsonLogging, STR_VERSION);
			if (pVersion && pVersion->valueint == CURRENT_CONFIG_FILE_VERSION)
				bJSONValid = TRUE;
			else
				GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s must have a %s of %i", STR_JSON_FILE_LOGGING, STR_VERSION, CURRENT_CONFIG_FILE_VERSION);
		}
	}
	// post error if json not valid
	if (bJSONValid == FALSE)
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "File %s is invalid, default logging is used.  Log file is output to %s",
				 STR_JSON_FILE_LOGGING, g_pGsLogOptions->m_TargetFile);
	}
	else
	{
		// find the logger object
		cJSON *pLogger = cJSON_GetObjectItem(pJsonLogging, "logger");
		if (pLogger)
			ReadLoggerObject(pLogger);
	}
	cJSON_Delete(pJsonLogging);
	TW_FREE(pszBufLogging);
	// continue to run even if the json file is invalid
	return TW_OK;
}

// ****************************************************************************
int CreateDefaultModules()
{
	GsLogModuleOptions *pModule;
	int i;
	if (!g_pGsLogOptions)
		return -1;
	for (i = 0; i < STR_DEFAULT_MODULES_ARRAY_SIZE; i++)
	{
		pModule = (GsLogModuleOptions *)TW_MALLOC(sizeof(GsLogModuleOptions));
		if (pModule == NULL)
			return TW_ERROR_ALLOCATING_MEMORY;
		twList_Add(g_pGsLogOptions->m_ModuleList, pModule);

		strcpy(pModule->m_ModuleName, STR_DEFAULT_MODULES_ARRAY[i]);
		pModule->m_mLevel = GS_INFO;
		twLogger_SetLevel((enum LogLevel)pModule->m_mLevel);
	} // for each default module name
	return TW_OK;
}

// ****************************************************************************
void ReadLoggerObject(cJSON *pLogger)
{
	// default_level
	cJSON *pFile = NULL;
	cJSON *pTargets = NULL;
	cJSON *pModules = NULL;
	cJSON *pTemp = NULL;
	char *filePath;
	// default_level
	pTemp = cJSON_GetObjectItem(pLogger, "default_level");
	if (pTemp)
	{
		char *pLevel = pTemp->valuestring;
		if (pLevel)
			g_pGsLogOptions->m_gLevel = GsLog_StringToLogLevel(pLevel);
	}
	// target list
	pTargets = cJSON_GetObjectItem(pLogger, "target");
	if (pTargets)
	{
		int i;
		int iTargets = cJSON_GetArraySize(pTargets);
		for (i = 0; i < iTargets; i++)
		{
			cJSON *pTarget = cJSON_GetArrayItem(pTargets, i);
			if (pTarget && pTarget->valuestring)
			{
				// convert string to int
				if (strcmp(pTarget->valuestring, "console") == 0)
					g_pGsLogOptions->m_Target |= LOG_TARGET_CONSOLE;
				else if (strcmp(pTarget->valuestring, "file") == 0)
					g_pGsLogOptions->m_Target |= LOG_TARGET_FILE;
			}
		}
	}
	// file
	pFile = cJSON_GetObjectItem(pLogger, "file");
	if (pFile)
	{
		pTemp = cJSON_GetObjectItem(pFile, "path");
		if (pTemp && pTemp->valuestring)
		{
			if (g_pGsLogOptions->m_TargetFile)
				TW_FREE(g_pGsLogOptions->m_TargetFile);
			// create log directory.
			filePath = GsConvertPath(pTemp->valuestring);
			GsCreateFolderForFile(filePath);
			g_pGsLogOptions->m_TargetFile = filePath;
		}
		pTemp = cJSON_GetObjectItem(pFile, "max_file_size");
		if (pTemp)
			g_pGsLogOptions->m_MaxFileSize = pTemp->valueint;
		pTemp = cJSON_GetObjectItem(pFile, "max_files");
		if (pTemp)
			g_pGsLogOptions->m_MaxFileNumber = pTemp->valueint;
	}
	// log modules
	pModules = cJSON_GetObjectItem(pLogger, "modules");
	if (!pModules)
		return;
	int idx;
	int iModules = cJSON_GetArraySize(pModules);
	for (idx = 0; idx < iModules; idx++)
	{
		// got one module
		cJSON *pModuleName;
		cJSON *pModule = cJSON_GetArrayItem(pModules, idx);
		GsLogModuleOptions *pCurModule = NULL;
		char *szTemp;
		if (!pModule)
			continue;
		// check if module exists already
		pModuleName = cJSON_GetObjectItem(pModule, "name");
		if (pModuleName)
		{
			szTemp = pModuleName->valuestring;
			if (szTemp)
				pCurModule = GsLog_LookupModule(szTemp);
		}
		// If module is new
		if (pCurModule == NULL)
		{
			pCurModule = (GsLogModuleOptions *)TW_MALLOC(sizeof(GsLogModuleOptions));
			pCurModule->m_mLevel = TW_INFO; //  default level to INFO in case it is not defined in the JSON file.
			twList_Add(g_pGsLogOptions->m_ModuleList, pCurModule);
		}
		// at this point, pCurModule must be good
		if (!pCurModule)
			continue; //! skip
		if (szTemp)
			strcpy(pCurModule->m_ModuleName, szTemp);
		pTemp = cJSON_GetObjectItem(pModule, "level");
		if (!pTemp)
			continue; //! skip
		szTemp = pTemp->valuestring;
		if (szTemp)
		{
			pCurModule->m_mLevel = GsLog_StringToLogLevel(szTemp);
			if (strcmp(pCurModule->m_ModuleName, MODULE_TW_SDK) == 0)
			{
				twLogger_SetLevel((enum LogLevel)pCurModule->m_mLevel);
			}
		}
	} //# for each module
}

// ****************************************************************************
GsLogModuleOptions *GsLog_LookupModule(const char *moduleName)
{
	if (g_pGsLogOptions && g_pGsLogOptions->m_ModuleList)
	{
		twList *moduleList = g_pGsLogOptions->m_ModuleList;
		ListEntry *le = twList_Next(moduleList, NULL);
		while (le && le->value)
		{
			GsLogModuleOptions *pModule = (GsLogModuleOptions *)le->value;
			if (strcasecmp(pModule->m_ModuleName, moduleName) == 0)
				return pModule;
			le = twList_Next(moduleList, le);
		}
	}
	return NULL;
}

void GsLog_ChangeLogLevelForString(const char *moduleName, const char *level)
{
	GsLog_ChangeLogLevel(moduleName, GsLog_StringToLogLevel(level));
}

void GsLog_ChangeLogLevel(const char *moduleName, enum LogLevel level)
{
	GsLogModuleOptions *pModule = GsLog_LookupModule(moduleName);
	if (!pModule)
		return;
	pModule->m_mLevel = level;
	if (strcasecmp(pModule->m_ModuleName, MODULE_TW_SDK) == 0)
	{
		twLogger_SetLevel((enum LogLevel)level);
	}
}

void GsLog_ChangeLogLevelInJson(cJSON *pJson, const char *moduleName, const char *level)
{
	if (!pJson || !moduleName || !level)
		return;
	if (moduleName[0] == '\0' || level[0] == '\0')
		return;
	//GsLogModuleOptions *pModuleOpts = GsLog_LookupModule(moduleName);
	cJSON *pModules = NULL;
	cJSON *pModule = NULL;
	cJSON *pModuleName = NULL;
	cJSON *pModuleLevel = NULL;
	cJSON *pLogger = cJSON_GetObjectItem(pJson, "logger");
	//char *szTemp = NULL;
	if (!pLogger)
		pLogger = pJson;
	pModules = cJSON_GetObjectItem(pLogger, "modules");
	if (!pModules)
		return;
	int idx;
	int iModules = cJSON_GetArraySize(pModules);
	for (idx = 0; idx < iModules; idx++)
	{
		// got one module
		pModule = cJSON_GetArrayItem(pModules, idx);
		if (!pModule)
			continue;
		// check if module exists already
		pModuleName = cJSON_GetObjectItem(pModule, "name");
		if (pModuleName && pModuleName->valuestring && strcasecmp(pModuleName->valuestring, moduleName) == 0)
		{
			pModuleLevel = cJSON_GetObjectItem(pModule, "level");
			if (!pModuleLevel)
				break; //?
			TW_FREE(pModuleLevel->valuestring);
			pModuleLevel->valuestring = GsStringDup(level);
			pModuleLevel->type = cJSON_String;
			break;
		}
	} //# for each module
}

// ****************************************************************************
// Override ThingsWorx log function (with the same signature)
void GsTwLog(enum LogLevel level, const char *timestamp, const char *message)
{
	DoLogging(level, "TW_SDK", timestamp, message);
}

// ****************************************************************************
// Gs log function (with more options: moduleID - log source, target - to file, console, etc.)
void GsAppLog(enum GsLogLevel level, char *module, const char *format, ...)
{
	char buffer[GS_LOGGER_BUF_SIZE];
	char timeStr[80];
	va_list va;
	va_start(va, format);
	vsnprintf(buffer, GS_LOGGER_BUF_SIZE - 1, format, va);
	va_end(va);

	twGetSystemTimeString(timeStr, "%Y-%m-%d %H:%M:%S", 80, 1, 1);
	DoLogging(level, module, timeStr, buffer);
}

// ****************************************************************************
//
// work horse logging function
//
void DoLogging(int level, char *module, const char *timeStr, const char *message)
{
	int iTargets = LOG_TARGET_CONSOLE;
	int iconfigLevel = TW_INFO; // default INFO
	TW_FILE_HANDLE hFile = NULL;
	GsLogModuleOptions *pModule;

	if (g_bLogShuttingDown)
		return; // safety on shutdown.
	if (!g_pGsLogOptions)
	{
		OutputMessage(iTargets, hFile, "Logging has not been initialized yet.\n");
	}
	else
	{
		twMutex_Lock(g_pGsLogOptions->m_LoggingMutex);
		iTargets = g_pGsLogOptions->m_Target;
		iconfigLevel = g_pGsLogOptions->m_gLevel; // get from global
	}
	// hunt for the source module
	pModule = GsLog_LookupModule(module);
	if (pModule)
		iconfigLevel = pModule->m_mLevel; // over ride from per module

	// check log level. if module not found, treat it as error (always log)
	if (!pModule || !(iconfigLevel > level))
	{
		hFile = OpenLoggingFile(iTargets);
		// time stamp
		OutputMessage(iTargets, hFile, timeStr);
		OutputMessage(iTargets, hFile, " ");

		// module name
		if (pModule)
			OutputMessage(iTargets, hFile, pModule->m_ModuleName);
		else
			OutputMessage(iTargets, hFile, "Unknown");
		OutputMessage(iTargets, hFile, "--");
		// debug level
		if (level < 0 || level >= STR_LOG_LEVEL_ARRAY_SIZE)
			OutputMessage(iTargets, hFile, STR_LOG_LEVEL_ARRAY[GS_INFO]);
		else
			OutputMessage(iTargets, hFile, STR_LOG_LEVEL_ARRAY[level]);
		// the debug message itself
		OutputMessage(iTargets, hFile, message);
		// end the line
		OutputMessage(iTargets, hFile, "\n");
	} //? got log module
	if (hFile)
		TW_FCLOSE(hFile);
	if (g_pGsLogOptions)
		twMutex_Unlock(g_pGsLogOptions->m_LoggingMutex);
	// If an error is logged, notify the ThingWorx Server via an event.
	if (g_bEnableErrorEvents && pModule)
	{
		ErrorEventMgr_FireEvent(level, pModule->m_ModuleName, message);
	}
}

// ****************************************************************************
void OutputMessage(int iTargets, TW_FILE_HANDLE handle, const char *message)
{
	// to console
	if (iTargets & LOG_TARGET_CONSOLE)
		printf("%s", message);
	// to file
	if (handle)
		TW_FWRITE(message, 1, strlen(message), handle);
	// to other venues
}

TW_FILE_HANDLE GsLog_OpenLogFileForReading()
{
	TW_FILE_HANDLE hFile = NULL;
	if (!g_pGsLogOptions)
		return NULL;
	hFile = TW_FOPEN(g_pGsLogOptions->m_TargetFile, "r");
	return hFile;
}

char *GsLog_GetLogFilePath()
{
	if (!g_pGsLogOptions)
		return NULL;
	return g_pGsLogOptions->m_TargetFile;
}

// ****************************************************************************
TW_FILE_HANDLE OpenLoggingFile(int iTargets)
{
	TW_FILE_HANDLE hFile = NULL;
	long iSize;
	if (iTargets & LOG_TARGET_FILE)
	{
		hFile = TW_FOPEN(g_pGsLogOptions->m_TargetFile, "a+");
		if (hFile)
		{
			TW_FSEEK(hFile, 0, SEEK_END);
			iSize = (long)TW_FTELL(hFile);
			if (iSize >= g_pGsLogOptions->m_MaxFileSize)
			{
				TW_FCLOSE(hFile);
				// move files
				MoveLoggingFiles();
				hFile = TW_FOPEN(g_pGsLogOptions->m_TargetFile, "w+"); // this creates an empty file
			}
		}
	}
	return hFile;
}

// ****************************************************************************
//
// MoveLoggingFiles() recycle logging files when size is maxed
//
void MoveLoggingFiles()
{
	char *pConfigFile = g_pGsLogOptions->m_TargetFile;
	// Max file number must be lowered by one.
	// This is because it should not count the original log file.
	int iNumber = g_pGsLogOptions->m_MaxFileNumber - 1;
	char fileNameLast[512];
	char fileNamePrev[512];
	int iSuffix = -1;
	int iLen;
	int i;
	// find the suffix
	iLen = (int)strlen(pConfigFile);
	for (i = iLen - 1; i > 0; i--)
	{
		if (pConfigFile[i] == '\\' || pConfigFile[i] == '/')
			break;
		if (pConfigFile[i] == '.')
		{
			iSuffix = i;
			break;
		}
	}
	for (i = iNumber; i > 0; i--)
	{
		// construct the file name with number
		if (iSuffix == -1)
		{
			sprintf(fileNameLast, "%s%d", pConfigFile, i);
			if (i > 1)
				sprintf(fileNamePrev, "%s%d", pConfigFile, i - 1);
			else
				sprintf(fileNamePrev, "%s", pConfigFile);
		}
		else
		{
			pConfigFile[iSuffix] = 0;
			sprintf(fileNameLast, "%s%d", pConfigFile, i);
			pConfigFile[iSuffix] = '.';
			strcat(fileNameLast, pConfigFile + iSuffix);
			if (i > 1)
			{
				pConfigFile[iSuffix] = 0;
				sprintf(fileNamePrev, "%s%d", pConfigFile, i - 1);
				pConfigFile[iSuffix] = '.';
				strcat(fileNamePrev, pConfigFile + iSuffix);
			}
			else
				sprintf(fileNamePrev, "%s", pConfigFile);
		}
		// delete the highest numbered file
		if (i == iNumber)
			GsDeleteFile(fileNameLast);
		// elevate the Prev to Last
		GsRenameFile(fileNamePrev, fileNameLast);
	}
}

// ****************************************************************************
void GsLog_ReInitializeLogOptions()
{
	//Initialize the logging options by reading the newly
	//downloaded logging.json.  If modules are removed they have previous
	//log level value. Ideally information should be added or edited to new values.
	InitializeModuleOptionsFromConfig();
}
