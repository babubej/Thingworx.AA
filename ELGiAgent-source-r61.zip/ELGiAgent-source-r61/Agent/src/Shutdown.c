/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   :  Shutdown.c
//
//  Subsystem:  ELGiAgent
//
//  Description:
//      - Manages the shutdown and cleanup functionality for all modules.
//      - During a application restart (initiated either via a Service call or a 
//        software update) launches the RestartAgent application to manage 
//        restarting the Agent after it shutdowns.
//
******************************************************************************/

#include "AgentConfig.h"
#include "twApiStubs.h"
#include "Shutdown.h"
#include "API_Task.h"
#include "MessageThreadPoolMgr.h"
#include "configParams.h"
#include "SCM_Task.h"
#include "ExtDataAcquisition.h"
#include "ExtDataConnection.h"
#include "DataSimulatorMgr.h"
#include "DataPublishingMgr.h"
#include "ConnectionMgr.h"
#include "DelayedTasksMgr.h"
#include "services.h"

#define RESTART_APP_SCRIPT_NAME "restartApp.sh"
#define RESTART_APP_SCRIPT_CMD "restartApp.sh"

#if defined(LEGATO)
void ExternalRestartApplication()
{
    char line[256];
    FILE *fp = popen(RESTART_APP_SCRIPT_CMD, "r");
    if (fp != NULL)
    {
        while (fgets(line, sizeof(line), fp) != NULL)
        {
            GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "%s output: %s", RESTART_APP_SCRIPT_NAME, line);
        }
        int restartAppResult = pclose(fp);
        if (!WIFEXITED(restartAppResult))
        {
            GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Could not run %s script", RESTART_APP_SCRIPT_NAME);
        }
        const int restartAppExitCode = WEXITSTATUS(restartAppResult);
        if (restartAppExitCode != 0)
        {
            GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "%s failed with exit code %d",
                     RESTART_APP_SCRIPT_NAME, restartAppExitCode);
        }
    }
    else
    {
        GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Could not open %s", RESTART_APP_SCRIPT_NAME);
    }
} //> ExternalRestartApplication()
#endif // LEGATO

/* Shutdown-cleanup function */
void Shutdown()
{
    g_bReceivedShutdownSignal = TRUE;
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "*******  Initiating system shutdown%s ********", g_bRestartApplication ? "and restart" : "");
    twSleepMsec(1000);

    // stop firing events at shutdown to avoid extraneous errors.
    ErrorEventMgr_Shutdown();
    Services_Shutdown();
    DataSimulatorMgr_Shutdown();
    ExtDataAcquisition_Shutdown();
    DataPublishingMgr_Shutdown();

    ConnectionMgr_Shutdown();
    SCM_Task_Shutdown();
    API_Task_Shutdown();
    MessageThreadPoolMgr_Shutdown();
    DelayedTasks_Shutdown();

    if (g_bRestartApplication)
    {
        GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "******* Restarting the Agent ********");
#if defined(LEGATO)
        //system("sleep 5 && /legato/systems/current/bin/app restart ELGiAgent &");
        ExternalRestartApplication();
#endif // LEGATO
#if defined(WIN32)
        // Windows specific restart
        char path[MAX_PATH];
        unsigned long exitCode = 0;
        GetModuleFileNameA(NULL, path, MAX_PATH);
        GsExecuteProgram(path, "", &exitCode, FALSE, 0);
#endif // WIN32
    }
    else
    {
        GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "******* Shutting down logging and exiting the Agent ********");
    }
    GsLog_Shutdown();
    GsGsDestroyShutdownEvent();
    twSleepMsec(100);
    twApi_UnbindThing(g_pszThingIdentifier);
    twApi_Delete();
    twApi_DeleteStubs(); // ??? may not be needed in future releases
    ConfigCleanUp();
} //> Shutdown()
