//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  ErrorEventMgr.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:
/*
    Manage creation and firing of events notifying the ThingWorx Server of system (SDK & application) errors.
    The ErrorEventMgr is enabled via the agent_config.json setting:  system -> enable_error_events.
    In the ELGiAgent the error events are fired by the logger when an error is logged.

    Essential global functions:
    - ErrorEventMgr_FireEvent().  Function called to have an event queued for processing by the ErrorEventMgr's Thread.  
      In the ELGiAgent, only the Agent's logging module 'fires events'... but the design is general purpose
      in order to allow any module to generate an event. 

    This code follows the standard pattern for a functional module with global functions for:  initialize, start and shutdown.
    The Thread's responsiblity is to manage a queue of events that need to be filtered and 'fired' to the SDK. 
	NOTE:  A seperate thread is REQUIRED to inhibit a mutex deadlock
    that occurs when a SDK makeRequest() function logs an error which fires an SDK event (via the module)
    which calls makeRequest().  

    Programmer Note:  ThingWorx Events (like services) are defined per a specific 'data shape'.  
       The data shape used for these events is designed to represent an event category, message and timestamp.
       You will need to modify this to represent the 'shape' of your events. 
       These event shapes must be registered with the Server via the SDK.  [See ErrorEventMgr_Start()].
       At the server, you will need to browse for remove events and then subscribe to them.       
*/
//
//*****************************************************************************

#include "AgentConfig.h"
#include "ErrorEventMgr.h"

// To verify the ErrorEventManager is working by generating logging a test error, set the g_bTestErrorEvents to TRUE;
GS_BOOL g_bTestErrorEvents = FALSE;

// structure for event management via a queue (list)
typedef struct _ErrorEventInfo ErrorEventInfo;
struct _ErrorEventInfo
{
	char *m_pszModuleName;
	char *m_pszMessage;
};
static twList *g_pErrorEventInfoList = NULL;

// private (locally global) variables
static GS_BOOL g_bErrorEventInitalized = FALSE;
static twInfoTable *g_pEventInfoTable = NULL;
static GsThreadStruct *g_pErrorEventMgrThreadStruct = NULL;
static unsigned int g_errorEventMgrScanRate = INFINITE; //  only wakeup thread per signal from data acquisition.static GsThreadStruct*	g_pErrorEventMgrThreadStruct = NULL;
static DATETIME g_errorEventMgrWakeupTime = 0;

// Function Prototypes
//*****************************************************************************
THREAD_FUNCTION_RETURN ErrorEventThreadFunction(void *pVoid);

static void DeleteErrorEventInfo(void *pItem);
// Manage firing the error events
static void ManageEvents();
static void FireEvent(char *pszModuleName, const char *pszMessage);

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

//*****************************************************************************
//
// NOTE:  this is called by GsLog_Initialize() so that errore events
// can be queued even before the EventMgr is started.
//
void ErrorEventMgr_Initialize()
{
	if (!g_pErrorEventMgrThreadStruct)
	{
		g_pErrorEventMgrThreadStruct = GsCreateThreadStruct();
		g_pErrorEventMgrThreadStruct->m_waitMilliSec = INFINITE;
	}

	if (!g_pErrorEventInfoList)
		g_pErrorEventInfoList = twList_Create(DeleteErrorEventInfo);
}

//*****************************************************************************
twDataShape *CreateErrorEventShape()
{
	twDataShape *pErrorEventShape = twDataShape_Create(twDataShapeEntry_Create(STR_EVENT_CATEGORY, NULL, TW_STRING));
	twDataShape_AddEntry(pErrorEventShape, twDataShapeEntry_Create(STR_EVENT_MESSAGE, NULL, TW_STRING));
	twDataShape_AddEntry(pErrorEventShape, twDataShapeEntry_Create(STR_EVENT_TIMESTAMP, NULL, TW_DATETIME));
	twDataShape_SetName(pErrorEventShape, STR_ERROR_EVENT_DATA_SHAPE_NAME);

	return pErrorEventShape;
}

//*****************************************************************************
int ErrorEventMgr_Start()
{
	// The Error  Event contains the following attributes (aspects):
	//   - Category  (string)  [Same as the Logger's 'module name' category]
	//   - Message  (string)
	//   - Time     (DATETIME)
	//
	int returnCode = TW_OK;
	// create DataShape
	twDataShape *pErrorEventShape = CreateErrorEventShape();

	// Create the info table that will be used later for sending event details.
	// The info table will take ownership of the shape.
	g_pEventInfoTable = twInfoTable_Create(pErrorEventShape);

	// Register the event. This needs a Shape instance of its own
	pErrorEventShape = CreateErrorEventShape();
	returnCode = twApi_RegisterEvent(TW_THING, g_pszThingIdentifier, STR_ERROR_EVENT_NAME,
									 STR_ERROR_EVENT_DESCRIPTION, pErrorEventShape);
	if (returnCode != TW_OK)
	{
		GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Failed to register the event handlder for %s.",
				 STR_ERROR_EVENT_NAME);
		return returnCode;
	}
	g_bErrorEventInitalized = TRUE;
	// start the thread
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ErrorEventMgr:  Initiate start of thread");
	GsStartThread(g_pErrorEventMgrThreadStruct, ErrorEventThreadFunction);
	if (g_bTestErrorEvents)
	{
		GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "ErrorEventMgr:  **** TESTING the ErrorEventMgr  **** ");
	}
	return TW_OK;
}

//*****************************************************************************
void ErrorEventMgr_Shutdown()
{
	g_bErrorEventInitalized = FALSE;

	// stop data processing
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ErrorEventMgr:  Initiate shutdown");
	GsStopThread(g_pErrorEventMgrThreadStruct);
	GsDestroyThreadStruct(g_pErrorEventMgrThreadStruct);
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ErrorEventMgr:  Shutdown complete");

	twList_Delete(g_pErrorEventInfoList);
	g_pErrorEventInfoList = NULL;

	// free info table and embedded shape.
	twInfoTable_Delete(g_pEventInfoTable);
	g_pEventInfoTable = NULL;
}

//*****************************************************************************
void ErrorEventMgr_SignalThread()
{
	// Wake-up the thread.
	// GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ErrorEventMgr:  Signal thread that there are events to process.");
	GsSignalThread(g_pErrorEventMgrThreadStruct);
}

//*****************************************************************************
void ErrorEventMgr_FireEvent(int level, char *pszModuleName, const char *pszMessage)
{
	ErrorEventInfo *pErrorEventInfo = NULL;
	if (level != GS_ERROR)
		return;

	if (g_pErrorEventInfoList == NULL || g_bEnableErrorEvents == FALSE)
		return;

	// no need to Fire event for connection errors since when connected those errors will be irrelevant.
	if (strcmp(pszModuleName, MODULE_TW_SDK) == 0)
	{

		if (twApi_ConnectionInProgress() || !twApi_isConnected())
			return;

		// Filter error certain messages that are not important to publish.
		if (strstr(pszMessage, "Error updating metadata for property"))
		{
			return;
		}
	}

	// Create error event entry and place in queue for processing by thread.
	pErrorEventInfo = (ErrorEventInfo *)TW_MALLOC(sizeof(ErrorEventInfo));
	pErrorEventInfo->m_pszMessage = GsStringDup((char *)pszMessage);
	pErrorEventInfo->m_pszModuleName = GsStringDup(pszModuleName);
	twList_Add(g_pErrorEventInfoList, pErrorEventInfo);
	ErrorEventMgr_SignalThread();
}

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

//*****************************************************************************

//*****************************************************************************
THREAD_FUNCTION_RETURN ErrorEventThreadFunction(void *pVoid)
{
	// The pVoid input parameter is always the thread struct pointer
	GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid;
	if (!pGsThreadStruct)
	{
		// Log error & exit
		GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "ErrorEventMgr:  Thread initialiation error.  Exiting thread.");
		return (THREAD_FUNCTION_RETURN)-1;
	}
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ErrorEventMgr:  Thread started.  Thread id = %i", pGsThreadStruct->m_threadId);
#if defined(LEGATO)
	le_thread_InitLegatoThreadData("ErrorEventMgr");
#endif // LEGATO
	// continue processing data forever while bRunning
	while (pGsThreadStruct->m_bRunning && g_bEnableErrorEvents)
	{
		DATETIME now;
		unsigned long loopTime;

		int waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);
		if (!pGsThreadStruct->m_bRunning)
			break;

		// Manage firing the error events
		ManageEvents();

		g_errorEventMgrWakeupTime = twGetSystemTime(TRUE);

		now = twGetSystemTime(TRUE);
		loopTime = (unsigned long)(now - g_errorEventMgrWakeupTime);
		pGsThreadStruct->m_waitMilliSec = CalculateDelay(pGsThreadStruct, g_errorEventMgrScanRate, loopTime);
	}

	// exit
	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ErrorEventMgr:  extiting thread");
#if defined(LEGATO)
	le_thread_CleanupLegatoThreadData();
#endif // LEGATO
	return 0;
}

//*****************************************************************************
void DeleteErrorEventInfo(void *pItem)
{
	// Delete the ErrorEventInfo object and all its pointers.
	ErrorEventInfo *pErrorEventInfo = (ErrorEventInfo *)pItem;
	if (!pItem)
		return;

	TW_FREE(pErrorEventInfo->m_pszModuleName);
	TW_FREE(pErrorEventInfo->m_pszMessage);
	TW_FREE(pErrorEventInfo);
}

//*****************************************************************************
// Manage firing the error events
void ManageEvents()
{
	ListEntry *pEntry = NULL;
	ErrorEventInfo *pErrorEventInfo;
	char *pszModuleName = NULL;
	char *pszMessage = NULL;

	// Don't process queued events until fully initialized.
	if (g_bErrorEventInitalized == FALSE)
		return;

	// Do NOT lock the list.  This allows new entries while processing and avoids deadlocks.
	pEntry = twList_Next(g_pErrorEventInfoList, NULL);
	while (pEntry && g_pErrorEventMgrThreadStruct->m_bRunning)
	{
		ListEntry *pPreviousEntry = pEntry;
		// Publishs properties that are 'dirty'.
		pErrorEventInfo = (ErrorEventInfo *)pEntry->value;

		pszModuleName = pErrorEventInfo->m_pszModuleName;
		pszMessage = pErrorEventInfo->m_pszMessage;
		FireEvent(pszModuleName, pszMessage);

		pEntry = twList_Next(g_pErrorEventInfoList, pEntry);
		twList_Remove(g_pErrorEventInfoList, pPreviousEntry, TRUE); // remove entries as you go.  New entries added to tail.
	}
}

//*****************************************************************************
void FireEvent(char *pszModuleName, const char *pszMessage)
{
	int level = GS_ERROR;
	const char *pszSubString = NULL;
	char *pszCategory = pszModuleName;
	twInfoTableRow *pInfoTableRow = NULL;
	twInfoTable *pEventInfoTable = NULL;
	int returnCode = TW_OK;

	if (g_pEventInfoTable == NULL)
		return;

	// create a copy of the global event info table.
	// The contents of the copy is freed by FireEvent, but memory of oject still needs to be freed.
	pEventInfoTable = twInfoTable_FullCopy(g_pEventInfoTable);

	// InfoTableRow entry data MUST be added to the rows in the same order as the DataShape entry data
	// (even if the entry is empty)
	pInfoTableRow = twInfoTableRow_Create(twPrimitive_CreateFromString(pszCategory, TRUE));
	twInfoTableRow_AddEntry(pInfoTableRow, twPrimitive_CreateFromString(pszMessage, TRUE));
	twInfoTableRow_AddEntry(pInfoTableRow, twPrimitive_CreateFromDatetime(twGetSystemTime(TRUE)));

	// Add the row collection to the Info table.
	twInfoTable_AddRow(pEventInfoTable, pInfoTableRow);

	GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ErrorEventMgr:  Fire Event.  Category = %s, Message = %s", pszCategory, pszMessage);

	// assumes if not conencted, that the event will be stored in the offline-message-storage.
	returnCode = twApi_FireEvent(TW_THING, g_pszThingIdentifier, STR_ERROR_EVENT_NAME, pEventInfoTable, -1, FALSE);
	if (returnCode != TW_OK && twApi_isConnected())
	{
		// If not connected, cannot send event.  Don't give lots of unnecessary warnings in the log file.
		GsAppLog(GS_WARN, MODULE_GS_RUNTIME, "Error Event: Failed to fire with error code: %i.",
				 returnCode);
	}

	// still need to delete the memory for the info table.
	twInfoTable_Delete(pEventInfoTable);
}
