/**
 ******************************************************************************
 * @file    ExtModBus.c
 * @author  Françis DUHAUT
 * @version V1.0.0
 * @date    July-2018
 * @brief   ModBus slave features, binary mode\n
 *          Crc calculation and verification
 ******************************************************************************
 * @attention
 *
 *
 * <h2><center>&copy; COPYRIGHT 2018 EnerSys</center></h2>
 ******************************************************************************
 */
#if defined(LEGATO)
#include "legato.h"
#endif // LEGATO
#include "ExtDataAcquisition.h"

uint8_t SERBuf[SCISIZE];
uint8_t SCIBuf[SCISIZE];
uint8_t SCIPtr = 0;
uint8_t SCILen = 0;		/* 0 indicates reception mode */
uint8_t SCITimeOut = 0; /* Character timeout inactivity for SCI1 */
uint8_t SCIDeb = 0;

static char s_intCharBuf[SCISIZE];

char *recdTimer1Data[255];
char *recdTimer2Data[255];

const uint16_t CrcTabFwd[256] = {
	0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241, 0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,
	0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40, 0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
	0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40, 0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,
	0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641, 0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,
	0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240, 0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
	0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41, 0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,
	0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41, 0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,
	0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640, 0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,
	0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240, 0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,
	0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41, 0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
	0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41, 0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
	0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640, 0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,
	0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241, 0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
	0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40, 0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,
	0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40, 0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
	0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641, 0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040};

/* Crc basic routines */
#if defined(LEGATO)
/**
 * \fn uint16_t CrcFwd(uint16_t c, uint8_t s)
 * \brief Calculates forward Crc for a single byte.
 * \param c : Current value of Crc
 * \param s : New byte to add to the Crc.
 * \retval : New value of Crc.
 */
uint16_t CrcFwd(uint16_t c, uint8_t s)
{
	return *(((uint8_t *)&c) + 1) ^ CrcTabFwd[*(uint8_t *)(&c) ^ s];
	//return *(((uint8_t *)&c)) ^ CrcTabFwd[*((uint8_t *)(&c) + 1) ^ s];
}

/**
 * \fn CrcCalc(uint8_t *s, uint8_t n, uint8_t m)
 * \brief Calculates Crc for a string of bytes.
 *        Start with CRC as initial Crc
 * \param *s : String to be Crc'ed
 * \param n : First byte to calculate Crc
 * \param m : Number of bytes to add to Crc
 * \retval : Value of Crc.
 */
uint16_t CrcCalc(uint8_t *s, uint8_t n, uint8_t m)
{
	uint16_t i;
	uint16_t j;
	uint16_t c;
	c = JBCRC;
	i = n;
	j = n + m;
	do
	{
		c = CrcFwd(c, s[i]);
		i++;
	} while (i <= j);
	return c;
}

void CrcAdd(uint8_t *s, uint8_t n, uint8_t m)
{
	/* Add crc at end of string (pf PF) */
	/* *s : address of string to be crc ed */
	/* n : pointer on 1st char */
	/* m : number of char (0 = 1 char)  */
	uint16_t c;
	c = CrcCalc(&s[0], n, m);
	s[(m + 1)] = Lowbyte(c);
	s[(m + 2)] = Highbyte(c);
}

uint8_t JbErr(uint8_t *t, uint8_t c, uint8_t e)
{
	/* Revoi d'un message d'erreur pour adresse incorrecte */
	/* *t : first character to add in transmit buffer */
	/* c : function code (without error) */
	/* return : number of character written in *t buffer */
	*t = c + 0x80;
	*(t + 1) = e; /* 2 octets lus */
	return 2;
}

uint8_t CrcChk(uint8_t *s, uint8_t n, uint8_t m)
{
	/* Control crc at end of string (pf PF) */
	/* *s : address of string to be crc ed */
	/* n : first char in *s */
	/* m : number of char (0 = 1 char)  */
	/* Return : 0 = impossible to correct, 1 = 1 error corrected, 2 = crc OK */

	uint8_t e;				  /* Eror counter */
	uint16_t c;				  /* Calculated crc */
	c = CrcCalc(&s[0], n, m); /* Calculates normal crc */
	if (c != 0)
	{
		e = 0; /* Error */
	}
	else
	{
		e = 2;
	}
	return e;
}

uint8_t Size(uint8_t l, uint8_t m)
{
	/* Retourne le nombre de caractères entre l et m
dans le buffer tournant de taille n  */
	/* l : first byte */
	/* m : last byte */
	return (uint8_t)((((uint16_t)m + SCISIZE + 1) - l) & SCISIZE);
	//if (l <= m)
	//  return (m - l);
	//else
	//  return (uint8_t)(((uint16_t)(m + SCISIZE + 1) - l));
}

void UlongRev(ulong *u)
{
	/* Reverse Pf pf for ulong : 0123 becomes 2301  */
	/* Be careful with endianness */
	uint16_t i;
	i = *((uint16_t *)u + 0);
	*((uint16_t *)u + 0) = *((uint16_t *)u + 1);
	*((uint16_t *)u + 1) = i;
}

uint8_t JbFnc3Mem(uint8_t *t, uint8_t c, ulong a, uint8_t n)
{
	/* Read bytes in memory : RAM, ROM, EEPROM */
	/* *t : first character to add in transmit buffer */
	/* c : function code */
	/* a : address of first location to read */
	/* n : number of word to read */
	/* return : number of character written in *t buffer */
	uint8_t i;
	uint16_t j;
	/* La requête est bonne, construction de la trame JBus de réponse */
	*t = c;			  /* Code fonction */
	*(t + 1) = 2 * n; /* Longueur */
	/* Boucle sur les adresses mémoire */
	i = 0;
	while (i < n)
	{
		/* No inversion */
		//if (((a + 2 * i) & 3) == 0)
		/* Even */
		//  j = *(uint16_t *)(a + 2 * i + 2);
		//else
		/* Odd */
		//  j = *(uint16_t *)(a + 2 * i - 2);
		j = *(uint16_t *)(a + 2 * i);
		*(t + 2 * i + 2) = Highbyte(j);
		*(t + 2 * i + 3) = Lowbyte(j);
		i++;
	}
	return (2 * n) + 2;
}

uint8_t JbFnc3(uint8_t *t, uint8_t c, uint16_t a, uint8_t n)
{
	/* Dispatch function 3 depending on address */
	uint8_t i = 0;

	/*if ((ADRBLESENSOR <= a) && ((a + n) <= (ADRBLESENSOR + (sizeof(StructBleSensor) / 2))))
	{
		//LE_INFO("Read ADRBLESENSOR");
	    SCIDeb = 0;
	    SCILen = 1;
	    SCIPtr = 0;
		i = JbFnc3Mem(t + 1, c, 2 * (a - ADRBLESENSOR) + (ulong)&BleSensor, n);
	}
	else
	{
	    SCIDeb = 0;
	    SCILen = 1;
	    SCIPtr = 0;
		 Address error
		i = JbErr(t + 1, c, JBERRADD);
	}*/

	return i;
}

uint8_t JbFnc16Ram(uint8_t *r, uint8_t rtop, uint8_t *t, ulong a, uint16_t b, uint8_t n)
{
	/* Write in RAM area */
	/* *r : first character of buffer */
	/* rtop : first character of data */
	/* *t : first character to add in transmit buffer */
	/* a : address of first word to write in RW area */
	/* b : address for indication in response */
	/* n : number of word to write */
	/* return : number of character written in *t buffer */
	uint8_t i;
	uint8_t e; /* Return code */
	if (SCISIZE < (uint16_t)(rtop + 2 * n))
	{
		e = 0;
	}
	else
	{
		/* Boucle sur les adresses mémoire */
		i = 0;
		do
		{
			//if (((a + 2 * i) & 3) == 0)
			/* Even */
			//  *(uint16_t *)(a + 2 * i + 2) = 256 * (uint16_t)(*(r + ((rtop + 2 * i) & SCISIZE))) + *(r + ((rtop + 2 * i + 1) & SCISIZE));
			//else
			/* Odd */
			//  *(uint16_t *)(a + 2 * i - 2) = 256 * (uint16_t)(*(r + ((rtop + 2 * i) & SCISIZE))) + *(r + ((rtop + 2 * i + 1) & SCISIZE));
			*(uint16_t *)(a + 2 * i) = 256 * (uint16_t)(*(r + ((rtop + 2 * i) & SCISIZE))) + *(r + ((rtop + 2 * i + 1) & SCISIZE));
			i = i + 1;
		} while (i < n);
		/* La requête est bonne, construction de la trame JBus de réponse */
		*t = 0x10;				/* Code fonction */
		*(t + 1) = Highbyte(b); /* Address high */
		*(t + 2) = Lowbyte(b);	/* Address low */
		*(t + 3) = 0;			/* 0 */
		*(t + 4) = n;			/* Length */
		e = 5;
	}
	return e;
}

uint8_t JbFnc16(uint8_t *r, uint8_t *rtop, uint8_t *t, uint16_t a, uint8_t n)
{
	/* Dispatch function 16 depending on address to write */
	uint8_t i = 0;
	/*if ((ADRBLESENSOR <= a) && ((a + n) <= (ADRBLESENSOR + (sizeof(StructBleSensor) / 2)))
			&& ((a & 3) == 0) && ((n & 1) == 0))             Address % 4 and number of words % 2
	{
		 Writing in RAM RW area
		i = JbFnc16Ram(r, *rtop + 7, t + 1, 2 * (a - ADRBLESENSOR) + (ulong)&BleSensor, a, n);
	}
	else
	{
		 Address error
		i = JbErr(t + 1, 0x10, JBERRADD);
	}*/
	return i;
}

uint8_t JbRx(uint8_t *r, uint8_t *rtop, uint8_t sl, uint8_t cur, uint8_t *t)
{
	/* Receive one character */
	/* Build frame without checksum */
	/* *r : top of received buffer */
	/* *rtop : first character valid in received buffer */
	/* sl : slave number */
	/* cur : current character received in buffer */
	/* *t : top of transmit buffer */
	/* return : number of written characters */
	uint8_t e;	/* End of loop indicator */
	uint16_t a; /* Adresse de début, record number */
	uint8_t s;	/* Slave number */
	uint8_t c;	/* Function code */
	uint8_t n;	/* Number of words */

	/* Analyse de la trame J-Bus, débute à m, n pointeur de fin */
	e = 0xFF; /* Chaîne considérée bonne au départ */
	do		  /* Loop until charcaters could be analysed */
	{
		if (Size(*rtop, cur) < 8) /* Control of size (not greater than 8 for all functions) */
		{
			e = 0; /* String too short */
		}
		else
		{
			s = *(r + *rtop); /* Slave address */
			if (s == sl)	  /* Slave address OK */
			{
				c = *(r + ((*rtop + 1) & SCISIZE)); /* Function code */
				switch (c)							/* Selection on function code */
				{
				case 0x03: /* Lecture de N words */
				case 0x04:
				{
					/* a : jbus address, n : number of words to read */
					n = *(r + ((*rtop + 5) & SCISIZE)); /* Number of words to read <= 125 */
					if (n <= ((SCISIZE - 5) / 2) && (0 < n) && (n <= 0x7D))
					{
						/* For faster response Crc is calculated afterwards */
						if (CrcChk(r, *rtop, 7) != 0)
						{
							a = (*(r + ((*rtop + 2) & SCISIZE))) * (uint16_t)256 + *(r + ((*rtop + 3) & SCISIZE));
							/* Execute function */
							e = JbFnc3(t, c, a, n);
							*t = sl;
							e = e + 1;
						}
						else
						{
							*rtop = (*rtop + 1) & SCISIZE;
						}
					}
					else
					{
						*rtop = (*rtop + 1) & SCISIZE;
					}
				}
				break;
				case 0x10: /* Write N words */
				{
					a = (*(r + ((*rtop + 2) & SCISIZE))) * 256 + (*(r + ((*rtop + 3) & SCISIZE)));
					n = (*(r + ((*rtop + 5) & SCISIZE))); /* Nombre de mots à écrire */
					if (Size(*rtop, cur) < (2 * n + 9))	  /* Test taille */
						e = 0;							  /* Incrément du début de trame au caractère suivant et modulo */
					else
					{
						if (((*(r + ((*rtop + 4) & SCISIZE))) == 0)			 /* 00 */
							&& ((*(r + ((*rtop + 6) & SCISIZE))) == (2 * n)) /* Byte = 2 * word */
							&& (0 < n)										 /* 0 < n */
							&& (n <= 0x7B)									 /* n <= 7B */
							&& (n <= ((SCISIZE - 9) / 2)))					 /* Control buffer size */
							/* For faster response Crc is calculated afterwards */
							if (CrcChk(r, *rtop, (2 * n + 8)) != 0)
							{
								/* Execute function */
								e = JbFnc16(r, rtop, t, a, n);
								*t = sl;
								e = e + 1;
							}
							else
							{
								*rtop = (*rtop + 1) & SCISIZE;
							}
						else
						{
							*rtop = (*rtop + 1) & SCISIZE;
						}
					}
				}
				break;

				default:
				{
					*rtop = (*rtop + 1) & SCISIZE;
				}
				break;
				}
			}
			else
			{
				*rtop = (*rtop + 1) & SCISIZE;
			}
		}
	} while (e == 0xFF);
	/* Add Crc */
	if (3 <= e)
	{
		CrcAdd(t, 0, e - 1); /* Add crc */
		e = e + 2;
	}
	return e;
}

char *ModbusRead_SingleDataString(int portCom, int len)
{
	ssize_t bytesRead = read(portCom, &SERBuf[0], len);
	SERBuf[len] = 0;
	SERBuf[bytesRead] = 0;
	return (char *)&SERBuf[0];
}

ssize_t ModbusRead(int portCom, int len, int queryNum)
{
	ssize_t bytesRead = read(portCom, &SERBuf[0], len);
	char strBuf[16];

	if (bytesRead >= len)
	{
		memcpy(&SCIBuf[SCIPtr], &SERBuf[0], (bytesRead >= SCISIZE ? SCISIZE : bytesRead));
	}
	//SCIPtr = (SCIPtr + bytesRead) % len;
	if (bytesRead >= len)
	{
		//LE_INFO("DataLen: %d", len);
		memset(s_intCharBuf, 0, SCISIZE);
		memmove(s_intCharBuf, SCIBuf, (bytesRead >= SCISIZE ? SCISIZE : bytesRead));
		//LE_INFO("ca:[3] : %d",ca[5]);
		//LE_INFO("ca:[4] : %d",ca[6]);
		//LE_INFO("ca:[5] : %d",ca[3]);
		//LE_INFO("ca:[6] : %d",ca[4]);
		for (int idx = 0; idx < bytesRead; idx++)
		{
			memset(strBuf, 0, 16);
			sprintf(strBuf, "%x", (int)(s_intCharBuf[idx]));
			memset(g_dataConfig->rawData[queryNum].dataArray[idx], 0, 16);
			strcpy(g_dataConfig->rawData[queryNum].dataArray[idx], strBuf);
		}
		g_dataConfig->rawData[queryNum].dataCount = bytesRead;

		//strArray[i] = str;
		//			if(TimerNum == 1)
		//				recdTimer1Data[i] = str;
		//			else if(TimerNum == 2)
		//				recdTimer2Data[i] = str;
		//			else if(TimerNum == 3)
		//				recdTimer3Data[i] = str;
		//			else if(TimerNum == 4)
		//				recdTimer4Data[i] = str;
		//			else if(TimerNum == 5)
		//				recdTimer5Data[i] = str;

		//		std::string fileName;
		//		if(TimerNum == 1)
		//			fileName = "RecdDataArr1.txt";
		//		else if(TimerNum == 2)
		//			fileName = "RecdDataArr2.txt";

		//		std::ofstream out(fileName.c_str(), std::ofstream::app);
		//		for(int k = 0; k < bytesRead; k++)
		//		{
		//			if(TimerNum == 1)
		//				out << recdTimer1Data[k] << " ";
		//			else if(TimerNum == 2)
		//				out << recdTimer2Data[k] << " ";
		//		}
		//			out << "\n";
		//			out.close();
		//		//LE_INFO("StrArray: 3: %s", g_dataConfig->rawData[queryNum].dataArray[5].c_str());
		//		//LE_INFO("StrArray: 4: %s", g_dataConfig->rawData[queryNum].dataArray[6].c_str());
		//		//LE_INFO("StrArray: 5: %s", g_dataConfig->rawData[queryNum].dataArray[3].c_str());
		//		//LE_INFO("StrArray: 6: %s", g_dataConfig->rawData[queryNum].dataArray[4].c_str());
		SCIPtr = 0;
	}
	return bytesRead;
} //> ModbusRead(...)

#endif // LEGATO
