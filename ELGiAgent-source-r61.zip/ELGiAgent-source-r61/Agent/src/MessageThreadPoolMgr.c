//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  MessageThreadPoolMgr.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Implement the thread to manage the SDK's twMessageHandler_msgHandlerTask().
//
//  This code follows the standard pattern for a functional module with global functions for:  initialize, start and shutdown
//  This ELGiAgent defines ENABLE_TASKER = 0 and uses a dedicated thread
//  to invoke the twMessageHandler_msgHandlerTask() function.  The wake up period for the thread is defined in the agent_config.json file.
//  To process multiple Server <--> Agent messages in parallel, a thread-pool is defined (size is configurable).
//
//  In order to facilitate a high througput system, for each thread cycle the SDK's twMessageHandler_msgHandlerTask() is
//  invoked multiple times (see agent_config.json message_thread_pool->task_iterations).

//
//*****************************************************************************
#include "AgentConfig.h"
#include "MessageThreadPoolMgr.h"

// public (locally global) variables
static twList *g_pThreadPoolList = NULL;
static int g_ThreadPoolSize = 4;
static int g_MessageThreadScanPeriod = 15; // milliseconds.
static int g_MessageThreadIterations = 5;  // # of time to iterate the SDK task in a single thread cycle.

// function prototypes
THREAD_FUNCTION_RETURN MessageThreadFunction(void *pVoid);
void DeleteMessageThreadPool(void *pItem);

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

//*****************************************************************************
void MessageThreadPoolMgr_Initialize()
{
    int i = 0;
    // Create thread pool list and populate it.
    g_pThreadPoolList = twList_Create(DeleteMessageThreadPool);
    for (i = 0; i < g_ThreadPoolSize; i++)
    {
        GsThreadStruct *pThreadStruct = GsCreateThreadStruct();
        pThreadStruct->m_waitMilliSec = g_MessageThreadScanPeriod;
        twList_Add(g_pThreadPoolList, (void *)pThreadStruct);
    }
}

//*****************************************************************************
int MessageThreadPoolMgr_Start()
{
    // start each thread in the thread pool
    // All threads will use the same 'thread-safe' thread function.

    struct ListEntry *pListEntry = NULL;
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "MessageThreadPoolMgr:  Initiate start of thread");

    twMutex_Lock(g_pThreadPoolList->mtx);

    pListEntry = g_pThreadPoolList->first;
    while (pListEntry)
    {
        GsThreadStruct *pThreadStruct = (GsThreadStruct *)pListEntry->value;
        GsStartThread(pThreadStruct, MessageThreadFunction);
        // allow threads to start at different times.  This should enable the threads
        // to have a longer scan rate.
        twSleepMsec(25);
        pListEntry = pListEntry->next;
    }
    twMutex_Unlock(g_pThreadPoolList->mtx);
    twSleepMsec(2500);
    return TW_OK;
}

//*****************************************************************************
void MessageThreadPoolMgr_Shutdown()
{
    // stop each thread in the thread pool
    struct ListEntry *pListEntry = NULL;
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "MessageThreadPoolMgr:  Initiate shutdown");

    twMutex_Lock(g_pThreadPoolList->mtx);
    pListEntry = g_pThreadPoolList->first;
    while (pListEntry)
    {
        GsThreadStruct *pThreadStruct = (GsThreadStruct *)pListEntry->value;
        GsStopThread(pThreadStruct);
        pListEntry = pListEntry->next;
    }
    twMutex_Unlock(g_pThreadPoolList->mtx);
    twList_Delete(g_pThreadPoolList); // See DeleteMessageThreadPool()

    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "MessageThreadPoolMgr:  Shutdown complete");
}

//*****************************************************************************
void MessageThreadPoolMgr_SignalThread()
{
    // Wake-up the each thread thead.
    struct ListEntry *pListEntry = NULL;
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "MessageThreadPoolMgr:  Signal thread that there is data to publish.");

    twMutex_Lock(g_pThreadPoolList->mtx);
    pListEntry = g_pThreadPoolList->first;
    while (pListEntry)
    {
        GsThreadStruct *pThreadStruct = (GsThreadStruct *)pListEntry->value;
        GsSignalThread(pThreadStruct);
        pListEntry = pListEntry->next;
    }
    twMutex_Unlock(g_pThreadPoolList->mtx);
}

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

//*****************************************************************************
THREAD_FUNCTION_RETURN MessageThreadFunction(void *pVoid)
{
    int waitReturnCondition = WAIT_OBJECT_0;
    // The pVoid input parameter is always the thread struct pointer
    GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid;
    if (!pGsThreadStruct)
    {
        // Log error & exit
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "MessageThreadPoolMgr:  Thread initialiation error.  Exiting thread.");
        return (THREAD_FUNCTION_RETURN)-1;
    }
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "MessageThreadPoolMgr:  Thread started.  Thread id = %x (hex)",
             pGsThreadStruct->m_threadId);
#if defined(LEGATO)
    le_thread_InitLegatoThreadData("MessageThreadPoolMgr");
#endif // LEGATO
    // continue publishing data forever while bRunning
    while (pGsThreadStruct->m_bRunning)
    {
        DATETIME now;
        int i = 0;

        // for for timeout or signal
        waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);

        if (!pGsThreadStruct->m_bRunning)
            break;

        // allow ThingWorx SDK to manage is messages.
        now = twGetSystemTime(TRUE);

        // Compensate for Windows threading not being real-time, optimize the throughput of the message tasking function by
        // iterating multiple times over the SDK task in a given thread cycle.
        for (i = 0; i < g_MessageThreadIterations; i++)
        {
            twMessageHandler_msgHandlerTask(now, NULL);
        }

        // DO NOT offset delay by the  amount of time in the message loop.  There is no need
        // for a balanced 'square wave' signal like in data acquistion.
        //
        pGsThreadStruct->m_waitMilliSec = CalculateDelay(pGsThreadStruct, g_MessageThreadScanPeriod, 0);
    }
    // exit
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "MessageThreadPoolMgr:  extiting thread.  Thread id = %x (hex)",
             pGsThreadStruct->m_threadId);
#if defined(LEGATO)
    le_thread_CleanupLegatoThreadData();
#endif // LEGATO
    return 0;
}

//*****************************************************************************
// Function pointer for a twlist destructor for the GsThreadStruct thread pool
//
void DeleteMessageThreadPool(void *pItem)
{
    GsThreadStruct *pThreadStruct = (GsThreadStruct *)pItem;
    if (!pItem)
        return;
    GsDestroyThreadStruct(pThreadStruct);
}

//*****************************************************************************
void MessageThreadPool_SetThreadScanPeriod(int iPeriod)
{
    g_MessageThreadScanPeriod = iPeriod;
}

//*****************************************************************************
void MessageThreadPool_SetPoolSize(int iPoolSize)
{
    if (iPoolSize < 1)
        iPoolSize = 4;
    g_ThreadPoolSize = iPoolSize;
}

//*****************************************************************************
void MessageThreadPool_SetTaskIterations(int iIterations)
{
    if (iIterations < 1)
        iIterations = 5;
    g_MessageThreadIterations = iIterations;
}
