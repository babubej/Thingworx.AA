//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  SCM_Task.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:
//      In summary, this managed the download and 'install' (processing) of an Agent update (executable or configuration files).
//      Thus, this code manages the ability for the agent to be 'self-updating'.
//
//       >>>>>>>   The abbreviationi SCM stand for Software Content Manager,
//           which is ThingWorx Utilities Application to download files and run an install capability. <<<<<
//
//       !!!
//       !!! This code will need to be modified once the SCM capability is officially released in the SDK.
//
//       !!!  At this time, this file manages interfacing with the
//       !!!  pre-released versions of the twSwUpdateManager and twSwUpdateJob files.
//       !!!
//       !!!  Expected changes may include:
//       !!!   - do not create & destroy twSwUpdateManager; do not register service callbacks.
//       !!!   - some twSwUpdateManager init variables will change.
//       !!!
//       !!!  The design principle behind the interface to the twSwUpdate functions was to completely
//       !!!  remove any need to change to the SDK core code itself. Thus, you can update to a different SDK version
//       !!!  and still support SCM without requiring changes to the SDK.
//
//      Ths code follows the standard pattern for a functional module with global functions for:  initialize, start and shutdown
//
//      General Functionality includes:
//           Create & Destroy the twSwUpdateManager
//           Create Thread to manage the twSwUpdateManager_TaskerFunction for SCM tasks.
//           Manage the install process.
//           Process the swUpdateManager notification callback.
//
//           To understand the core SCM workflow of the Service calls implemented in twSWUpdateManager.c
//           and twSwUpdateJob.c, see the document in the folder:  documents\SCM Workflow.docx.
//
//      Key information:
//          The configuration for SCM is in agent_config.json
//          The key functions in this module are:
//              - SCM_TaskThreadFunction
//              - SCM_InstallFunc
//              - DoInstall
//          See function comments for details.
//
//      General worflow:
//        - Intialization: set configuration variables and create thread to invoke the SCM task manager
//        - the custom 'SDK' SCM (see files twSWUpdateManager.c & twSwUpdateJob.c) manage the processing of the package
//          and the download of the file.
//        - This module's SCM_InstallFunc, DoInstall, and SwUpdateStateChangeCallback functions do the following:
//            * Backup any files in the archive that already exists.
//            * extract the archive to the Agent's root directory (current working directory).
//            * Initiate an Agent restart.  The Agent restart workflow is as follows:
//              - The ELGiAgent starts its shutdown process.  See Shutdown.c
//              - The ELGiAgent launches a support application named AgentRestart passing in the Agent processID.
//              - The RestartAgent monitors the ELGiAgent's processID to see when the Agent has exited
//              - The ELGiAgent completes shutdown and exits
//              - The RestartAgent restarts the ELGiAgent either as a console application or a background task (Service)
//              Thus, if a new ELGiAgent has been downloaded, the latest version will now be running.
//
//
//      Reminder:
//         Search for "Programmer note" for guidance on modifying/enhancing this code.
//*****************************************************************************

#include "AgentConfig.h"
#include "SCM_Task.h"
#include "twSwUpdateManager.h"
#include "twSwUpdateJob.h"
//#include "TarGzip.h"
#include "twFileManager.h"
#include "twExt.h"
#include <sys/stat.h>

// private (locally global) variables
static unsigned int g_SCM_TaskScanRate = 100; // milliseconds.
static GsThreadStruct *g_pSCM_TaskThreadStruct = NULL;
// g_SwUpdate_Action uses bit pattern masking.
static int g_SwUpdate_Action = SWUPDATE_ACTION_NONE; /*Default action*/
static char *g_pszStagingDir = NULL;
static int g_scmIdleTimeout = -1; // units:  milliseconds
// Need to track if agent is part of a installation download because it requires
// special processing.
static GS_BOOL g_bAgentIsDownloaded = FALSE;

// Create backup directory names
static char *g_pszExeBackupDir = NULL;

// function prototypes
THREAD_FUNCTION_RETURN SCM_TaskThreadFunction(void *pVoid);

//  SW Update Event Callback
void SwUpdateStateChangeCallback(const twSwUpdateJob *job);

// Manage the actual file extration from the archive and backup as required.
static int DoInstall(char *pszSCMFormattedFilename, char *pszStagingDownloadDir, char *pszScript);

// manage file backup [File backup is optiona and is determeind by an an optional to the install function]
static int DoFileBackup(twList *pFileList, char *pszSkipFile);

int CopyFileListTo(twList *pFileList, char *pszSourceDir, char *pszTargetDir, char *pszSkipFile);

// Create required backup directories and delete if they already exist.
static int PrepareForBackup();

// Update g_SwUpdate_Action based on special use cases.
static void ProcessSpecialUseCases(twList *pFileList);

/*****************************************************************************
 set SCM Thread's scan rate to watch the Software Update task.
 - input:  scan rate in milli-seconds
 *****************************************************************************/
void SCM_Task_SetScanRate(int iScanRate)
{
    g_SCM_TaskScanRate = iScanRate;
} //> SCM_Task_SetScanRate(...)
//> ---------------------------------------------------------------------------

void SCM_Task_Initialize()
{
    int i = 0;
    // Create backup directory name
    g_pszExeBackupDir = GetFilePathInAgentHome(BACKUP_FOLDER_NAME, NULL);

    // This code will need to be removed when the SDK offically supports SCM.
    // Create software update manager and reset some default SwUPdateManager variables
    twSwUpdateManager_Create();
    twSwUpdateManager_SetInstallFunction(SCM_InstallFunc);
    twSwUpdateManager_RegisterNotification(g_pszThingIdentifier, SwUpdateStateChangeCallback);
    g_pszSw_update_staging_dir = SCM_Task_GetStagingDir();
    g_sw_update_idle_timeout = SCM_Task_GetIdleTimeout();

    // The swUpdateManager has as single service callback to handle all services.
    // Register the single callback for each SCM service name managed by the software update manager.
    // This approach does not require a change to the core SDK.
    // This needs to be removed when the SDK offically supports SCM.
    // Note: "SENTINEL" is used as an end of array marker.
    while (strcmp(swUpdateServices[i], "SENTINEL"))
    {
        twApi_RegisterServiceCallback(TW_THING, g_pszThingIdentifier, swUpdateServices[i++],
                                      (service_cb)swUpdateServiceCallback, NULL);
    }

    // Define the thread that process the software update tasks.
    // This thread will be used even after the SDK officially supports SCM.
    g_pSCM_TaskThreadStruct = GsCreateThreadStruct();
    if (g_pSCM_TaskThreadStruct)
    {
        g_pSCM_TaskThreadStruct->m_waitMilliSec = g_SCM_TaskScanRate;
    }
    // FIXME
    //char *stagingFolder = GsAppendFilenameToPath(g_pszSw_update_staging_dir, g_pszThingIdentifier + 1);
    //DoInstall("PackageTest_1598427894443.zip", stagingFolder, "HelloWorld.bat");
    //TW_FREE(stagingFolder);
    //exit(0);
} //> SCM_Task_Initialize()
//> ---------------------------------------------------------------------------

int SCM_Task_Start()
{
    // start the thread
    GsAppLog(GS_TRACE, MODULE_GS_SCM, "SCM_Task:  Initiate start of thread");
    GsStartThread(g_pSCM_TaskThreadStruct, SCM_TaskThreadFunction);

    return TW_OK;
} //> SCM_Task_Start()
//> ---------------------------------------------------------------------------

void SCM_Task_Shutdown()
{
    // stop the thread
    GsAppLog(GS_TRACE, MODULE_GS_SCM, "SCM_Task:  Initiate shutdown");
    GsStopThread(g_pSCM_TaskThreadStruct);
    GsDestroyThreadStruct(g_pSCM_TaskThreadStruct);
    GsAppLog(GS_TRACE, MODULE_GS_SCM, "SCM_Task:  shutdown complete");

    TW_FREE(g_pszStagingDir);
    g_pszStagingDir = NULL;
    TW_FREE(g_pszExeBackupDir);
    g_pszExeBackupDir = NULL;

    // delete the software update manager
    twSwUpdateManager_UnregisterNotification(g_pszThingIdentifier, SwUpdateStateChangeCallback);
    twSwUpdateManager_Delete();
} //> SCM_Task_Shutdown()
//> ---------------------------------------------------------------------------

// Thread to manage SCM tasker
// This threads calls the twSwUpdateManager_TaskerFunction peridically per the time set
// in the agent_config.json file (scm - scan_rate)\
// The scan task will manage all service calls to/from the ThingWorx Server regarding Software Content Management
// of packages.
// Once the package is downloaded, the tasker will invoke the callback SCM_InstallFunc() to 'install' the download
// (i.e process the files in the archive).
THREAD_FUNCTION_RETURN SCM_TaskThreadFunction(void *pVoid)
{
    int waitReturnCondition = WAIT_OBJECT_0;
    GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid; // The void* parameter is always the thread struct pointer
    if (!pGsThreadStruct)
    {
        GsAppLog(GS_ERROR, MODULE_GS_SCM, "SCM_Task:  Thread initialiation error.  Exiting thread.");
        return (THREAD_FUNCTION_RETURN)-1;
    }
    GsAppLog(GS_TRACE, MODULE_GS_SCM, "SCM_Task:  Thread started.  Thread id = %x (hex)", pGsThreadStruct->m_threadId);
#if defined(LEGATO)
    le_thread_InitLegatoThreadData("SCM_Task");
#endif // LEGATO
    // while bRunning, continues to run
    while (pGsThreadStruct->m_bRunning)
    {
        DATETIME wakeupTime = twGetSystemTime(TRUE);
        DATETIME now;
        unsigned long loopTime;

        // Give time to the Software Update Manager's task manager.
        // execute before wait
        twSwUpdateManager_TaskerFunction(wakeupTime, NULL);

        // calculate wait time.
        now = twGetSystemTime(TRUE);
        loopTime = (unsigned long)(now - wakeupTime);
        pGsThreadStruct->m_waitMilliSec = CalculateDelay(pGsThreadStruct, g_SCM_TaskScanRate, loopTime);

        // Wait for signal or timeout
        waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);
    }
    GsAppLog(GS_TRACE, MODULE_GS_SCM, "SCM_Task:  extiting thread");
#if defined(LEGATO)
    le_thread_CleanupLegatoThreadData();
#endif // LEGATO
    return 0;
} //> SCM_TaskThreadFunction(...)
//> ---------------------------------------------------------------------------

// Set the staging directory location for the destination of the SCM download.
// This is defined in the agent_config.json file (scm - staging_dir)
// The staging directory is where the archive is downloaded in-process. After it is fully
// downloaded, the install callback is invoked to process the archive.
void SCM_Task_SetStagingDir(char *pszStagingDir)
{
    if (pszStagingDir)
    {
        TW_FREE(g_pszStagingDir);
        g_pszStagingDir = GsConvertPath(pszStagingDir);
        twDirectory_CreateDirectory(g_pszStagingDir);
    }
} //> SCM_Task_SetStagingDir(...)
//> ---------------------------------------------------------------------------

/*Get the staging directory location for the destination of the SCM download.*/
char *SCM_Task_GetStagingDir()
{
    if (!g_pszStagingDir)
    {
        g_pszStagingDir = GsStringDup(STR_DEFAULT_SCM_TARGET_DIR);
    }
    return g_pszStagingDir;
} //> SCM_Task_GetStagingDir()
//> ---------------------------------------------------------------------------

// Set the SCM idle timeout
// This is defined in the agent_config.json file (scm - idle_timeout)
// The SCM task manager will 'abort' an package that is not completed within the timeout period.
void SCM_Task_SetIdleTimeout(int timeoutSeconds)
{
    // convert to ms.
    g_scmIdleTimeout = timeoutSeconds * 1000;
} //> SCM_Task_SetIdleTimeout()
//> ---------------------------------------------------------------------------

int SCM_Task_GetIdleTimeout()
{
    return g_scmIdleTimeout;
} //> SCM_Task_GetIdleTimeout()
//> ---------------------------------------------------------------------------

//*****************************************************************************
//   **********************   Callback  Functions   ***************************
//*****************************************************************************
//
/*
 SCM_InstallFunc is the heart of the custom code to manage the processing ("install") of
 the package download.  
 SCM_InstallFunc is set via the SCM callback function:  twSwUpdateManager_SetInstallFunction().
 
 >>>> Note:  The 'install' interface may change when the SDK officially support SCM.  <<<<

 Core custom 'SDK' SCM responsibility is:
 ` download the archive to a staging directory
 - invoke the callback function.  Key input parameters are:
    - pszSCMFormattedFilename:  contains the name of the archive.  [expected to be tar.gz for this implementation]
      The path for the filename is based on the SCM Utilities "Create Package" screen when you 'select file' and define
      the 'Directory Structure'.  For this implementation, the archive filename is extacted and the path ignored. 
    - pszStagingDownloadDir:  the folder containing the archive file.
    - pszScript:  Standard ThingWorx Utilities SCM is built on the premise that a customer's 'script' will be executed
        on the edge to process the download (i.e. do the install).  This code does NOT use a script to do the download!
        The processing of the download is managed by this SCM_InstallFunc function.
        The pszScript input is used to by this specific implementation as an input parameter to cause any pre-existing 
        file in the archive to be overwritten. 
        if pszScript = "overwrite" then any existing file that is in the archvie is overwritten.
            NOTE:  an error will be generated if the exiting file is in use by a running process (such as an 
                   exectuable or library).
        if pszScript != "overwrite" the variable is ignored!

 This implementation does the following:
    - requires a tar.gz file archive to be in the package download.  
      You can modify the code if you need to use a .zip, .7z or other archive & compresion format. 
    - Get a list of files in the archive. 
    - Backup existing files:  If the list contains a file that already exists, backup it up (or overwrite based on 
      the pszScript parameter). 
    - Extact the archive to the Agent's root directory (which is the current working directory). 
    - Set the post install action state in the variable: g_SwUpdate_Action (to either none or restart).
      In all cases (except update of only the logging.json file) the agent is restarted. 
      Note: the Agent restart is handled by the callback function:  SwUpdateStateChangeCallback which 
            is invoked by the custom 'SDK' SCM implementation.  

For Input parameter definitions, see the signature of the function in SCM_Task.h.
Return values can be:  TW_SWU_COMPLETE_SUCCESS, TW_SWU_IN_PROGRESS, TW_SWU_COMPLETE_FAILED

  Programmer Note: 
  There are several ways to implement the installer functionality.
  Other approaches could use 
   - the pszStagingDownloadDir input parameter to define the target directory for the file or it could define
     the name of the virtual directory as the target directory. The directory defined at in Utilities SCM 
     is contained as part of the path in pszStagingDownloadDir.    
   - the list of tar files to process files based on name or extension
     This may be necessary for implementation that separate directories for configuration files, executables and libaries
     (this is often done in a Linux deployment).
     Processing of files by name, extension or folder name will be required if you need to process file other then
     Agent files (such as yoru company specific application files or OS files).
   - the script input parameter to hold either an actual script (which assumes you OS has that script engine 
     installed) or use the parameter to hold a set of applicaiton specific predefined commands to define how
     to process the file (and/or optionally define the 'action' to take post install). 
   - You could use the ThingWorx Utilities SCM package parameters to control the processing workflow.
     The package parameters will be in the input:  pszParams.  
     pszParams contains a JSON formatted string. You can use the cJSON_Parse object (which is built into the SDK)
     to parse the pszParams content.  See the file configParams.c for example of using the JSON parser.
*/
int SCM_InstallFunc(char *pszScript, char *pId, char *pszEntityName, char *pszCampaign,
                    char *updateMgr, char *pszSCMFormattedFilename, char *pszStagingDownloadDir,
                    TW_SW_UPDATE_FUNC_ID *pFunc_id, char *pszParams, char abort)
{
    static GS_BOOL bIsProcessingSCMInstallFunc = FALSE; // prevent reentrancy
    int retCode = TW_OK;
    char *pszConvertedSCMFormattedFilename = NULL;
    char *pszConvertedStagingDownloadDir = NULL;
    if (bIsProcessingSCMInstallFunc)
    {
        /*The SCM install is already in-progress no action to be taken return 
		*/
        GsAppLog(GS_TRACE, MODULE_GS_SCM, "SCM_InstallFunc function is already in-progress for PackageName: %s, ID: %s",
                 pszCampaign, pId);
        return TW_SWU_IN_PROGRESS;
    }
    //  If abort signal was issued - this may cause a race condition.  The idea is that abort should take precedence.
    // Note:  swUpdateManager is informing us that the job is aborted... not asking if it is OK to abort.
    // This will be also set true when removing the scm job item from the main list.
    if (abort)
    {
        g_SwUpdate_Action = SWUPDATE_ACTION_NONE;
        if (!g_bReceivedShutdownSignal)
            GsAppLog(GS_DEBUG, MODULE_GS_SCM, "SCM_InstallFunc: Received abort signal for PackageName: %s, ID: %s",
                     pszCampaign, pId);
        return TW_SWU_COMPLETE_FAILED;
    }
    // prevent reentrancy
    bIsProcessingSCMInstallFunc = TRUE;
    pszConvertedSCMFormattedFilename = GsConvertPath(pszSCMFormattedFilename);
    pszConvertedStagingDownloadDir = GsConvertPath(pszStagingDownloadDir);
    retCode = DoInstall(pszConvertedSCMFormattedFilename, pszConvertedStagingDownloadDir, pszScript);

    TW_FREE(pszConvertedSCMFormattedFilename);
    TW_FREE(pszConvertedStagingDownloadDir);
    // Completed the tasks set the in-progress to false
    bIsProcessingSCMInstallFunc = FALSE;
    return (retCode == TW_OK) ? TW_SWU_COMPLETE_SUCCESS : TW_SWU_COMPLETE_FAILED;
} //> SCM_InstallFunc(...)
//> ---------------------------------------------------------------------------

// SW Update Event Notification Callback
// This method is invoked by the twSwUpdateManager_TaskerFunction() whenever the package state changes.
// See:  twSwUpdateState in twSwUpdateJob.h for the possible states.
//
// This implementation checks for the 'done' state (TW_SWUPDATE_DONE) and based on the
// update action (defined by the install function), the Agent will be restarted to complete the 'installation'.
//
// Programmer Note:  this callback and state variable is subject to change when the SDK supports SCM.
//
void SwUpdateStateChangeCallback(const twSwUpdateJob *job)
{
    if (!job)
    {
        GsAppLog(GS_TRACE, MODULE_GS_SCM, (TW_ERROR, "SwUpdateStateChangeCallback: Function called with NULL info"));
        return;
    }
    GsAppLog(GS_TRACE, MODULE_GS_SCM,
             "\n\n*****************\nSW UPDATE STATE CHANGE:\nCampaign: %s\nID: %s\nThingName: %s\nCurrent State: %s\n*****************\n",
             job->campaignName ? job->campaignName : "NULL", job->id ? job->id : "NULL", job->entityName ? job->entityName : "NULL",
             twSwUpdateJob_GetStateString(job->state));

    // Note:  Notification for state == TW_SWUPDATE_DONE is sent after both a failure and a 'completed' (success) state.
    //        If there was an failure, then the update action will be 'none'.
    //        If TW_SWUPDATE_DONE occurs and the update action is not 'none', then finish install.
    //        There is no need to process the completed state (TW_SWUPDATE_COMPLETED) since this is processed via TW_SWUPDATE_DONE.
    if (job->state == TW_SWUPDATE_FAILED)
    {
        g_SwUpdate_Action = SWUPDATE_ACTION_NONE;
    }
    else if (job->state == TW_SWUPDATE_DONE && g_SwUpdate_Action != SWUPDATE_ACTION_NONE)
    {
        // precautionary messaure to make sure the SCM status update message for 'completed' gets delivered.
        twSleepMsec(1000);
        /*	If the SW update post action is restart, the GsShutdownApplication() function will
            manage stoping the Agent and restarting it.  */
        if (g_SwUpdate_Action == SWUPDATE_ACTION_RESTART_APP)
        {
            GsAppLog(GS_INFO, MODULE_GS_SCM, "Restarting Agent to complete software update.");
            g_SwUpdate_Action = SWUPDATE_ACTION_NONE;
            GsShutdownApplication(TRUE);
        }
    }
} //> SwUpdateStateChangeCallback(...)
//> ---------------------------------------------------------------------------

twSwPackageType SwGetPackageTypeFromPath(char *pszFilePath)
{
    if (!pszFilePath)
        return TW_SWPACKAGE_AGENT;
    twSwPackageType packageType = TW_SWPACKAGE_GENERIC;
    const char *pszFileName = GsGetFileNamePortion(pszFilePath);
    lowercase(pszFileName);
    if (strstr(pszFileName, "firmware") != NULL)
        packageType = TW_SWPACKAGE_FIRMWARE;
    else if (strstr(pszFileName, "legato") != NULL)
        packageType = TW_SWPACKAGE_LEGATO;
    else if (strstr(pszFileName, "hardware") != NULL)
        packageType = TW_SWPACKAGE_HADRWARE;
    else if (strstr(pszFileName, "neuron") != NULL)
        packageType = TW_SWPACKAGE_NEURON;
    else if (strstr(pszFileName, "agent") != NULL)
        packageType = TW_SWPACKAGE_AGENT;
    TW_FREE(pszFileName);
    return packageType;
} //> SwGetPackageTypeFromPath(...)
//> ---------------------------------------------------------------------------

const char *SwPackageTypeName(twSwPackageType packageType)
{
    if (packageType == TW_SWPACKAGE_FIRMWARE)
        return "firmware";
    else if (packageType == TW_SWPACKAGE_LEGATO)
        return "legato";
    else if (packageType == TW_SWPACKAGE_HADRWARE)
        return "hardware";
    else if (packageType == TW_SWPACKAGE_NEURON)
        return "neuron";
    else if (packageType == TW_SWPACKAGE_AGENT)
        return "agent";
    return "generic";
} //> SwPackageTypeName(...)

//*****************************************************************************
//**********************   Local Support  Functions   *************************
//*****************************************************************************
#include "unzip.h"
twList *GsGetZipFileListing(char *pszFilePath)
{
    int opt_extract_without_path = 0;
    int opt_overwrite = 1;
    const char *password = NULL;
    uLong idx;
    unz_global_info64 gi;
    unzFile uf = unzOpen64(pszFilePath);
    int err = unzGetGlobalInfo64(uf, &gi);
    unz_file_info64 file_info;
    char filename_inzip[512];
    if (err != UNZ_OK)
    {
        unzClose(uf);
        return NULL;
    }
    twList *pFileList = twList_Create(NULL);
    for (idx = 0; idx < gi.number_entry; idx++)
    {
        err = unzGetCurrentFileInfo64(uf, &file_info, filename_inzip, sizeof(filename_inzip), NULL, 0, NULL, 0);
        if (err != UNZ_OK)
            break;
        twList_Add(pFileList, GsStringDup(filename_inzip));
        err = unzGoToNextFile(uf);
        if (err == UNZ_END_OF_LIST_OF_FILE)
        {
            //TW_LOG(TW_DEBUG, "End of list in unzGoToNextFile.");
            break;
        }
        else if (err != UNZ_OK)
        {
            //TW_LOG(TW_ERROR, "Error %d with zipfile in unzGoToNextFile.", err);
            break;
        }
    } //# for each file entry
    unzClose(uf);
    return pFileList;
} //> GsGetZipFileListing(...)
//> ---------------------------------------------------------------------------

// Manage the actual file extration from the archive and backup as required.
//
// Implementation:  The downloaded tar.gz archive is extracted into the Agent's root
//       directory (e.g. where the Agent binary is running).
//       This enables updating of any file in the Agent directory including binary files and
//       configuration files.
//
// Note: the pszScript is defined at the Server as part of the package.
//       Per this implementation, a 'script' is NOT used.
//       But, the 'script' input can be used in the processing of the dowload.
//       If the pszScript does NOT equal "overwrite" - then the default is to backup any existing file
//       that are in the downloaded archive before extacting the archive.
int DoInstall(char *pszSCMFormattedFilename, char *pszStagingDownloadDir, char *pszScript)
{
    char *pszCurrentPath = GsGetCwd(); // need to free the buffer
    twList *pFileListing = NULL;
    char *pszExtractPath = TW_MALLOC(PATH_MAX + 1);
    char *pszScriptFullPath = NULL; //GetFilePathInAgentHome(NULL, pszScript);
    char *pszArchiveName = NULL;
    char *pszFullPathArchiveName = NULL;
    int retCode = TW_OK;
    GS_BOOL shouldRunScript = FALSE;
    GS_BOOL fileBackupDone = FALSE;
    twSwPackageType packageType = SwGetPackageTypeFromPath(pszSCMFormattedFilename);
    char *packageTypeStr = GsStringDup(SwPackageTypeName(packageType));
    memset(pszExtractPath, 0, PATH_MAX + 1);
    GsAppLog(GS_FORCE, MODULE_GS_SCM, "Incoming package is of type: '%s'", uppercase(packageTypeStr));
    lowercase(packageTypeStr);
    if (!pszScript)
        pszScript = "update.sh"; // force default
    if (strlen(pszScript) == 0)
        pszScript = "update.sh"; // force default
    //shouldRunScript = FALSE;
    // The pszSCMFormattedFilename is defined at Utilities SCM by the user.  It uses Linux path delimeters... but for this
    // implementation the path will be ignored and only the filename will be used.
    // The filename is assuemd to be a file archive using the tar.gz format.
    // The tar.gz will contain path information.
    // The destination directory is fixed to the Agent's working directory (where the exe lives).
    // clean up the pszSCMFormattedFilename to only have the name of the tar.gz archive.
    pszArchiveName = GsGetFileNamePortion(pszSCMFormattedFilename);
    // extraction path is always the same (internally inside SCM update folder)
    // the trick is to later on BACKUP some of those files
    // and overwrite the other files
    sprintf(pszExtractPath, "%s%s%s_%s%s", pszStagingDownloadDir, TW_FILE_DELIM_STR, "extract", packageTypeStr, TW_FILE_DELIM_STR);
    pszScriptFullPath = GsAppendFilenameToPath(pszExtractPath, pszScript);
    GsCreateFolderRecursive(pszExtractPath);
    // Get list of file in the tar file.
    pszFullPathArchiveName = GsAppendFilenameToPath(pszStagingDownloadDir, pszArchiveName);
    pFileListing = GsGetZipFileListing(pszFullPathArchiveName);
    if (pFileListing != NULL)
    {
        ListEntry *pItem = pFileListing->first;
        int _idx = 0;
        if (pFileListing->count)
            GsAppLog(GS_TRACE, MODULE_GS_SCM, "Zip file listing contents for '%s' package:", pszArchiveName);
        else
            GsAppLog(GS_TRACE, MODULE_GS_SCM, "Incoming '%s' zip file is empty or damaged!", pszArchiveName);
        while (pItem)
        {
            char *pFilePath = (char *)pItem->value;
            if (pFilePath != NULL)
            {
                GsAppLog(GS_TRACE, MODULE_GS_SCM, "[%d] %s", _idx, pFilePath);
                if (pszScript != NULL && strstr(pFilePath, pszScript) != NULL)
                    shouldRunScript = TRUE; // the script file is present
                _idx++;
            }
            pItem = pItem->next;
        } //# while got items
    }
    GsAppLog(GS_INFO, MODULE_GS_SCM, "SCM_InstallFunc: Extracting update package '%s' from '%s'", pszArchiveName, pszStagingDownloadDir);
    GsSetCwd(pszExtractPath); // go into extract dir
    retCode = twApi_ZipExtractFile(pszFullPathArchiveName);
    GsSetCwd(pszCurrentPath); // go back
    if (retCode != TW_OK)
    {
        GsAppLog(GS_ERROR, MODULE_GS_SCM, "SCM_InstallFunc: Error creating list of files from the dowloaded archive file: %s.  Application error code = %i",
                 pszArchiveName, retCode);
        goto ExitFunction;
    }
    // Extraction was ok - now it should do any required backup
    // Should backup be performed two-fold?
    // We can update files that will get overwritten - this is the case with 'ConfigFiles' type update
    // Every other update type will use custom exe package and script.
    if (packageType == TW_SWPACKAGE_CONFIGFILES)
    {
        // package is of 'ConfigFiles', file listing contains files that'll get copied over
        // backup files before extaction. This is required when updating an executable or library that is running.
        retCode = DoFileBackup(pFileListing, pszScript);
        if (retCode != TW_OK)
            goto ExitFunction; // exit fatal ?
        // Note:  This will overwrite any files that are not actively being used by a process.
        fileBackupDone = TRUE;
    }
    if (shouldRunScript && twDirectory_FileExists(pszScriptFullPath))
    {
        GsAppLog(GS_INFO, MODULE_GS_SCM, "SCM_InstallFunc: Executing update script '%s'", pszScriptFullPath);
        unsigned long exitCode = 0;
        int _length = strlen(pszScriptFullPath) + 16;
        char *inputArg_1 = (char *)TW_MALLOC(_length);
        memset(inputArg_1, 0, _length);
        const char *pProgram;
#if defined(LINUX) || defined(LEGATO)
        pProgram = "sh"; // assume /bin/sh for Legato and Linux
        sprintf(inputArg_1, "%s", pszScriptFullPath);
#else
        pProgram = "bash.exe"; // Try to support bash.exe and Git for Windows (for testing mostly)
        sprintf(inputArg_1, "\"%s\"", pszScriptFullPath);
#endif /* LINUX / LEGATO */
#if defined(WIN32)
        // .bat files are also supported - can be called directly
        if (strcmp(GsGetFileExtension(pszScript), ".bat") == 0)
        {
            pProgram = pszScriptFullPath; // for bat file can use the file name directly
            sprintf(inputArg_1, "");      // no input arguments for itself
        }
#endif /* WIN32 */
        // in this case it's necessary to check the file extension
        // .sh script files should be executed by sh or bash (even for windows)
        // .bat files should be triggered directly?
        GsSetCwd(pszExtractPath); // go into extract dir
        retCode = GsExecuteProgram(pProgram, inputArg_1, &exitCode, TRUE, 15000);
        GsSetCwd(pszCurrentPath); // go back
        TW_FREE(inputArg_1);
        if (retCode != TW_OK || exitCode != 0)
        {
            // error occurred - script was not successfull, or wasn't even executed (wrong PATH)
            // for Windows it's neccessary to have bash.exe added (from Git for Windows)
            // If script file is a .bat file - it will be executed directly without cmd.exe or bash.exe
            // There is no way to verify - need to assume failure and revert if possible (skip backups etc)
            GsAppLog(GS_ERROR, MODULE_GS_SCM, "Executing script '%s' and program '%s' has failed with code: %d (retCode: %d)",
                     pszScript, pProgram, exitCode, retCode);
            retCode = 1; // force value not ok
            goto ExitFunction;
        }
    } //? script file exists
    // at this point it's needed to copy over any files from the extracted folder
    if (shouldRunScript && retCode == TW_OK)
        GsAppLog(GS_INFO, MODULE_GS_SCM, "Script '%s' finished runing with status OK!", pszScript);
    if (fileBackupDone)
    {
        // copy over files from the extracted directory to home
        CopyFileListTo(pFileListing, pszExtractPath /* from */, g_pszAgentHomeDir /* to */, pszScript);
    }
ExitFunction:
    // Set the software update action to restart the Agent on all updates.
    // The restart is done based on the assumption that the only download processed by this
    // implementation is an installation of a new agent or agent configuration file.
    // Programmer Note
    // If you have other use cases besides an Agent 'install', you may not need to restart the Agent.
    if (retCode == TW_OK)
    {
        //
        // FIXME - restart should be only done when updating the agent files?
        // TODO or always - but with additional check to ensure that incoming
        // script executed properly.
        ProcessSpecialUseCases(pFileListing);
    }
    // clean-up staging directory.
    //twDirectory_DeleteDirectory(pszExtractPath);
    twDirectory_DeleteFile(pszFullPathArchiveName);
    twList_Delete(pFileListing);
    TW_FREE(packageTypeStr);
    TW_FREE(pszScriptFullPath);
    TW_FREE(pszArchiveName);
    TW_FREE(pszFullPathArchiveName);
    TW_FREE(pszCurrentPath);
    if (packageType == TW_SWPACKAGE_CONFIGFILES)
    {
        // Restart the application
        g_SwUpdate_Action = SWUPDATE_ACTION_RESTART_APP;
    }
    return retCode;
} //> DoInstall(...)
//> ---------------------------------------------------------------------------

int CopyFileListTo(twList *pFileList, char *pszSourceDir, char *pszTargetDir, char *pszSkipFile)
{
    ListEntry *pEntry = NULL;
    char *pszEntryFileName = NULL;
    int retCode = TW_OK;
    char *pszSourceFile = NULL;
    char *pszDestinationFile = NULL;
    // Iterate the list and perform backup per file.
    pEntry = twList_Next(pFileList, NULL);
    if (!pszTargetDir)
        pszTargetDir = g_pszAgentHomeDir;
    if (!pszSourceDir)
        pszSourceDir = g_pszExeBackupDir;
    while (pEntry)
    {
        if (pEntry->value == NULL)
        {
            pEntry = twList_Next(pFileList, pEntry);
            continue;
        }
        pszEntryFileName = (char *)pEntry->value;
        if (pszSkipFile != NULL && strstr(pszEntryFileName, pszSkipFile) != NULL)
        {
            pEntry = twList_Next(pFileList, pEntry);
            continue;
        }
        unsigned int _len = strlen(pszEntryFileName);
        // check if filename is a directory.
        if (pszEntryFileName[_len - 1] == '/' || pszEntryFileName[_len - 1] == '\\')
        {
            // Create the tar directory as a sub-directory in the back up folder.
            char *pszDirectory = NULL;
            char *pszTempEntryDirName = GsStringDup(pszEntryFileName);
            // remove trailing file delimiter and replace with a string null terminitor.
            // This is required for TW functions to work correctly
            pszTempEntryDirName[strlen(pszTempEntryDirName) - 1] = '\0';
            pszDirectory = GsAppendFilenameToPath(g_pszExeBackupDir, pszTempEntryDirName);
            twDirectory_CreateDirectory(pszDirectory);
            TW_FREE(pszDirectory);
            TW_FREE(pszTempEntryDirName);
            // now, continue to the next file in the archive.
            pEntry = twList_Next(pFileList, pEntry);
            continue;
        }
        // set the source and destination file name strings.
        pszSourceFile = GsAppendFilenameToPath(pszSourceDir, pszEntryFileName);
        pszDestinationFile = GsAppendFilenameToPath(pszTargetDir, pszEntryFileName);
        if (twDirectory_FileExists(pszSourceFile))
        {
            char *lastSlash = strrchr(pszDestinationFile, TW_FILE_DELIM);
            if (lastSlash != NULL)
            {
                *lastSlash = 0;
                twDirectory_CreateDirectory(pszDestinationFile);
                *lastSlash = TW_FILE_DELIM;
            }
            retCode = twDirectory_CopyFile(pszSourceFile, pszDestinationFile);
            if (retCode != TW_OK)
            {
                GsAppLog(GS_ERROR, MODULE_GS_SCM, "Could not copy file from %s to %s.  OS system error code: %i",
                         pszSourceFile, pszDestinationFile, retCode);
            }
        }
        TW_FREE(pszSourceFile);
        pszSourceFile = NULL;
        TW_FREE(pszDestinationFile);
        pszDestinationFile = NULL;
        if (retCode != TW_OK)
        {
            // Programmer Note:
            // It is up to your workflow to determine what to do if a file could not be backed-up.
            retCode = TW_OK;
        }
        // prepare to backup the next file (or directory) in the archive.
        pEntry = twList_Next(pFileList, pEntry);
    } //# for each file entry
    return retCode;
} //> CopyFileListTo(...)
//> ---------------------------------------------------------------------------

// manage file backup [File backup is optional and is determined by the install function]
//
// Using the input list of files in the tar archive, backup any existing files.
// Any previous 'backup' file is deleted before the existing core file is backed-up.
// the backup directory is set in the variable:  g_pszExeBackupDir
int DoFileBackup(twList *pFileList, char *pszSkipFile)
{
    int retCode = TW_OK;
    GsAppLog(GS_INFO, MODULE_GS_SCM, "Backing up existing Agent files in prepration for Agent update.");
    // Create required backup directories and delete them if they already exist.
    retCode = PrepareForBackup();
    if (retCode != TW_OK)
        return retCode;
    return CopyFileListTo(pFileList, g_pszAgentHomeDir, g_pszExeBackupDir, pszSkipFile);
} //> DoFileBackup(...)
//> ---------------------------------------------------------------------------

// Create required backup directories and delete them if they already exist.
int PrepareForBackup()
{
    int retCode = TW_OK;
    if (twDirectory_FileExists(g_pszExeBackupDir))
    {
        retCode = GsDeleteDirectoryRecursive(g_pszExeBackupDir);
        if (retCode != TW_OK)
        {
            GsAppLog(GS_ERROR, MODULE_GS_SCM, "Cannot delete existing directory:  %s", g_pszExeBackupDir);
            return retCode;
        }
    }
    retCode = twDirectory_CreateDirectory(g_pszExeBackupDir);
    if (retCode != TW_OK)
    {
        GsAppLog(GS_ERROR, MODULE_GS_SCM, "Cannot create directory:  %s", g_pszExeBackupDir);
        return retCode;
    }
    return retCode;
} //> PrepareForBackup()
//> ---------------------------------------------------------------------------

// Update the post install action variable (g_SwUpdate_Action) based on special use cases.
//
// All agent configuration files require the agent to be restarted with the EXCEPTION
// of the logging.json configuration file.  IF that is the only file in the archive,
// an Agent restart is not necessary; a reinitialize logging function is called instead.
//
//  Programmer Note:
//    This is an example of one way of handling special use cases within the downloaded archive.
//
void ProcessSpecialUseCases(twList *pFileList)
{
    // Special use case.  Enable updating of logging parameters ** without ** a restart.
    ListEntry *pEntry = NULL;
    char *pszTarEntryFileName = NULL;

    // This assumes that the tar contains 2 files:  the ConfigFiles directory and the logging configuration file.
    if (pFileList->count != 2)
        return;

    // check if 1st entry is the config files folder.
    pEntry = twList_Next(pFileList, NULL);
    if (pEntry->value == NULL)
        return;
    pszTarEntryFileName = (char *)pEntry->value;
    if (strstr(pszTarEntryFileName, CONFIG_FOLDER_NAME) == 0 && pszTarEntryFileName[strlen(pszTarEntryFileName) - 1] == TW_FILE_DELIM)
    {
        pEntry = twList_Next(pFileList, pEntry);
        if (pEntry->value == NULL)
            return;

        // check that 2nd entry is the logging config file.
        pszTarEntryFileName = (char *)pEntry->value;
        if (strstr(pszTarEntryFileName, STR_JSON_FILE_LOGGING))
        {
            // update logging options without a restart.
            GsLog_ReInitializeLogOptions();

            // No need to restart the application.
            g_SwUpdate_Action = SWUPDATE_ACTION_NONE;
        }
    }
} //> ProcessSpecialUseCases(...)
//> ---------------------------------------------------------------------------
