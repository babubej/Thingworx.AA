//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  tsSwUpdateJob.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:
//      This code is the **Custom** C-SDK implementation of Software Content Management (SCM)
//      It should NOT be modified.
//      This code should be removed when the C-SDK release officially supports SCM.
//
//      >>>>>>>>>  For SCM details, see SCM_Task.c <<<<<<<<<<<
//
//*****************************************************************************

// Software Update includes.
#include "twSwUpdateManager.h"
#include "twSwUpdateJob.h"

#include "AgentConfig.h"
#include "twLogger.h"
#include "twInfoTable.h"
#include "twDefinitions.h"
#include "stringUtils.h"
#include "cJSON.h"
#include "twApi.h"
#ifdef ENABLE_FILE_XFER
#include "twFileManager.h"
#endif

// sw upate global variables.  Originally in twConfig.
extern char *g_pszSw_update_staging_dir;

/********************************/
/*       Helper Functions       */
/********************************/
int swUpdateNotifyServer(twSwUpdateJob *job, char *state, char complete, char *message, char success, char *reason)
{
	twDataShapeEntry *dse = NULL;
	twDataShape *ds = NULL;
	twInfoTableRow *row = NULL;
	twInfoTable *it = NULL;
	uint32_t msgId = 0;
	//twInfoTable *result = NULL;
	int res = TW_OK;
	if (!job || !state)
		return TW_INVALID_PARAM;
	dse = twDataShapeEntry_Create("ID", NULL, TW_STRING);
	if (!dse)
	{
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	ds = twDataShape_Create(dse);
	if (!ds)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error creating DataShape");
		twDataShapeEntry_Delete(dse);
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	if (twDataShape_AddEntry(ds, twDataShapeEntry_Create("State", NULL, TW_STRING)))
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding field to DataShape");
		twDataShape_Delete(ds);
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	if (twDataShape_AddEntry(ds, twDataShapeEntry_Create("Target", NULL, TW_STRING)))
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding field to DataShape");
		twDataShape_Delete(ds);
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	if (twDataShape_AddEntry(ds, twDataShapeEntry_Create("Timestamp", NULL, TW_DATETIME)))
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding field to DataShape");
		twDataShape_Delete(ds);
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	if (complete)
	{
		if (twDataShape_AddEntry(ds, twDataShapeEntry_Create("Message", NULL, TW_STRING)))
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding field to DataShape");
			twDataShape_Delete(ds);
			return TW_ERROR_ALLOCATING_MEMORY;
		}
		if (twDataShape_AddEntry(ds, twDataShapeEntry_Create("Success", NULL, TW_BOOLEAN)))
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding field to DataShape");
			twDataShape_Delete(ds);
			return TW_ERROR_ALLOCATING_MEMORY;
		}
		if (twDataShape_AddEntry(ds, twDataShapeEntry_Create("Reason", NULL, TW_STRING)))
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding field to DataShape");
			twDataShape_Delete(ds);
			return TW_ERROR_ALLOCATING_MEMORY;
		}
	}
	it = twInfoTable_Create(ds);
	if (!it)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error creating InfoTable");
		twDataShape_Delete(ds);
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	row = twInfoTableRow_Create(twPrimitive_CreateFromString(job->id, TRUE));
	if (!row)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error creating InfoTable Row");
		twInfoTable_Delete(it);
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	if (twInfoTableRow_AddEntry(row, twPrimitive_CreateFromString(state, TRUE)))
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding value to InfoTableRow");
		twInfoTable_Delete(it);
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	if (twInfoTableRow_AddEntry(row, twPrimitive_CreateFromString(job->entityName, TRUE)))
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding value to InfoTableRow");
		twInfoTable_Delete(it);
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	if (twInfoTableRow_AddEntry(row, twPrimitive_CreateFromDatetime(twGetSystemTime(TRUE))))
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding value to InfoTableRow");
		twInfoTable_Delete(it);
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	if (complete)
	{
		if (twInfoTableRow_AddEntry(row, twPrimitive_CreateFromString(message ? message : "", TRUE)))
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding value to InfoTableRow");
			twInfoTable_Delete(it);
			return TW_ERROR_ALLOCATING_MEMORY;
		}
		if (twInfoTableRow_AddEntry(row, twPrimitive_CreateFromBoolean(success)))
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding value to InfoTableRow");
			twInfoTable_Delete(it);
			return TW_ERROR_ALLOCATING_MEMORY;
		}
		if (twInfoTableRow_AddEntry(row, twPrimitive_CreateFromString(reason, TRUE)))
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error adding value to InfoTableRow");
			twInfoTable_Delete(it);
			return TW_ERROR_ALLOCATING_MEMORY;
		}
	}
	twInfoTable_AddRow(it, row);
	if (complete)
	{
		//res = twApi_InvokeService(TW_THING, job->serverUpdateMgr, "CompleteDeliveryTarget", it, &result, -1, FALSE);
		res = twApi_InvokeServiceAsync(TW_THING, job->serverUpdateMgr, "CompleteDeliveryTarget", it, TRUE, EmptyServiceCallback, &msgId);
	}
	else
	{
		//res = twApi_InvokeService(TW_THING, job->serverUpdateMgr, "UpdateState", it, &result, -1, FALSE);
		res = twApi_InvokeServiceAsync(TW_THING, job->serverUpdateMgr, "UpdateState", it, TRUE, EmptyServiceCallback, &msgId);
	}
	GsAppLog(GS_AUDIT, MODULE_GS_SCM, "SW Update State Change: PackageName: %s, ID: %s, Target: %s, State: %s, Message: %s",
			 job->campaignName, job->id, job->entityName, state, message ? message : "");
	twInfoTable_Delete(it);
	//if (result)
	//	twInfoTable_Delete(result);
	if (res)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateNotifyServer: Error %d returned when trying to update state of job %s", res, job->id);
	}
	return res;
} //> swUpdateNotifyServer(...)

/********************************/
/*    Structure Functions       */
/********************************/
twSwUpdateJob *twSwUpdateJob_Create(const char *entityName, cJSON *json, char *vdir, swupdate_func downloadFunc, swupdate_func installFunc)
{
	twSwUpdateJob *job = NULL;
	cJSON *tmp = NULL;
	int len = 0; /* Length of script parameter string */
	if (!entityName || !json || !installFunc)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: NULL pointer for required parameter");
		return NULL;
	}
	job = (twSwUpdateJob *)TW_CALLOC(sizeof(twSwUpdateJob), 1);
	if (!job)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Error allocating memory for job");
		return NULL;
	}
	job->swuJobMtx = GS_RecursiveMutex_Create();
	job->entityName = duplicateString(entityName);
	len += (int)(strlen("twEntity=") + strlen(entityName) + 1);
	job->lastActivity = twGetSystemTime(TRUE);
	job->state = TW_SWUPDATE_CREATED;
	job->prev_state = TW_SWUPDATE_UNKNOWN;
	job->downloadFunc = downloadFunc;
	job->installFunc = installFunc;
	tmp = cJSON_GetObjectItem(json, "id");
	if (!tmp || !tmp->valuestring)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Missing id in json params");
		twSwUpdateJob_Delete(job);
		return NULL;
	}
	job->id = duplicateString(tmp->valuestring);
	len += (int)(strlen("twId=") + strlen(tmp->valuestring) + 1);
	tmp = cJSON_GetObjectItem(json, "name");
	if (!tmp || !tmp->valuestring)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Missing name in json params");
		twSwUpdateJob_Delete(job);
		return NULL;
	}
	job->campaignName = duplicateString(tmp->valuestring);
	len += (int)(strlen("twCampaign=") + strlen(tmp->valuestring) + 1);
	tmp = cJSON_GetObjectItem(json, "updateManager");
	if (!tmp || !tmp->valuestring)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Missing repository in json params");
		twSwUpdateJob_Delete(job);
		return NULL;
	}
	job->serverUpdateMgr = duplicateString(tmp->valuestring);
	len += (int)(strlen("twUpdateMgr=") + strlen(tmp->valuestring) + 1);
	tmp = cJSON_GetObjectItem(json, "script");
	if (!tmp || !tmp->valuestring)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Missing script in json params");
		twSwUpdateJob_Delete(job);
		return NULL;
	}
	job->script = duplicateString(tmp->valuestring);
	tmp = cJSON_GetObjectItem(json, "path");
	if (!tmp || !tmp->valuestring)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Missing path in json params");
		twSwUpdateJob_Delete(job);
		return NULL;
	}
	/* This is the path on the SERVER */
	job->path = duplicateString(tmp->valuestring);

	tmp = cJSON_GetObjectItem(json, "scriptParams");
	if (tmp && tmp->type == cJSON_Object)
	{
		cJSON *avp = NULL;
		GsAppLog(GS_DEBUG, MODULE_GS_SCM, "twSwUpdateJob_Create: Converting scriptParams into a string");
		avp = tmp->child;
		/* First pass, get our length */
		while (avp)
		{
			if (!avp->string || !avp->valuestring)
				continue;
			len += (int)(strlen(avp->string) + strlen(avp->valuestring) + 2);
			avp = avp->next;
		}
		if (len)
		{
			job->scriptParams = (char *)TW_CALLOC(len + 1, 1);
			if (!job->scriptParams)
			{
				GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Error allocating memory for scriptParamString");
				twSwUpdateJob_Delete(job);
				return NULL;
			}
			/* Second pass, create the string. Flags need to come first */
			avp = cJSON_GetObjectItem(tmp, "flags");
			if (avp && avp->valuestring)
			{
				strcat(job->scriptParams, avp->valuestring);
			}
			/* Now add our built in params */
			strcat(job->scriptParams, " twId=");
			strcat(job->scriptParams, job->id);
			strcat(job->scriptParams, " twCampaign=");
			strcat(job->scriptParams, job->campaignName);
			strcat(job->scriptParams, " twEntity=");
			strcat(job->scriptParams, job->entityName);
			strcat(job->scriptParams, " twUpdateMgr=");
			strcat(job->scriptParams, job->serverUpdateMgr);
			/* Now do the rest */
			avp = tmp->child;
			while (avp)
			{
				if (!avp->string || !avp->valuestring)
					continue;
				/* We already added the flags, so skip them */
				if (strcmp("flags", avp->string) != 0)
				{
					strcat(job->scriptParams, " ");
					strcat(job->scriptParams, avp->string);
					strcat(job->scriptParams, "=");
					strcat(job->scriptParams, avp->valuestring);
				}
				avp = avp->next;
			}
		}
		GsAppLog(GS_DEBUG, MODULE_GS_SCM, "twSwUpdateJob_Create: Parameters to be passed to install function: %s", job->scriptParams);
	}
	else
	{
		GsAppLog(GS_DEBUG, MODULE_GS_SCM, "twSwUpdateJob_Create: No script parameters found.  Adding defaults");
		if (len)
		{
			job->scriptParams = (char *)TW_CALLOC(len + 1, 1);
			if (!job->scriptParams)
			{
				GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Error allocating memory for scriptParamString");
				twSwUpdateJob_Delete(job);
				return NULL;
			}
			/* Add our built in params */
			strcat(job->scriptParams, " twId=");
			strcat(job->scriptParams, job->id);
			strcat(job->scriptParams, " twCampaign=");
			strcat(job->scriptParams, job->campaignName);
			strcat(job->scriptParams, " twEntity=");
			strcat(job->scriptParams, job->entityName);
			strcat(job->scriptParams, " twUpdateMgr=");
			strcat(job->scriptParams, job->serverUpdateMgr);
		}
		GsAppLog(GS_DEBUG, MODULE_GS_SCM, "twSwUpdateJob_Create: Parameters to be passed to install function: %s", job->scriptParams);
	}
	/* 
	If we are using built in file transfer for downloads we may have to create a 
	virtual directory for the download for this Entity Name. This section is dependent
	on the built in File Transfer functions which may not be needed
	*/
#ifdef ENABLE_FILE_XFER
	if (!job->downloadFunc)
	{
		int len = (int)(strlen(g_pszSw_update_staging_dir) + 1 + strlen(entityName) + 1);
		int entityNameOffset = 0;
		job->downloadDir = (char *)TW_CALLOC(len, 1);
		if (!job->downloadDir)
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Error allocating memory for path");
			twSwUpdateJob_Delete(job);
			return NULL;
		}
		strcpy(job->downloadDir, g_pszSw_update_staging_dir);
		strcat(job->downloadDir, TW_FILE_DELIM_STR);
		if (entityName[0] == '*')
		{
			// Fix bug.
			entityNameOffset = 1; // skip 1st character.
		}
		strcat(job->downloadDir, entityName + entityNameOffset);
		if (twDirectory_CreateDirectory(job->downloadDir))
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Error creating directory for SW update download");
			twSwUpdateJob_Delete(job);
			return NULL;
		}
		if (twFileManager_AddVirtualDir(entityName, vdir, job->downloadDir))
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Create: Error creating virtual directory 'updates' for SW update download");
			twSwUpdateJob_Delete(job);
			return NULL;
		}
	}
#endif
	// Bug Fix:  add initializations
	job->downloadTime = 0; // force wait for ScheduleDownload invocation to set the dateTime.

	// Set the installDate at intialization and then use state machine 'state' flag to wait
	// for the ScheduleInstall invocation.
	tmp = cJSON_GetObjectItem(json, "installDate");
	if (tmp)
	{
		char timeStr[80];
		job->installTime = (DATETIME)tmp->valuedouble;
		twGetTimeString(job->installTime, timeStr, "%Y-%m-%d %H:%M:%S", 80, 1, 1);
		GsAppLog(GS_TRACE, MODULE_GS_SCM, "twSwUpdateJob_Create: Intall Time is %s",
				 timeStr);
	}
	else
	{
		// Incase of error in JSON, set install time to 'immedate' (once triggered by ScheduleInstall).
		job->installTime = 0;
	}

	return job;
} //> twSwUpdateJob_Create(...)

void twSwUpdateJob_Delete(void *job)
{
	twSwUpdateJob *tmp = (twSwUpdateJob *)job;
	if (!job)
		return;
	if (tmp->swuJobMtx)
		twMutex_Lock(tmp->swuJobMtx);
	/* Do an abort */
	if (tmp->installFunc && tmp->func_id == NULL)
		tmp->installFunc(tmp->script, tmp->id, tmp->entityName, tmp->campaignName,
						 tmp->serverUpdateMgr, tmp->path, tmp->downloadDir, &tmp->func_id, tmp->scriptParams, TRUE);
	if (tmp->entityName)
		TW_FREE(tmp->entityName);
	if (tmp->campaignName)
		TW_FREE(tmp->campaignName);
	if (tmp->serverUpdateMgr)
		TW_FREE(tmp->serverUpdateMgr);
	if (tmp->script)
		TW_FREE(tmp->script);
	if (tmp->path)
		TW_FREE(tmp->path);
	if (tmp->id)
		TW_FREE(tmp->id);
	if (tmp->downloadDir)
		TW_FREE(tmp->downloadDir);
	if (tmp->scriptParams)
		TW_FREE(tmp->scriptParams);
	if (tmp->swuJobMtx)
		twMutex_Unlock(tmp->swuJobMtx);
	twMutex_Delete(tmp->swuJobMtx);
	TW_FREE(tmp);
}

int twSwUpdateJob_SetDownloadTime(twSwUpdateJob *job, DATETIME time)
{
	char timeStr[80];
	if (!job || !time)
		return TW_INVALID_PARAM;
	twMutex_Lock(job->swuJobMtx);
	job->downloadTime = time;
	twMutex_Unlock(job->swuJobMtx);
	twGetTimeString(time, timeStr, "%Y-%m-%d %H:%M:%S", 80, 1, 1);
	GsAppLog(GS_TRACE, MODULE_GS_SCM, "twSwUpdateJob_SetDownloadTime: Dowload Time is %s",
			 timeStr);
	return TW_OK;
}

int twSwUpdateJob_SetInstallTime(twSwUpdateJob *job, DATETIME time)
{
	if (!job || !time)
		return TW_INVALID_PARAM;
	twMutex_Lock(job->swuJobMtx);
	job->installTime = time;
	twMutex_Unlock(job->swuJobMtx);
	return TW_OK;
}

int twSwUpdateJob_TakeAction(twSwUpdateJob *job, char *action, cJSON *params)
{
	if (!job || !action)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_TakeAction: Missing parameters");
		return TW_INVALID_PARAM;
	}
	twMutex_Lock(job->swuJobMtx);
	if (!strcmp(action, "abort"))
	{
		if (job->state == TW_SWUPDATE_DOWNLOADING)
		{
			if (job->downloadFunc)
			{
				/* Abort the download */
				job->downloadFunc(job->script, job->id, job->entityName, job->campaignName, job->serverUpdateMgr, job->path,
								  job->downloadDir, &job->func_id, job->scriptParams, TRUE);
			}
		}
		else if (job->state == TW_SWUPDATE_INSTALLING)
		{
			/* Abort the install */
			job->installFunc(job->script, job->id, job->entityName, job->campaignName, job->serverUpdateMgr, job->path,
							 job->downloadDir, &job->func_id, job->scriptParams, TRUE);
		}
		// Fix Bug:  Don't change state to aborted if it is done.
		if (!(job->state == TW_SWUPDATE_DONE || job->state == TW_SWUPDATE_COMPLETED || job->state == TW_SWUPDATE_FAILED))
			job->state = TW_SWUPDATE_ABORTED;
	}
	else if (!strcmp(action, "download"))
	{
		job->state = TW_SWUPDATE_START_DOWNLOAD;
	}
	else if (!strcmp(action, "downloaded"))
	{
		job->state = TW_SWUPDATE_DOWNLOADED;
	}
	else
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_TakeAction: Invalid action '%s' on job %s", action, job->id);
		twMutex_Unlock(job->swuJobMtx);
		return TW_ERROR;
	}
	twMutex_Unlock(job->swuJobMtx);
	return TW_OK;
}

enum twSwUpdateState twSwUpdateJob_GetState(twSwUpdateJob *job)
{
	enum twSwUpdateState tmp = TW_SWUPDATE_UNKNOWN;
	if (!job)
		return TW_SWUPDATE_UNKNOWN;
	twMutex_Lock(job->swuJobMtx);
	tmp = job->state;
	twMutex_Unlock(job->swuJobMtx);
	return tmp;
}

char twSwUpdateJob_StateHasChanged(twSwUpdateJob *job)
{
	char tmp = FALSE;
	if (!job)
		return FALSE;
	twMutex_Lock(job->swuJobMtx);
	tmp = (job->state != job->prev_state);
	job->prev_state = job->state;
	twMutex_Unlock(job->swuJobMtx);
	return tmp;
}

const char *twSwUpdateJob_GetStateString(enum twSwUpdateState state)
{
	switch (state)
	{
	case TW_SWUPDATE_CREATED:
		return "created";
		break;
	case TW_SWUPDATE_NOTIFIED:
		return "notified";
		break;
	case TW_SWUPDATE_WAIT_FOR_DOWNLOAD:
		return "wait_for_download";
		break;
	case TW_SWUPDATE_ABORTED:
		return "aborted";
		break;
	case TW_SWUPDATE_START_DOWNLOAD:
		return "start_download";
		break;
	case TW_SWUPDATE_DOWNLOADING:
		return "downloading";
		break;
	case TW_SWUPDATE_DOWNLOADED:
		return "downloaded";
		break;
	case TW_SWUPDATE_WAIT_FOR_INSTALL_COMMAND:
		return "wait_for_install command";
		break;
	case TW_SWUPDATE_WAIT_FOR_INSTALL_DATETIME:
		return "wait_for_install date-time.";
		break;
	case TW_SWUPDATE_INSTALLING:
		return "installing";
		break;
	case TW_SWUPDATE_COMPLETED:
		return "completed";
		break;
	case TW_SWUPDATE_FAILED:
		return "failed";
		break;
	case TW_SWUPDATE_DONE:
		return "done";
		break;
	default:
		return "unknown";
	}
}

void twSwUpdateJob_Process(twSwUpdateJob *job)
{
	enum twSwUpdateState s = TW_SWUPDATE_UNKNOWN;
	char *stateString = NULL;
	char *message = NULL;
	char *reason = NULL;
	char success = FALSE;
	char complete = FALSE;
	char resetActivity = TRUE;
	if (!job)
		return;
	twMutex_Lock(job->swuJobMtx);
	s = job->state;
	switch (s)
	{
	case TW_SWUPDATE_CREATED:
		stateString = "notified";
		job->state = TW_SWUPDATE_NOTIFIED;
		break;
	case TW_SWUPDATE_NOTIFIED:
		job->state = TW_SWUPDATE_WAIT_FOR_DOWNLOAD;
		break;
	case TW_SWUPDATE_WAIT_FOR_DOWNLOAD:
		if (job->downloadTime)
		{
			if (twTimeGreaterThan(twGetSystemTime(TRUE), job->downloadTime))
			{
				job->state = TW_SWUPDATE_START_DOWNLOAD;
			}
		}
		break;
	case TW_SWUPDATE_ABORTED:
		GsAppLog(GS_WARN, MODULE_GS_SCM, "twSwUpdateJob_Process: Aborting installation of job %s", job->id);
		if (job->installFunc)
		{
			job->installFunc(job->script, job->id, job->entityName, job->campaignName, job->serverUpdateMgr,
							 job->path, job->downloadDir, &job->func_id, job->scriptParams, TRUE);
		}
		else
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Process: No install funcntion defined");
			job->state = TW_SWUPDATE_ABORTED;
		}
		reason = "aborted";
		success = FALSE;
		stateString = "CompleteDeliveryTarget";
		complete = TRUE;
		job->state = TW_SWUPDATE_DONE;
		break;
	case TW_SWUPDATE_START_DOWNLOAD:
		if (job->downloadFunc)
		{
			int res = TW_OK;
			GsAppLog(GS_AUDIT, MODULE_GS_SCM, "twSwUpdateJob_Process: SW Update Job %s - downloading file with custom download function", job->id);
			res = job->downloadFunc(job->script, job->id, job->entityName, job->campaignName, job->serverUpdateMgr, job->path, job->downloadDir, &job->func_id, job->scriptParams, FALSE);
			if (res == TW_SWU_COMPLETE_SUCCESS)
				job->state = TW_SWUPDATE_DOWNLOADED;
			else if (res == TW_SWU_IN_PROGRESS)
			{
				job->state = TW_SWUPDATE_DOWNLOADING;
			}
			else
			{
				GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Process: Error downloading file with custom download function");
				job->state = TW_SWUPDATE_ABORTED;
			}
		}
		else
		{
			stateString = "downloading";
			job->state = TW_SWUPDATE_DOWNLOADING;
		}
		break;
	case TW_SWUPDATE_DOWNLOADING:
		if (job->downloadFunc)
		{
			int res = job->downloadFunc(job->script, job->id, job->entityName, job->campaignName, job->serverUpdateMgr,
										job->path, job->downloadDir, &job->func_id, job->scriptParams, FALSE);
			if (res == TW_SWU_COMPLETE_SUCCESS)
				job->state = TW_SWUPDATE_DOWNLOADED;
			else if (res == TW_SWUPDATE_DOWNLOADING)
			{
				job->state = TW_SWUPDATE_DOWNLOADING;
				resetActivity = FALSE;
			}
			else
			{
				GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Process: Error downloading file with custom download function");
				job->state = TW_SWUPDATE_FAILED;
			}
		}
		break;
	case TW_SWUPDATE_DOWNLOADED:
		stateString = "downloaded";
		// Bug Fix due to a bug in the ScheduleInstall service.
		// job->state = TW_SWUPDATE_WAIT_FOR_INSTALL;
		job->state = TW_SWUPDATE_WAIT_FOR_INSTALL_COMMAND;
		break;
	case TW_SWUPDATE_WAIT_FOR_INSTALL_COMMAND:
		// do nothing... just wait for ScheduleInstall service.
		break;
	case TW_SWUPDATE_WAIT_FOR_INSTALL_DATETIME:
		// Note:  installTime of 0 is an 'immediate install'.  This is not used.
		if (job->installTime == 0 || twTimeGreaterThan(twGetSystemTime(TRUE), job->installTime))
		{
			stateString = "installing";
			job->state = TW_SWUPDATE_INSTALLING;
		}
		break;
	case TW_SWUPDATE_INSTALLING:

		if (job->installFunc)
		{
			int res = job->installFunc(job->script, job->id, job->entityName, job->campaignName, job->serverUpdateMgr,
									   job->path, job->downloadDir, &job->func_id, job->scriptParams, FALSE);
			if (res == TW_SWU_COMPLETE_SUCCESS)
				job->state = TW_SWUPDATE_COMPLETED;
			else if (res == TW_SWU_IN_PROGRESS)
			{
				job->state = TW_SWUPDATE_INSTALLING;
				resetActivity = FALSE;
			}
			else
			{
				GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Process: Error installing update");
				job->state = TW_SWUPDATE_FAILED;
			}
		}
		else
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateJob_Process: No install funcntion defined");
			job->state = TW_SWUPDATE_ABORTED;
		}
		break;
	case TW_SWUPDATE_COMPLETED:
		reason = "completed";
		success = TRUE;
		stateString = "completed";
		complete = TRUE;
		job->state = TW_SWUPDATE_DONE;
		break;
	case TW_SWUPDATE_FAILED:
		reason = "failed";
		success = FALSE;
		stateString = "failed";
		complete = TRUE;
		job->state = TW_SWUPDATE_DONE;
		break;
	default:
		break;
	}
	if (resetActivity)
		job->lastActivity = twGetSystemTime(TRUE);
	twMutex_Unlock(job->swuJobMtx);
	if (stateString)
		swUpdateNotifyServer(job, stateString, complete, message, success, reason);
}
