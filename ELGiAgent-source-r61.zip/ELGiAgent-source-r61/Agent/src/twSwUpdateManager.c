//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  tsSwUpdateManager.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:
//      This code is the **Custom** C-SDK implementation of Software Content Management (SCM)
//      It should NOT be modified.
//      This code should be removed when the C-SDK release officially supports SCM.
//
//      >>>>>>>>>  For SCM details, see SCM_Task.c <<<<<<<<<<<
//
//*****************************************************************************

// Software Update includes.
#include "twSwUpdateManager.h"
#include "twSwUpdateJob.h"

#include "AgentConfig.h"
#include "twLogger.h"
#include "twInfoTable.h"
#include "twDefinitions.h"
#include "twApi.h"
#include "stringUtils.h"
#include "cJSON.h"

// software update global variables.  Originally in twConfig.
int32_t g_sw_update_idle_timeout = -1;
char *g_pszSw_update_staging_dir = NULL;

// local prototypes
/**
 * \brief Find a particular job in progress by its id.
 *
 * \param[in]     id     The id of the job.
 *
 * \return The job that matches the id, or a NULL if the job is not found.
 *
*/
twSwUpdateJob *twSwUpdateManager_FindJobById(const char *id);

/**
 * \brief Find a particular job in progress by its EntityName.
 *
 * \param[in]     id     The id of the job.
 *
 * \return The job that matches the EntityName, or a NULL if the job is not found.
 *
 * \note Assumes we are limited to one job at a time per entity
*/
twSwUpdateJob *twSwUpdateManager_FindJobByEntityName(const char *name);

/*****************************************/
/* Singleton SW Update Manager Structure */
/*****************************************/
typedef struct twSwUpdateManager
{
	char *vdir;						/**< The name of virtual directory where the update files are downloaded to. **/
	twList *updatesInProgress;		/**< The virtual path of the file. **/
	twList *stateChangeSubscribers; /**< The virtual path of the file. **/
	swupdate_func downloadFunc;		/**< Pointer to the function that should be used for downloads for each new SW Update Job **/
	swupdate_func installFunc;		/**< Pointer to the function that should be used for installation of the software for each new SW Update Job **/
	TW_MUTEX swuMgrMtx;
} twSwUpdateManager;

twSwUpdateManager *swupdate_mgr = NULL;

/********************************/
/*    Notification Struct       */
/********************************/
typedef struct twSwUpdateNotification
{
	char *name;
	swupdate_notify_func cb;
} twSwUpdateNotification;

twSwUpdateNotification *twSwUpdateNotification_Create(char *name, swupdate_notify_func cb)
{
	twSwUpdateNotification *tmp = NULL;
	if (!name || !cb)
		return NULL;
	tmp = (twSwUpdateNotification *)TW_CALLOC(sizeof(twSwUpdateNotification), 1);
	if (tmp)
	{
		tmp->name = duplicateString(name);
		tmp->cb = cb;
	}
	return tmp;
}

void twSwUpdateNotification_Delete(void *notification)
{
	if (notification)
	{
		twSwUpdateNotification *tmp = (twSwUpdateNotification *)notification;
		if (tmp->name)
			TW_FREE(tmp->name);
		TW_FREE(tmp);
	}
}

int Add_Remove_Notification(char *name, swupdate_notify_func func, char remove)
{
	ListEntry *le = NULL;
	twSwUpdateNotification *tmp = NULL;
	if (!swupdate_mgr)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "Add_Remove_Notification: SW Update manager not initialized");
		return TW_SWUPDATE_MANAGER_NOT_INITIALIZED;
	}
	if (!name || (!remove && !func))
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "Add_Remove_Notification: Name and callback function cannot be NULL");
		return TW_INVALID_PARAM;
	}
	twMutex_Lock(swupdate_mgr->swuMgrMtx);
	/* Check to see if this combo already exists. */
	le = twList_Next(swupdate_mgr->stateChangeSubscribers, NULL);
	while (le && le->value)
	{
		tmp = (twSwUpdateNotification *)le->value;
		if ((!remove && (tmp->cb == func)) && !strcmp(tmp->name, name))
		{
			/* name/value pair already exists. */
			if (remove)
			{
				twList_Remove(swupdate_mgr->stateChangeSubscribers, le, TRUE);
			}
			twMutex_Unlock(swupdate_mgr->swuMgrMtx);
			return TW_OK;
		}
		le = twList_Next(swupdate_mgr->stateChangeSubscribers, le);
	}
	if (!remove)
	{
		/* We were asked to add this notification and it doesn't already exist, so add it */
		tmp = twSwUpdateNotification_Create(name, func);
		if (!tmp)
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "Add_Remove_Notification: Error allocating memory for notification struc");
			twMutex_Unlock(swupdate_mgr->swuMgrMtx);
			return TW_ERROR_ALLOCATING_MEMORY;
		}
		twList_Add(swupdate_mgr->stateChangeSubscribers, tmp);
	}
	twMutex_Unlock(swupdate_mgr->swuMgrMtx);
	return TW_OK;
}

/********************************/
/*       Tasker Function        */
/********************************/
void twSwUpdateManager_TaskerFunction(DATETIME now, void *params)
{
	enum twSwUpdateState jobState = TW_SWUPDATE_UNKNOWN;
	/* We need to walk through our list of outstanding sw update jobs and process each one */
	ListEntry *le = NULL;
	if (!swupdate_mgr)
	{
		/* No SW Update manager - can't do anything */
		return;
	}
	twMutex_Lock(swupdate_mgr->swuMgrMtx);
	/* Check to see if this combo already exists. */
	le = twList_Next(swupdate_mgr->updatesInProgress, NULL);
	while (le && le->value)
	{
		twSwUpdateJob *job = (twSwUpdateJob *)le->value;
		twSwUpdateJob_Process(job);
		/* Look for a state change and notify if needed */
		jobState = twSwUpdateJob_GetState(job);
		if (twSwUpdateJob_StateHasChanged(job))
		{
			ListEntry *notify_le = NULL;
			notify_le = twList_Next(swupdate_mgr->stateChangeSubscribers, NULL);
			while (notify_le && notify_le->value)
			{
				twSwUpdateNotification *tmp = (twSwUpdateNotification *)notify_le->value;
				if (job->entityName && tmp->name && (!strcmp(tmp->name, job->entityName) || !strcmp(tmp->name, "*")))
				{
					/* We have a match, call the notify function */
					GsAppLog(GS_DEBUG, MODULE_GS_SCM, "twSwUpdateManager_TaskerFunction: Calling state change notification function for job %s.  State = %s",
							 job->id, twSwUpdateJob_GetStateString(job->state));
					tmp->cb(job);
				}
				notify_le = twList_Next(swupdate_mgr->stateChangeSubscribers, notify_le);
			}
		}
		/* Check for jobs that are just sitting idle and clean them up */
		if (g_sw_update_idle_timeout > 0)
		{
			if (twTimeGreaterThan(twGetSystemTime(TRUE), twAddMilliseconds(job->lastActivity, g_sw_update_idle_timeout)))
			{
				/* We have been idle too long */
				GsAppLog(GS_WARN, MODULE_GS_SCM, "twSwUpdateManager_TaskerFunction: Job %s has been idle for %d seconds.  Aborting the update.",
						 job->id, g_sw_update_idle_timeout / 1000);
				twSwUpdateJob_TakeAction(job, "abort", NULL);
			}
		}
		/* 
		Now check to see if this job is complete and all state changes have been 
		reported to the server.  If so, we should remove it from our list 
		*/
		if (jobState == TW_SWUPDATE_DONE || jobState == TW_SWUPDATE_UNKNOWN)
		{
			ListEntry *entryToDelete = le;
			GsAppLog(GS_DEBUG, MODULE_GS_SCM, "twSwUpdateManager_TaskerFunction: Deleting Job %s from Campaign %s for Thing %s",
					 job->id ? job->id : "UNKNOWN", job->campaignName ? job->campaignName : "UNKNOWN", job->entityName ? job->entityName : "UNKNOWN");
			le = le->prev;
			twList_Remove(swupdate_mgr->updatesInProgress, entryToDelete, TRUE);
		}
		le = twList_Next(swupdate_mgr->updatesInProgress, le);
	}
	twMutex_Unlock(swupdate_mgr->swuMgrMtx);
}

/********************************/
/*     Service Callbacks        */
/********************************/
char *swUpdateServices[] = {
	"TriggerUpdateAction", "ScheduleDownload", "ScheduleInstall", "SENTINEL"};

enum msgCodeEnum swUpdateServiceCallback(const char *entityName, const char *serviceName, twInfoTable *params, twInfoTable **content)
{
	enum msgCodeEnum retCode = TWX_NOT_FOUND;
	char *id = NULL;
	twSwUpdateJob *job = NULL;
	char *action = NULL;
	GsAppLog(GS_TRACE, MODULE_GS_SCM, "swUpdateServiceCallback - Function called");
	if (!params)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateServiceCallback - NULL params pointer");
		return TWX_BAD_REQUEST;
	}
	/* Make sure we have a SW update manager */
	if (!swupdate_mgr)
	{
		/* No SW Update manager - can't do anything */
		return TWX_PRECONDITION_FAILED;
	}

	// Fix Bug:  (at least keep callback locked during processing.
	twMutex_Lock(swupdate_mgr->swuMgrMtx);

	twInfoTable_GetString(params, "action", 0, &action);
	twInfoTable_GetString(params, "id", 0, &id);
	if (id)
	{
		job = twSwUpdateManager_FindJobById(id);
	}
	else
		job = twSwUpdateManager_FindJobByEntityName(entityName);
	if (!job && (!action || strcmp(action, "start")))
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateServiceCallback: Could not find existing update job for Thing %s with id %s",
				 entityName, id ? id : "NULL");
		if (id)
			TW_FREE(id);
		if (action)
			TW_FREE(action);
		retCode = TWX_NOT_FOUND;
		goto exitCallBack;
	}
	if (id)
		TW_FREE(id);
	if (strcmp(serviceName, "TriggerUpdateAction") == 0)
	{
		cJSON *json = NULL;
		char *jsonString = NULL;
		/* Need to have an action */
		if (!action)
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateServiceCallback: TriggerUpdateAction must contain an 'action' field");
			retCode = TWX_BAD_REQUEST;
			goto exitCallBack;
		}
		twInfoTable_GetString(params, "params", 0, &jsonString);
		if (!jsonString)
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateServiceCallback: TriggerUpdateAction must contain a 'params' field");
			TW_FREE(action);
			retCode = TWX_BAD_REQUEST;
			goto exitCallBack;
		}

		json = cJSON_Parse(jsonString);
		if (!json)
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateServiceCallback: Error parsing params field %s in TriggerUpdateAction", jsonString);
			TW_FREE(action);
			TW_FREE(jsonString);
			retCode = TWX_BAD_REQUEST;
			goto exitCallBack;
		}
		GsAppLog(GS_DEBUG, MODULE_GS_SCM, "swUpdateServiceCallback: TriggerUpdateAction executing action %s with params %s", action, jsonString);
		TW_FREE(jsonString);
		if (strcmp(action, "start") == 0)
		{
			twSwUpdateJob *job = NULL;
			/* Check to see if this Entity already has a job running */
			if (twSwUpdateManager_FindJobByEntityName(entityName))
			{
				GsAppLog(GS_WARN, MODULE_GS_SCM, "swUpdateServiceCallback: Already running a job for %s.  Cannot start a new one", entityName);
				cJSON_Delete(json);
				retCode = TWX_PRECONDITION_FAILED;
				goto exitCallBack;
			}
			/* We need to create a new job */
			GsAppLog(GS_DEBUG, MODULE_GS_SCM, "swUpdateServiceCallback: Creating new SW Update Job");
			job = twSwUpdateJob_Create(entityName, json, swupdate_mgr->vdir, swupdate_mgr->downloadFunc, swupdate_mgr->installFunc);
			if (!job)
			{
				GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateServiceCallback: Error creating new twSwUpdateJob");
				TW_FREE(action);
				cJSON_Delete(json);
				retCode = TWX_BAD_REQUEST;
				goto exitCallBack;
			}
			twList_Add(swupdate_mgr->updatesInProgress, job);
			cJSON_Delete(json);
			TW_FREE(action);
			retCode = TWX_SUCCESS;
			goto exitCallBack;
		}
		else
		{
			int res = TW_ERROR;
			GsAppLog(GS_DEBUG, MODULE_GS_SCM, "swUpdateServiceCallback: Taking action %s on job %s", action, job->id);
			res = twSwUpdateJob_TakeAction(job, action, json);
			TW_FREE(action);
			cJSON_Delete(json);
			if (res)
			{
				GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateServiceCallback: Error %d taking action %s on job %s", res, action, job->id);
				retCode = TWX_INTERNAL_SERVER_ERROR;
			}
			else
			{
				retCode = TWX_SUCCESS;
			}
			goto exitCallBack;
		}
	}
	else if (strcmp(serviceName, "ScheduleDownload") == 0)
	{
		DATETIME time = 0;
		DATETIME now = twGetSystemTime(TRUE);
		if (twInfoTable_GetDatetime(params, "time", 0, &time))
		{
			GsAppLog(GS_ERROR, MODULE_GS_SCM, "swUpdateServiceCallback: ScheduleDownload must contain a 'time' field");
			retCode = TWX_BAD_REQUEST;
			goto exitCallBack;
		}
		if (twSwUpdateJob_SetDownloadTime(job, time))
		{
			retCode = TWX_INTERNAL_SERVER_ERROR;
		}
		else
		{
			retCode = TWX_SUCCESS;
		}
		goto exitCallBack;
	}
	else if (strcmp(serviceName, "ScheduleInstall") == 0)
	{
		/*
        Bug Fix:
        There is a bug in the implementatino of the ScheduleInstall service:
        The 'time' field is marked as BaseType of NUMBER, instead of DATETIME.
        As a work-around, set the installTime at TriggerUpdateAction and in the 
        twSwUpdateJob_Process statemachine wait until this ScheduleInstall sets the 
        state to TW_SWUPDATE_WAIT_FOR_INSTALL_DATETIME.  This will actually waid
        for the install datetime to occur.  The original code simply ignored the install datetime.

		DATETIME time = 0;
        DATETIME now = twGetSystemTime(TRUE);
		if (twInfoTable_GetDatetime(params, "time", 0, & time)) {
			GsAppLog(GS_ERROR, MODULE_GS_SCM,"swUpdateServiceCallback: ScheduleInstall must contain a 'time' field");
			return TWX_BAD_REQUEST;
		}
		if (twSwUpdateJob_SetInstallTime(job, time)) {
			return TWX_INTERNAL_SERVER_ERROR;
		} else {
			return TWX_SUCCESS;
		}
        */
		twMutex_Lock(job->swuJobMtx);
		job->state = TW_SWUPDATE_WAIT_FOR_INSTALL_DATETIME;
		twMutex_Unlock(job->swuJobMtx);
		retCode = TWX_SUCCESS;
		goto exitCallBack;
	}
	retCode = TWX_NOT_FOUND;

exitCallBack:
	twMutex_Unlock(swupdate_mgr->swuMgrMtx);
	return retCode;
}

/********************************/
/*        API Functions         */
/********************************/
int twSwUpdateManager_Create()
{
	if (swupdate_mgr)
	{
		GsAppLog(GS_WARN, MODULE_GS_SCM, "twSwUpdateManager_Create: Singleton already created");
		return TW_OK;
	}
	swupdate_mgr = (twSwUpdateManager *)TW_CALLOC(sizeof(twSwUpdateManager), 1);
	if (!swupdate_mgr)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_Create: Error allocating SW Update Manager singleton");
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	swupdate_mgr->swuMgrMtx = GS_RecursiveMutex_Create();
	if (swupdate_mgr->swuMgrMtx)
	{
		twMutex_Lock(swupdate_mgr->swuMgrMtx);
		// Note:  the virtual directory is hardcode both here and in the SCM utility.
		swupdate_mgr->vdir = duplicateString("updates");
		swupdate_mgr->updatesInProgress = twList_Create(twSwUpdateJob_Delete);
		swupdate_mgr->stateChangeSubscribers = twList_Create(twSwUpdateNotification_Delete);
		swupdate_mgr->installFunc = DEFAULT_SW_UPATE_INSTALL_FUNC;
		swupdate_mgr->downloadFunc = DEFAULT_SW_UPATE_DOWNLOAD_FUNC;
		twMutex_Unlock(swupdate_mgr->swuMgrMtx);
	}
	if (!swupdate_mgr->swuMgrMtx || !swupdate_mgr->vdir || !swupdate_mgr->updatesInProgress || !swupdate_mgr->stateChangeSubscribers)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_Create: Error allocating mutex or tracking list");
		twSwUpdateManager_Delete();
		return TW_ERROR_ALLOCATING_MEMORY;
	}
#ifdef ENABLE_TASKER
	/* Initalize our tasker functon */
	twApi_CreateTask(50, &twSwUpdateManager_TaskerFunction);
#endif
	GsAppLog(GS_INFO, MODULE_GS_SCM, "twSwUpdateManager_Create: SoftwareUpdateManager Initialized");
	return TW_OK;
}

int twSwUpdateManager_Delete()
{
	if (!swupdate_mgr)
		return TW_OK;
	if (swupdate_mgr->swuMgrMtx)
		twMutex_Lock(swupdate_mgr->swuMgrMtx);
	if (swupdate_mgr->vdir)
		TW_FREE(swupdate_mgr->vdir);
	if (swupdate_mgr->updatesInProgress)
		twList_Delete(swupdate_mgr->updatesInProgress);
	if (swupdate_mgr->stateChangeSubscribers)
		twList_Delete(swupdate_mgr->stateChangeSubscribers);
	if (swupdate_mgr->swuMgrMtx)
		twMutex_Unlock(swupdate_mgr->swuMgrMtx);
	twMutex_Delete(swupdate_mgr->swuMgrMtx);
	TW_FREE(swupdate_mgr);
	swupdate_mgr = NULL;
	// Bug Fix:  change function name.
	GsAppLog(GS_DEBUG, MODULE_GS_SCM, "twSwUpdateManager_Delete: SoftwareUpdateManager deleted");
	return TW_OK;
}

int twSwUpdateManager_SetDefaultDownloadlDir(char *dirName)
{
	if (!swupdate_mgr)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_SetDefaultDownloadlDir: SW Update manager not initialized");
		return TW_SWUPDATE_MANAGER_NOT_INITIALIZED;
	}
	if (!dirName)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_SetDefaultDownloadlDir: dirName cannot be NULL");
		return TW_INVALID_PARAM;
	}
	twMutex_Lock(swupdate_mgr->swuMgrMtx);
	if (swupdate_mgr->vdir)
		TW_FREE(swupdate_mgr->vdir);
	swupdate_mgr->vdir = duplicateString(dirName);
	twMutex_Unlock(swupdate_mgr->swuMgrMtx);
	return TW_OK;
}

int twSwUpdateManager_SetDownloadlFunction(swupdate_func func)
{
	if (!swupdate_mgr)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_SetDownloadlFunction: SW Update manager not initialized");
		return TW_SWUPDATE_MANAGER_NOT_INITIALIZED;
	}
	twMutex_Lock(swupdate_mgr->swuMgrMtx);
	swupdate_mgr->downloadFunc = func;
	twMutex_Unlock(swupdate_mgr->swuMgrMtx);
	return TW_OK;
}

int twSwUpdateManager_SetInstallFunction(swupdate_func func)
{
	if (!swupdate_mgr)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_SetInstallFunction: SW Update manager not initialized");
		return TW_SWUPDATE_MANAGER_NOT_INITIALIZED;
	}
	if (!func)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_SetInstallFunction: Install function cannot be NULL");
		return TW_INVALID_PARAM;
	}
	twMutex_Lock(swupdate_mgr->swuMgrMtx);
	swupdate_mgr->installFunc = func; // fix bug
	twMutex_Unlock(swupdate_mgr->swuMgrMtx);
	return TW_OK;
}

int twSwUpdateManager_RegisterNotification(char *name, swupdate_notify_func func)
{
	return Add_Remove_Notification(name, func, FALSE);
}

int twSwUpdateManager_UnregisterNotification(char *name, swupdate_notify_func func)
{
	return Add_Remove_Notification(name, func, TRUE);
}

twSwUpdateJob *twSwUpdateManager_FindJobById(const char *id)
{
	ListEntry *le = NULL;
	twSwUpdateJob *job = NULL;
	if (!id)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_FindJobById: NULL id passed in");
		return NULL;
	}
	if (!swupdate_mgr)
	{
		/* No SW Update manager - can't do anything */
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_FindJobById: SW Update Manger not initialized");
		return NULL;
	}
	// Caller should lock mutex.
	/* Check to see if a job has this id. */
	le = twList_Next(swupdate_mgr->updatesInProgress, NULL);
	while (le && le->value)
	{
		twSwUpdateJob *tmp = (twSwUpdateJob *)le->value;
		if (!strcmp(tmp->id, id))
		{
			job = tmp;
			break;
		}
		le = twList_Next(swupdate_mgr->updatesInProgress, le);
	}

	return job;
}

twSwUpdateJob *twSwUpdateManager_FindJobByEntityName(const char *name)
{
	ListEntry *le = NULL;
	twSwUpdateJob *job = NULL;
	if (!name)
	{
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_FindJobByEntityName: NULL name passed in");
		return NULL;
	}
	if (!swupdate_mgr)
	{
		/* No SW Update manager - can't do anything */
		GsAppLog(GS_ERROR, MODULE_GS_SCM, "twSwUpdateManager_FindJobByEntityName: SW Update Manger not initialized");
		return NULL;
	}
	// Caller should lock mutex.
	// twMutex_Lock(swupdate_mgr->swuMgrMtx);
	/* Check to see if a job has this entityName. */
	le = twList_Next(swupdate_mgr->updatesInProgress, NULL);
	while (le && le->value)
	{
		twSwUpdateJob *tmp = (twSwUpdateJob *)le->value;
		if (!strcmp(tmp->entityName, name))
		{
			job = tmp;
			break;
		}
		le = twList_Next(swupdate_mgr->updatesInProgress, le);
	}
	// twMutex_Unlock(swupdate_mgr->swuMgrMtx);
	return job;
}

/** Bug Fix:  Enhancement:
    Add function to abort all jobs. 
    This is needed to manage loss of connection 
      1. Because Utilities SCM does not <currently> know how to manage a loss of connection.
      2. A job will get stuck in its current state because SCM doesn't give it the next transition.

     Note: Any message (service call) sent to the Platform will be persisted until the connection is established. 

     return:  true if one or more jobs were aborted.
              false if no jobs were aborted.

*/
char twSwUpdateManager_AbortJobs()
{
	ListEntry *le = NULL;
	char bJobsWereAborted = FALSE;
	if (!swupdate_mgr)
	{
		/* No SW Update manager - can't do anything */
		return bJobsWereAborted;
	}
	GsAppLog(GS_TRACE, MODULE_GS_SCM, "twSwUpdateManager_AbortJobs: Aborting all software update jobs.");

	twMutex_Lock(swupdate_mgr->swuMgrMtx);
	/* Check to see if this combo already exists. */
	le = twList_Next(swupdate_mgr->updatesInProgress, NULL);
	while (le && le->value)
	{
		twSwUpdateJob *job = (twSwUpdateJob *)le->value;
		twSwUpdateJob_TakeAction(job, "abort", NULL);
		le = twList_Next(swupdate_mgr->updatesInProgress, le);
		bJobsWereAborted = TRUE;
	}
	twMutex_Unlock(swupdate_mgr->swuMgrMtx);

	return bJobsWereAborted;
}

/** Bug Fix:  Enhancement:
    Add function to check if any jobs are being processed. 
    This is needed to know when there are not jobs being processed so that a modem can be disconnected.
*/
char twSwUpdateManager_IsJobInProcess()
{
	int count = 0;
	if (!swupdate_mgr)
		return FALSE;

	twMutex_Lock(swupdate_mgr->swuMgrMtx);
	/* Check to see if this combo already exists. */
	count = twList_GetCount(swupdate_mgr->updatesInProgress);
	twMutex_Unlock(swupdate_mgr->swuMgrMtx);
	return count ? TRUE : FALSE;
}
