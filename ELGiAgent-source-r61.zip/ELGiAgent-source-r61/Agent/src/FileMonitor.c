/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   :  FileMonitor.c
//
// //  Subsystem:  ELGiAgent
//
//
//  Description:
//
//              Callback for notification when a file download is completed.
//              Note: this is for a direct file download - not for a download that is part 
//                    of a SCM package. 
//
//              Specifically, this enables the updating of logging parameters without requiring an Agent restart.
//              The callback checks if the file download is the logging.json file;
//              if so, the logging parameters are re-initialized without requiring an Agent restart.
//
******************************************************************************/

#include "AgentConfig.h"
#include "FileMonitor.h"
#include "twFileTransferCallbacks.h"

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

/******************************************************************************
File transfer callback function 
******************************************************************************/
void OnFileCompleteCallbackFunc(char fileRcvd, twFileTransferInfo *info, void *userdata)
{
	// This enables updating the logging configurations without requiring a restart of the application.
	// Note:  This will only process a direct file download, not a SCM package download.
	if (strstr(info->sourceFile, STR_JSON_FILE_LOGGING) && strstr(info->targetPath, CONFIG_FOLDER_NAME))
	{
		GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Re-initializing logging options based on the downloaded %s file",
				 info->sourceFile);
		GsLog_ReInitializeLogOptions();
	}
}
