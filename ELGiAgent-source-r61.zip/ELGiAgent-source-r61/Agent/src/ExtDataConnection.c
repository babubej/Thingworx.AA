//--------------------------------------------------------------------------------------------------
/** @file ExtDataConnection.c
 *
 * Demonstrates opening a data connection
 * Author : Akshay
 * Copyright (C) Syratron Technologies Pvt.Ltd Bengaluru
 */
#include "AgentConfig.h"
#include "ExtDataConnection.h"
#include "ExtDataAcquisition.h"
#if !defined(LEGATO)
GS_BOOL g_bIsWaitingForConnection = FALSE;
#endif // LEGATO
#if defined(LEGATO)
#include "legato.h"
#include "le_data_interface.h"
#include "le_timer.h"
#include <curl/curl.h>
#include <time.h>
#include <stdbool.h>
#include "interfaces.h"

#define MODULE_PREFIX "Connectivity"

static void SetTechnologies(void)
{
    GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Setting cellular as data connection technology", MODULE_PREFIX);
    le_result_t cellular_result = le_data_SetTechnologyRank(1, LE_DATA_CELLULAR);
    if (LE_OK == cellular_result)
    {
        GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Cellular technology selected successfully", MODULE_PREFIX);
    }
    else
    {
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Failed to set cellular data connection technology", MODULE_PREFIX);
    }
} //> SetTechnologies()

void StartData_Connection(void);

#define TIMEOUT_SECS 30
#define SSL_ERROR_HELP "Make sure your system date is set correctly (e.g. `date -s '2016-7-7'`)"
#define SSL_ERROR_HELP_2 "You can check the minimum date for this SSL cert to work using: `openssl s_client -connect httpbin.org:443 2>/dev/null | openssl x509 -noout -dates`"

static le_timer_Ref_t s_mainTimerPtr = NULL;
static le_data_RequestObjRef_t s_objConnectionRef = NULL;
GS_BOOL g_bIsWaitingForConnection = FALSE;

static int s_numConnections = 0;
static int s_numDisconnections = 0;
static int s_numNoData = 0;
static le_sim_States_t s_simState;
static le_sim_Id_t simId = 1;
static le_mrc_NetRegState_t s_netRegStateId;
static int fc_count = 0;
le_result_t res;
char _deviceId[20];
static GS_BOOL s_bIsDataSuccess = FALSE;

const char *s_pszNetRegStateTitle[] = {
    "Not registered and not currently searching for new operator.",
    "Registered, home network.",
    "Not registered but currently searching for a new operator.",
    "Registration was denied, usually because of invalid access credentials.",
    "Registered to a roaming network.",
    "Unknown state.",
    NULL};

const char *s_pszSimStateTitle[] = {
    "SIM card is inserted and locked.",
    "SIM card is absent.",
    "SIM card is inserted and unlocked.",
    "SIM card is blocked.",
    "SIM card is busy.",
    "SIM card is powered down.",
    "Unknown SIM state.",
    NULL};

/* Check states
 * --> sim state --> network registration state --> data connection
 */
void ConnectionCheckState(void)
{
    GsAppLog(GS_DEBUG, MODULE_GS_CONFIG, "%s: Checking connection & sim state...", MODULE_PREFIX);
    // check whether sim is ready or no
    s_simState = le_sim_GetState(simId);
    if (s_simState == LE_SIM_READY || s_simState == LE_SIM_INSERTED)
    {
        GsAppLog(GS_DEBUG, MODULE_GS_CONFIG, "%s: Sim card is inserted & ready. Checking network registration state...", MODULE_PREFIX);
        // check whether sim is registered to network or no
        res = le_mrc_GetNetRegState(&s_netRegStateId);
        if (s_netRegStateId <= (int)LE_MRC_REG_UNKNOWN)
        {
            GsAppLog(GS_DEBUG, MODULE_GS_CONFIG, "%s: Network registration state: '%s'", MODULE_PREFIX, s_pszNetRegStateTitle[s_netRegStateId]);
        }
        if (s_netRegStateId == LE_MRC_REG_HOME)
        {
            if (g_bIsWaitingForConnection) // check if there is disconnection
            {
                GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Couldn't establish connection after " STRINGIZE(TIMEOUT_SECS) " seconds", MODULE_PREFIX);
                //  exit(EXIT_FAILURE);
                GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Reconnections counter: %d", MODULE_PREFIX, (s_numDisconnections++));
                StartData_Connection();
            }
            else // else the data connection is active
            {
                GsAppLog(GS_DEBUG, MODULE_GS_CONFIG, "%s: Data uninterrupted counter: %d", MODULE_PREFIX, (s_numConnections++));
                GsAppLog(GS_DEBUG, MODULE_GS_CONFIG, "%s: Data connection is ACTIVE!", MODULE_PREFIX);
            }
        }
        else // when the sim registration is interrupted
        {
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Something went wrong in Sim registration...", MODULE_PREFIX);
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: No data service... count=%d", MODULE_PREFIX, s_numNoData++);
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Reconnections counter: %d", MODULE_PREFIX, (s_numDisconnections++));
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Network registration state: '%s'", MODULE_PREFIX, s_pszNetRegStateTitle[s_netRegStateId]);
        }
    }
    else // in case if sim is interrupted
    {
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Reconnections counter: %d", MODULE_PREFIX, (s_numDisconnections++));
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: There's an issue with the Sim state - please check sim card insertion.", MODULE_PREFIX, s_pszSimStateTitle[s_simState]);
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Current Sim state: '%s'", MODULE_PREFIX, s_pszSimStateTitle[s_simState]);
        if (s_simState != LE_SIM_READY && s_simState != LE_SIM_INSERTED)
        {
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: No data service... count=%d", MODULE_PREFIX, s_numNoData++);
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Data connection is ACTIVE!", MODULE_PREFIX);
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Entering software Sim detect pin process...", MODULE_PREFIX);
            le_sim_SelectCard(0);
            twSleepMsec(5000);
            le_sim_SelectCard(1);
        }
    }
} //> ConnectionCheckState()
//>----------------------------------------------------------------------------

static size_t PrintCallback(
    void *bufferPtr, size_t size,
    size_t nbMember,
    void *userData // unused, but can be set with CURLOPT_WRITEDATA
)
{
    printf("Succesfully received data:");
    s_bIsDataSuccess = TRUE;
    fwrite(bufferPtr, size, nbMember, stdout);
    return size * nbMember;
} //> PrintCallback(...)
//>----------------------------------------------------------------------------

static void GetUrl(const char *inputUrl)
{
    CURL *curl;
    CURLcode res;
    curl = curl_easy_init();
    if (curl)
    {
        GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Url: %s", MODULE_PREFIX, inputUrl);
        //curl_easy_setopt(curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        s_bIsDataSuccess = FALSE;
        curl_easy_setopt(curl, CURLOPT_URL, inputUrl);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, PrintCallback);
        //curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
        res = curl_easy_perform(curl);
        if (res != CURLE_OK)
        {
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: curl_easy_perform() failed: %s", MODULE_PREFIX, curl_easy_strerror(res));
            if (res == CURLE_SSL_CACERT)
            {
                GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: %s", MODULE_PREFIX, SSL_ERROR_HELP);
                GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: %s", MODULE_PREFIX, SSL_ERROR_HELP_2);
            }
        }
        curl_easy_cleanup(curl);
    }
    else
    {
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "%s: Couldn't initialize cURL.", MODULE_PREFIX);
    }
    curl_global_cleanup();
} //> GetUrl()
//>----------------------------------------------------------------------------

/**
 * Callback for the timeout timer
 */
static void TimeoutHandler(le_timer_Ref_t timerRef)
{
    ConnectionCheckState();
    if (!g_bIsWaitingForConnection)
    {
    }
    RTC_Synchronize();
    if (g_bReceivedShutdownSignal)
    {
        // https://docs.legato.io/latest/c_timer.html#timer_objects
        // It's mentioned that it is alright to call timer Stop/Delete
        // from within the handler function, so there won't be any
        // cross thread issues when calling Legato API.
        // It's guaranteed that this handler is managed inside
        // Legato specific code.
        ExtDataConnection_Shutdown();
    }
} //> TimeoutHandler(...)
//>----------------------------------------------------------------------------

void StartFirewall_Script(void)
{
    /*	system("/usr/bin/iptables -F && iptables -I INPUT -j ACCEPT");
	system("iptables -t nat -A POSTROUTING --out-interface rmnet_data0 -j MASQUERADE");
	system("iptables -A FORWARD -o ecm0 -i rmnet_data0 -m state --state RELATED,ESTABLISHED -j ACCEPT");
	system("iptables -A FORWARD -i ecm0 -o rmnet_data0 -j ACCEPT");
	system("echo 1 > /proc/sys/net/ipv4/ip_forward");
	*/
    system("/legato/systems/current/appsWriteable/ELGiAgent/bin/cfg_Modem.sh");
    GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Internet is connected. Modem is configured.", MODULE_PREFIX);
} //> StartFirewall_Script()
//>----------------------------------------------------------------------------

/**
 * Callback for when the connection state changes
 */
static void ConnectionStateHandler(const char *intfName, bool isConnected, void *contextPtr)
{
    if (isConnected)
    {
        g_bIsWaitingForConnection = FALSE;
        GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Interface %s connected. No longer waiting for the connection.", MODULE_PREFIX, intfName);
        StartFirewall_Script();
        RTC_Synchronize();
    }
    else
    {
        g_bIsWaitingForConnection = TRUE;
        GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Interface %s disconnected.", MODULE_PREFIX, intfName);
    }
} //> ConnectionStateHandler(...)
//>----------------------------------------------------------------------------

void StartData_Connection(void)
{
    GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Requesting data connection...", MODULE_PREFIX);
    if (fc_count == 0)
    {
        GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: adding resolve.conf", MODULE_PREFIX);
        system("/bin/touch /etc/resolv.conf");
        fc_count++;
    }
    s_objConnectionRef = le_data_Request();
} //> StartData_Connection()
//>----------------------------------------------------------------------------

void ExtDataConnection_Initialize(void)
{
    GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Starting Data Connection Subsystem", MODULE_PREFIX);

    SetTechnologies();
    s_mainTimerPtr = le_timer_Create("Connection timeout timer");

    le_clk_Time_t interval = {TIMEOUT_SECS, 2};
    le_timer_SetInterval(s_mainTimerPtr, interval);
    le_timer_SetRepeat(s_mainTimerPtr, 0);
    le_timer_SetHandler(s_mainTimerPtr, &TimeoutHandler);
    g_bIsWaitingForConnection = TRUE;
    le_timer_Start(s_mainTimerPtr);
    le_data_AddConnectionStateHandler(&ConnectionStateHandler, NULL);

    ConnectionCheckState();
} //> ExtDataConnection_Initialize()
//>----------------------------------------------------------------------------

void ExtDataConnection_Shutdown(void)
{
    GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Stopping Data Connection Timers", MODULE_PREFIX);
    le_data_RemoveConnectionStateHandler(&ConnectionStateHandler);
    le_timer_Stop(s_mainTimerPtr);
    le_timer_Delete(s_mainTimerPtr);
} //> ExtDataConnection_Shutdown()
//>----------------------------------------------------------------------------

#endif // LEGATO
