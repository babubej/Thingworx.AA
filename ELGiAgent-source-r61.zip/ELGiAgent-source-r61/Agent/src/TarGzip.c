//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  TarGzip.c
//
// //  Subsystem:  ELGiAgent
//
//  Description:  Utility to list and extract the content of a tar.gz archive file.
//                For this application, the ThingWorx Software Content Management application
//                must download an archive using a tar.gz format.
//
//                This uses the libtar library that is available in the folder:
//                AgentLibraries\<OS-processor specific folder>\lib.
//
//*****************************************************************************

#include "AgentConfig.h"
#include "TarGzip.h"
#include "libtar.h"
#include "zlib.h"
#include <fcntl.h>
#include <errno.h>

#if defined(LINUX)
// On Windows INT_PTR/UINT_PTR definitions can be found in basestd.h header.
// INT_PTR and UINT_PTR should be used to replace signed/unsigned int in
// declaration of integers that store pointers.
#if defined(_LP64) || defined(__LP64__)
typedef long INT_PTR;
typedef unsigned long UINT_PTR;
#else
typedef int INT_PTR;
typedef unsigned int UINT_PTR;
#endif
#endif

extern wchar_t *convertToWide(const char *in); // in twWindows.h

// 'C' prototype
INT_PTR gzopen_frontend(char *pathname, int oflags, int mode);

// Use GZip open, close, read, write functions directly with TAR.
tartype_t gztype = {(openfunc_t)gzopen_frontend, (closefunc_t)gzclose,
                    (readfunc_t)gzread, (writefunc_t)gzwrite};

//*****************************************************************************
// Extract from Tar-GZip files to the destination folders defined in the TAR file.
// All extractions are relative to the Agent's root directory (where the binary executable resides).
int TarGzip_Extract(char *pszZipFileName, char *pszDestinationDir)
{
    // use temporary string to allow changes to input parameters.
    char *pszTempFileName = NULL;
    char *pszTempDestDir = NULL;
    int tempFileNameLen = 0;
    int tempDestDirLen = 0;
    TAR *pTar = NULL;
    char *pszEndOfDest = NULL;
    int retCode = TW_OK;

    // Check that there are names.
    if (pszZipFileName == NULL || pszDestinationDir == NULL || strlen(pszZipFileName) == 0 || strlen(pszDestinationDir) == 0)
        return TW_INVALID_PARAM;

    tempFileNameLen = (int)strlen(pszZipFileName);
    tempDestDirLen = (int)strlen(pszDestinationDir);

    // Check all filenames to make sure within acceptable length.
    if (tempFileNameLen >= T_MAXPATHLEN || tempDestDirLen >= T_MAXPATHLEN)
        return GS_TARGZIP_FILENAME_TOO_LONG;

    pszTempFileName = (char *)TW_CALLOC(tempFileNameLen + 10, 1);
    pszTempDestDir = (char *)TW_CALLOC(tempDestDirLen + 10, 1);
    strcpy(pszTempFileName, pszZipFileName);
    strcpy(pszTempDestDir, pszDestinationDir);

    // If no defined extension, then default to .tar.gz
    if (strrchr(pszTempFileName, '.') == NULL)
    {
        strcat(pszTempFileName, ".tar.gz");
    }

    // Open TAR-Gzip file (GZip happens automatically  via use of gztype).
    if (tar_open(&pTar, pszTempFileName, &gztype, O_RDONLY, 0, TAR_GNU) == -1)
    {
        retCode = TW_ERROR_READING_FILE;
        goto cleanReturn;
    }

    // Unzip and Extract all files to the destination directory.
    // Don't allow trailing delimiter.  Taken care of by TAR.
    pszEndOfDest = &pszTempDestDir[strlen(pszTempDestDir) - 1];
    if (*pszEndOfDest == '\\' || *pszEndOfDest == '/')
        *pszEndOfDest = '\0';
    // Note:  This will overwrite any files that are not actively being used by a process.
    if (tar_extract_all(pTar, pszTempDestDir) != 0)
    {
        tar_close(pTar);
        retCode = GS_TARGZIP_EXTRACTION_FAILURE;
        goto cleanReturn;
    }

    if (tar_close(pTar) != 0)
        retCode = GS_TARGZIP_FILE_FAILURE;

cleanReturn:
    TW_FREE(pszTempFileName);
    TW_FREE(pszTempDestDir);

    return retCode;
}

//*****************************************************************************
// List the files in the Tar-GZip file; output contained in pListFiles.
// Note:  file names are converted to use the correct OS path delimiter.
int TarGzip_List(char *pszZipFileName, twList *pListFiles)
{
    char *pszTempFileName = NULL;
    TAR *pTar = NULL;
    int i = 0;
    int retCode = TW_OK;

    // Check that there are names.
    if (pszZipFileName == NULL)
        return TW_INVALID_PARAM;

    // Check all filenames to make sure within acceptable length.
    if (strlen(pszZipFileName) >= T_MAXPATHLEN)
        return GS_TARGZIP_FILENAME_TOO_LONG;

    pszTempFileName = (char *)TW_CALLOC(strlen(pszZipFileName) + 10, 1);
    strcpy(pszTempFileName, pszZipFileName);

    // If no defined extension, then default to .tar.gz
    if (strrchr(pszTempFileName, '.') == NULL)
    {
        strcat(pszTempFileName, ".tar.gz");
    }

    if (tar_open(&pTar, pszTempFileName, &gztype, O_RDONLY, 0, TAR_GNU) == -1)
    {
        retCode = TW_ERROR_READING_FILE;
        goto cleanReturn;
    }

    while ((i = th_read(pTar)) == 0)
    {
        // Get the filename, convert path to OS specific delimiters and save in the list.
        char *pszFileNameEntry = GsConvertPath(th_get_pathname(pTar));
        twList_Add(pListFiles, pszFileNameEntry);
        if (TH_ISREG(pTar) && tar_skip_regfile(pTar) != 0)
        {
            tar_close(pTar);
            retCode = GS_TARGZIP_LIST_FAILURE;
            goto cleanReturn;
        }
    }
    if (tar_close(pTar) != 0)
        retCode = GS_TARGZIP_LIST_FAILURE;
cleanReturn:
    TW_FREE(pszTempFileName);
    return retCode;
}

//*****************************************************************************
// This is used in the tartype_t for the TAR "open" function.
INT_PTR gzopen_frontend(char *pathname, int oflags, int mode)
{
    char *gzoflags;
    gzFile gzf;
    int fd;
    wchar_t *pszRealPathname = NULL;

    switch (oflags & O_ACCMODE)
    {
    case O_WRONLY:
        gzoflags = "wb";
        break;
    case O_RDONLY:
        gzoflags = "rb";
        break;
    default:
    case O_RDWR:
        errno = EINVAL;
        return -1;
    }

#ifdef WIN32
    // UTF-8 decode the file name
    pszRealPathname = convertToWide(pathname);
    if (pszRealPathname)
    {
        fd = _wopen(pszRealPathname, oflags, mode);
        TW_FREE(pszRealPathname);
        ;
    }
    else
        fd = -1;
#else
    oflags |= O_LARGEFILE;
    fd = open(pathname, oflags, mode);
#endif

    if (fd == -1)
        return -1;

    gzf = gzdopen(fd, gzoflags);
    if (!gzf)
    {
        errno = ENOMEM;
        return -1;
    }

    return (INT_PTR)gzf;
}
