// *****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
// *****************************************************************************
//
//  Filename   :  DataSimulatorMgr.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Data simulator as an example data source for an Edge application.
//      Following the patten of the simulator is a recommended starting place for writing your own data source.
//
//      The workflow of the data simulator is as follows:
//      - Read  the JSON configuration file.  See:  DataSimulatorMrg_ReadConfiguration().
//      - Follow standard pattern for a functional module with global functions for:  initialize, start and shutdown
//        - DataSimulatorMgr_Initialize():
//          *  Register all properties with the ThingWorx Sever.
//          *  Create the (locally) global thread structure
//        - DataSimulatorMgr_Start():
//          *  Start the data source's thread.  This thread will now do all the work of acquiring
//        - DataSimulatorMgr_Shutdown():
//          *  Stop the acquistion thread.
//          *  Unregister all properties
//          *  Free any global memory
//      - Acquistion thread workflow
//          * Stay in thread loop until the system is shutdown (not running)
//          * Acquire data.
//          * Create a list of all properties that represent your acquired data
//          * Publish the list of properties via the Data Publishing Mgr.
//          * reset the thread 'wait' time to maintain an consistent rate of acquisition.
//
// *****************************************************************************

#include "AgentConfig.h"
#include "configParams.h"
#include "DataSimulatorMgr.h"
#include "DataPublishingMgr.h"

#if defined(LEGATO)
#include "ExtDataAcquisition.h"
#endif // LEGATO

#define MAX_PROP_NAME_LEN 100
#define TIME_BUFFER_SIZE (32)
#define FILE_OUTPUT_BUFFER_SIZE (1024)

// global variables
GS_BOOL g_bSimulatorEnabled = FALSE;

// private (locally global) variables
// Note: if used, must define identifier by prepending an '*'.
static GsThreadStruct *g_pDataSimThreadStruct = NULL;
static DATETIME g_dataSimWakeupTime = 0;
static char g_szPropertyName[MAX_PROP_NAME_LEN];
static propertyList *g_dataSimProperyList = NULL;
static char *g_pszSimulatorThroughtputFilename = NULL;

static int g_numOfProperties = 0;
static char *g_pszBasePropName = NULL;
static unsigned int g_acquisitionRate = 5000;
static int g_numOfSeedValues = 0;
static int *g_pSeedValues = NULL; // array of seed values.

// function prototypes
THREAD_FUNCTION_RETURN DataSimThreadFunction(void *pVoid);

// Register a  property with the ThingWorx server.
static void RegisterDataSimProperty(char *pszPropertyName, enum BaseType propertyType);
// Unregister a property with the ThingWorx server.
static void UnregisterDataSimProperty(char *pszPropertyName);
// Callback invoked by a proeprty write.
enum msgCodeEnum DataSim_PropertyCallback(const char *entityName, const char *pszPropertyName,
                                          twInfoTable **ppInfoTable, char isWrite, void *pUserdata);
static void SimulateData(int seed);
static void SimulateErrorEvent();
static void AcquireAndPublishProperties(int maxProperties, int seed);
// creates simulater property name
static void GetSimName(int ix, /* output */ char *pszName);
// creates simulator property value.  Value is the index of the property + seed value.
static int GetSimValue(int ix, int seedValue);
static void UpdatePropertyList(propertyList **ppPropertylist, char *pszName, int value, DATETIME dt);

// string definitions
static char *STR_SIMULATOR_FILE_NAME = "simulator.json";
static char *STR_SIMULATOR_VERSION = "version";
static char *STR_SIMULATOR_ENABLED = "simulator_enabled";
static char *STR_NUM_PROPERTIES = "num_properties";
static char *STR_BASE_PROPERTY_NAME = "base_property_name";
static char *STR_SEED_VALUES = "seed_values";
static char *STR_ACQUISITION_RATE_MS = "acquisition_rate_ms";

static int SIMULATOR_VERSION = 1;

// *****************************************************************************
//   **********************   Global  Functions   *****************************
// *****************************************************************************

// *****************************************************************************
/* example simulator configuration file:

{
	"version": 1,
	"simulator_enabled": 1,
	"num_properties": 150,
	"base_property_name": "Prop",
	"seed_values": [1, 100, 500, 1000],
	"acquisition_rate_ms": 1000,
	"publishing": {
		"use_SCM": 1,
		"use_infotable_direct": 1
	},
}

*/
int DataSimulatorMrg_ReadConfiguration()
{
    cJSON *pJsonRoot = NULL;
    cJSON *pJsonTemp = NULL;
    cJSON *pJsonSeedValues = NULL;
    cJSON *pJsonPublishingValues = NULL;
    char *pszSimulatorFilePath = NULL;
    char *pszSimulatorContent = NULL;
    int retCode = TW_ERROR_READING_FILE;
    int i = 0;

    // Read the simulator json configuration file
    pszSimulatorFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, STR_SIMULATOR_FILE_NAME);
    if (!twDirectory_FileExists(pszSimulatorFilePath))
    {
        GsAppLog(GS_TRACE, MODULE_GS_DATA, "DataSimulator: Cannot open the file: %s.",
                 pszSimulatorFilePath);
        TW_FREE(pszSimulatorFilePath);
        return TW_NOT_FOUND;
    }

    pszSimulatorContent = GsReadFileContent(pszSimulatorFilePath);
    pJsonRoot = cJSON_Parse(pszSimulatorContent);
    TW_FREE(pszSimulatorContent);
    if (!pJsonRoot)
    {
        GsAppLog(GS_WARN, MODULE_GS_DATA, "DataSimulator: File %s invalid JSON.",
                 pszSimulatorFilePath);
        goto CLEAN_EXIT;
    }

    // Verify version information
    pJsonTemp = GsVerifyJSONContent(pJsonRoot, STR_SIMULATOR_VERSION);
    if (!pJsonTemp || pJsonTemp->valueint != SIMULATOR_VERSION)
    {
        GsAppLog(GS_WARN, MODULE_GS_DATA, "DataSimulator: File %s must be version %i.",
                 pszSimulatorFilePath, SIMULATOR_VERSION);
        goto CLEAN_EXIT;
    }

    // Get required simulator enabled field
    pJsonTemp = GsVerifyJSONContent(pJsonRoot, STR_SIMULATOR_ENABLED);
    if (!pJsonTemp)
        goto CLEAN_EXIT;

    // If the simulator is not enabled, no need to read the rest of the file.
    // Note:  the entire file must be read successfully for the simulator to be enabled.
    if (pJsonTemp->valueint != 1)
    {
        retCode = TW_OK;
        goto CLEAN_EXIT;
    }

    // Get number of properties to simulate.
    pJsonTemp = GsVerifyJSONContent(pJsonRoot, STR_NUM_PROPERTIES);
    if (!pJsonTemp)
        goto CLEAN_EXIT;
    g_numOfProperties = pJsonTemp->valueint;

    // Get the base property name.
    pJsonTemp = GsVerifyJSONContent(pJsonRoot, STR_BASE_PROPERTY_NAME);
    if (!pJsonTemp || pJsonTemp->valuestring == NULL)
        goto CLEAN_EXIT;
    g_pszBasePropName = GsStringDup(pJsonTemp->valuestring);

    // Get the seed values for the simulator.
    pJsonSeedValues = GsVerifyJSONContent(pJsonRoot, STR_SEED_VALUES);
    if (!pJsonSeedValues)
        goto CLEAN_EXIT;

    // allocatin & populate the seed array
    g_numOfSeedValues = cJSON_GetArraySize(pJsonSeedValues);
    g_pSeedValues = (int *)TW_MALLOC(sizeof(int) * g_numOfSeedValues);
    for (i = 0; i < g_numOfSeedValues; i++)
    {
        g_pSeedValues[i] = cJSON_GetArrayItem(pJsonSeedValues, i)->valueint;
    }

    // Get the acquisition rate.
    pJsonTemp = GsVerifyJSONContent(pJsonRoot, STR_ACQUISITION_RATE_MS);
    if (!pJsonTemp)
        goto CLEAN_EXIT;
    g_acquisitionRate = pJsonTemp->valueint;

    // all parameters have been successfully read.  Enable the simulator.
    g_bSimulatorEnabled = TRUE;

    GsAppLog(GS_INFO, MODULE_GS_DATA, "DataSimulator: The simulator is successfully enabled and configured per file %s.",
             pszSimulatorFilePath);

    retCode = TW_OK;

CLEAN_EXIT:
    TW_FREE(pszSimulatorFilePath);
    cJSON_Delete(pJsonRoot);
    return retCode;
}

// *****************************************************************************
void DataSimulatorMgr_Initialize()
{
    int i;
    int err = TW_OK;
    if (!g_bSimulatorEnabled)
        return;

    // register all simulated property names
    for (i = 1; i <= g_numOfProperties; i++)
    {
        // value is ignored.
        GetSimName(i, g_szPropertyName);
        RegisterDataSimProperty(g_szPropertyName, TW_INTEGER);
    }
    // Create thread structure
    g_pDataSimThreadStruct = GsCreateThreadStruct();
    g_pDataSimThreadStruct->m_waitMilliSec = g_acquisitionRate; // wait before starting 1st acquisition.
}

// *****************************************************************************
int DataSimulatorMgr_Start()
{
    if (!g_bSimulatorEnabled)
        return TW_OK;
    // start the thread
    GsAppLog(GS_TRACE, MODULE_GS_DATA, "DataSimulatorMgr:  Initiate start of thread");
    GsStartThread(g_pDataSimThreadStruct, DataSimThreadFunction);
    return TW_OK;
}

// *****************************************************************************
void DataSimulatorMgr_Shutdown()
{
    int i;
    if (!g_bSimulatorEnabled)
        return;

    // stop DataSim data acquisition and clean up memory.
    GsAppLog(GS_TRACE, MODULE_GS_DATA, "DataSimulatorMgr:  Initiate shutdown");
    GsStopThread(g_pDataSimThreadStruct);
    GsDestroyThreadStruct(g_pDataSimThreadStruct);
    TW_FREE(g_pszSimulatorThroughtputFilename);
    if (g_bSimulatorEnabled)
    {
        // unregister all simulated property names
        for (i = 1; i <= g_numOfProperties; i++)
        {
            GetSimName(i, g_szPropertyName);
            UnregisterDataSimProperty(g_szPropertyName);
        }
    }
    // clean up memory.
    TW_FREE(g_pszBasePropName);
    TW_FREE(g_pSeedValues);
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "DataSimulatorMgr:  shutdown complete");
}

// *****************************************************************************
// Register a DataSim property with the ThingWorx server.
// This is only requried for writable properties.
void RegisterDataSimProperty(char *pszPropertyName, enum BaseType propertyType)
{
    twApi_RegisterProperty(TW_THING, g_pszThingIdentifier, pszPropertyName,
                           propertyType, NULL, TW_PUSH_TYPE_ALWAYS, 0,
                           DataSim_PropertyCallback, (void *)NULL);
}

// *****************************************************************************
// Unregister a DataSim property with the ThingWorx server.
// This is only requried for writable properties.
void UnregisterDataSimProperty(char *pszPropertyName)
{
    twApi_UnregisterPropertyCallback(g_pszThingIdentifier, pszPropertyName, (void *)NULL);
}

// *****************************************************************************
// Callback invoked by a proeprty write.
enum msgCodeEnum DataSim_PropertyCallback(const char *entityName, const char *pszPropertyName,
                                          twInfoTable **ppInfoTable, char isWrite, void *pUserdata)
{
    enum msgCodeEnum returnCode = TWX_BAD_OPTION;
    GsAppLog(GS_TRACE, MODULE_GS_DATA, "DataSimulatorMgr: Received callback for unsupported property write of: %s",
             pszPropertyName);
    return returnCode;
}

// *****************************************************************************
//   *********************   Support  Functions   *****************************
// *****************************************************************************

// *****************************************************************************
// Thread to manage all DataSim data acquisition.
//
THREAD_FUNCTION_RETURN DataSimThreadFunction(void *pVoid)
{
    int seedIx = 0;
    int waitReturnCondition = WAIT_OBJECT_0;
    GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid; // The void* parameter is always the thread struct pointer
    GsAppLog(GS_FORCE, MODULE_GS_DATA, "DataSimulatorMgr:  Data Simulator is enabled.");

    if (!pGsThreadStruct)
    {
        GsAppLog(GS_ERROR, MODULE_GS_DATA, "DataSimulatorMgr:  Thread initialiation error.  Exiting thread.");
        return (THREAD_FUNCTION_RETURN)-1;
    }
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataSimulatorMgr:  Thread started.  Thread id = %x (hex)", pGsThreadStruct->m_threadId);
#if defined(LEGATO)
    le_thread_InitLegatoThreadData("DataSimulatorMgr");
#endif // LEGATO
    // while bRunning, continues to run
    while (pGsThreadStruct->m_bRunning)
    {
        unsigned long loopTime = 0;
        unsigned long waitTime = 0; // init to no wait.
        // Wait for signal or timeout for the next acquisition scan.
        waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);
        GsAppLog(GS_TRACE, MODULE_GS_DATA, "DataSimulatorMgr: %s running(%s)",
                 (waitReturnCondition == WAIT_OBJECT_0 ? "Signal received." : "Thread wakup due to timeout."),
                 (pGsThreadStruct->m_bRunning ? "true" : "false"));
        if (!pGsThreadStruct->m_bRunning)
            break;
        g_dataSimWakeupTime = twGetSystemTime(TRUE);

        //#if defined(LEGATO)
        //propertyList *pPropertyList = ReadModbusData();
        //DataPublishingMgr_PublishProperties(pPropertyList, FALSE);
        //#endif // #FIXME

        // Simulate data acquisition and publishing.
        // Use a seed value to vary the data values.
        SimulateData(g_pSeedValues[seedIx]);
        if (++seedIx >= g_numOfSeedValues)
            seedIx = 0;

        //SimulateErrorEvent();
        // calculate the total time within the acquisition loop.
        loopTime = (unsigned long)(twGetSystemTime(TRUE) - g_dataSimWakeupTime);
        if (loopTime < g_acquisitionRate)
            waitTime = g_acquisitionRate - loopTime;
        g_pDataSimThreadStruct->m_waitMilliSec = waitTime;
    }
    // exit
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataSimulatorMgr:  extiting thread");
#if defined(LEGATO)
    le_thread_CleanupLegatoThreadData();
#endif // LEGATO
    return 0;
}

// *****************************************************************************
void SimulateData(int seed)
{
    if (!g_pDataSimThreadStruct->m_bRunning)
        return;
    AcquireAndPublishProperties(g_numOfProperties, seed);
}

// *****************************************************************************
void AcquireAndPublishProperties(int maxProperties, int seed)
{
    int i = 1;
    int value;
    // The properties list be be created, populated, published (asynchronously - via the PublishingMgr) for each
    // iteration of the while loop.  The PublishingMgr will take ownership of the properties list when published.
    propertyList *pPropertyList = NULL;
    // acquire the data into a properties list and publish using SPM (subscribe property manager)
    for (i = 1; i <= maxProperties; i++)
    {
        GetSimName(i, g_szPropertyName);
        value = GetSimValue(i, seed);
        UpdatePropertyList(&pPropertyList, g_szPropertyName, value, g_dataSimWakeupTime);
    }
    // Transfer the ownership of the propertyList and the publishing of the properties
    // to the Publishing Manager.
    DataPublishingMgr_PublishProperties(pPropertyList, FALSE);
    // list ownership has been transferred.  Set to NULL
    pPropertyList = NULL;
}

// *****************************************************************************
// creates simulater property name
void GetSimName(int ix, /* output */ char *pszName)
{
    snprintf(pszName, MAX_PROP_NAME_LEN, "%s%03i", g_pszBasePropName, ix);
}

// *****************************************************************************
// creates simulator property value.  Value is the index of the property + seed value.
int GetSimValue(int ix, int seedValue)
{
    int retVal = ix + seedValue;
    return retVal;
}

// *****************************************************************************
void UpdatePropertyList(propertyList **ppPropertylist, char *pszName, int value, DATETIME dt)
{
    twPrimitive *pPrimitive = twPrimitive_CreateFromInteger(value);

    if (*ppPropertylist == NULL)
    {
        *ppPropertylist = GsCreatePropertyList(pszName, pPrimitive, dt, TW_QUALITY_GOOD);
    }
    else
    {
        GsAddPropertyToList(*ppPropertylist, pszName, pPrimitive, dt, TW_QUALITY_GOOD);
    }
}

//*****************************************************************************
void SimulateErrorEvent()
{
    // Assuming system - enable_error_events is enabled in agent_config.json
    // the easiest way to simulate an event is to generate an error
    //GsAppLog(GS_ERROR, MODULE_GS_DATA, "DataSimulatorMgr:  Simulate an Event.");
}
