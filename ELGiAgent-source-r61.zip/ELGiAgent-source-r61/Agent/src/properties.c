/*****************************************************************************
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   : properties.c
//
//  Subsystem :  ELGiAgent
//
//  Description:
//                Implement the functions realated to processing the static Properties. 
//
******************************************************************************/
#include "AgentConfig.h"
#include "properties.h"
#include "DataPublishingMgr.h"

/** Property handler **/
enum msgCodeEnum PropertyHandler(const char *entityName, const char *propertyName,
                                 twInfoTable **value, char isWrite, void *userdata)
{
   // static properties are read-only and only sent on start-up.
   return TWX_BAD_OPTION;
} //> PropertyHandler(...)
//> ---------------------------------------------------------------------------

void RegisterStaticProperties()
{
   /* Register our properties */
   twApi_RegisterProperty(TW_THING, g_pszThingIdentifier, STR_AGENT_VERSION_PROPERTY, TW_STRING,
                          NULL, TW_PUSH_TYPE_ALWAYS, 0, PropertyHandler, NULL);
} //> RegisterStaticProperties()
//> ---------------------------------------------------------------------------

/** Update the properties' status once to platform **/
void StaticPropertyUpdate()
{
   propertyList *pPropertyList;
   twPrimitive *pAgentVersion = twPrimitive_CreateFromString(AGENT_VERSION, TRUE);
   GsAppLog(GS_INFO, MODULE_GS_CONFIG, "Writing '%s' property with '%s' value.",
            STR_AGENT_VERSION_PROPERTY, AGENT_VERSION);
   pPropertyList = GsCreatePropertyList(STR_AGENT_VERSION_PROPERTY,
                                        pAgentVersion,
                                        twGetSystemTime(TRUE),
                                        TW_QUALITY_GOOD);
   DataPublishingMgr_PublishProperties(pPropertyList, FALSE);
} //> StaticPropertyUpdate()
//> ---------------------------------------------------------------------------
