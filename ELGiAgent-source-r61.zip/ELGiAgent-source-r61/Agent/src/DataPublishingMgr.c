//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  DataPublishingMgr.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Manage data publishing to the ThingWorx Server.
//
/*
    This module is designed to be used 'as is' by your application as a broker between your 
    data acquisition and the SDK for publishing properties to the Server in a high throughput design.
    The publishing system is configurable via the agent_config.json file, see JSON "publishing" object.
    The key SDK functions used are:
      - twApi_SetSubscribedPropertyVTQ
      - twApi_PushSubscribedPropertiesAsync

    Essential global functions:
    - DataPublishingMgr_PublishProperties().  Function called by your data acquisition module in order
        to have the recently acquired data sent to the ThingWorx server as properties.

    This code follows the standard pattern for a functional module with global functions for:  initialize, start and shutdown.
    The Thread's responsiblity is to 'push' buffered properties to the SDK in an effecient and asynchronous manner.
*/
//
//*****************************************************************************
#include "AgentConfig.h"
#include "twProperties.h"
#include "DataPublishingMgr.h"

#define TIME_BUFFER_SIZE (32)
#define FILE_OUTPUT_BUFFER_SIZE (1024)

// protect various list from multi-thread access.
// This is needed by ThingWorx list only have function level mutex protection and the ThingWorx mutex is non-recursive.
TW_MUTEX g_DataPublishingMtx;
unsigned long g_pubPropertiesTAT = 0; // time to actually send properties via SDK to Platform & receive a response.

// public (locally global) variables
static unsigned int g_DataPublishingScanRate = INFINITE;
static GsThreadStruct *g_pDataPublishingThreadStruct = NULL;
// property queue logic:  if the number of properties in the queue is < g_minPropertyQueueSize then ...
// delay update g_propertyPublishingDelay before publishing.
static int g_minPropertyQueueSize = 10;
// # of properties to store in the g_pInterimPropertyList before loss of data (throw away newer values).
// 2200 is a guess for a default.  2200 = 7 * 300 samples per second + 100 extra.
static int g_maxPropertyQueueSize = 2200;
static unsigned long g_propertyPublishingDelay = 3000; // seconds.
static int g_bPushingProperties = FALSE;
static DATETIME g_propertyQueueNotEmptyTime = 0; // used for tacking time delay between queuing and publishing.
// If the SPM queue is not emptied at each push, set the 'time' at which the system needs to reboot so that the SDK becomes unlocked.
static DATETIME g_rebootTime = 0;

static char *g_pszThroughtputFilename = NULL;
static char *g_pszDataBufferFilename = NULL;

// This variable is used by both Publishing and Processing for logging.
static GS_BOOL g_bDataBufferOutput = FALSE;

// This is an interim property list.
// This will be populated via the PublishProperties() method. The thread will then
// transfer the list to the Subscribe Property Manager (SPM - internal SDK singleton).
// Once the list is transferred, the interim property list pointer will be cleared.
// An Interim Property List will not be created, if NULL, it will take owership of the
// list passed in via PublishProperties().
//
// NOTE:  if the SDK's persisted Queue is full, the SDK does NOT return an error
//        when setting property values and the Agent will lose data as well.
//        We are dependent on the SDK for persistence since we are NOT writing a
//        secondary persistence system.

static propertyList *g_pInterimPropertyList = NULL;

unsigned int g_pushSubscribedPropertiesAsyncMsgId = 0;

// function prototypes
THREAD_FUNCTION_RETURN DataPublishingThreadFunction(void *pVoid);

static void CopyInterimListToSDK();
static int PushProperties();
static void WriteDataBufferToFile(twProperty *pProperty);
static int GeneralResponseAsyncCallback(uint32_t id, enum msgCodeEnum code, char *pszReason, twInfoTable *pIT);

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

//*****************************************************************************
void DataPublishingMgr_Initialize()
{
    g_DataPublishingMtx = GS_RecursiveMutex_Create();

    g_pDataPublishingThreadStruct = GsCreateThreadStruct();
    g_pDataPublishingThreadStruct->m_waitMilliSec = g_DataPublishingScanRate;

    g_propertyQueueNotEmptyTime = twGetSystemTime(TRUE); // Initialize to curent time (vs. 0)

    // If DataBuffer file exists, rename using a filename with a timestamp.
    g_pszDataBufferFilename = GsAppendFilenameToPath(g_pszDataLogsDir, STR_DATA_BUFFER_FILENAME);
    GsBackupFileWithTimestamp(g_pszDataBufferFilename);
} //> DataPublishingMgr_Initialize(...)

//*****************************************************************************
int DataPublishingMgr_Start()
{
    // start the thread
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataPublishingMgr:  Initiate start of thread");
    GsStartThread(g_pDataPublishingThreadStruct, DataPublishingThreadFunction);

    return TW_OK;
} //> DataPublishingMgr_Start(...)

//*****************************************************************************
void DataPublishingMgr_Shutdown()
{
    // stop data publishing
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataPublishingMgr:  Initiate shutdown");
    GsStopThread(g_pDataPublishingThreadStruct);
    GsDestroyThreadStruct(g_pDataPublishingThreadStruct);
    g_pDataPublishingThreadStruct = NULL;

    if (g_pInterimPropertyList)
        twApi_DeletePropertyList(g_pInterimPropertyList);
    g_pInterimPropertyList = NULL;

    twMutex_Delete(g_DataPublishingMtx);

    TW_FREE(g_pszDataBufferFilename);

    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataPublishingMgr:  Shutdown complete");
} //> DataPublishingMgr_Shutdown(...)

//*****************************************************************************
void DataPublishingMgr_SignalThread()
{
    if (g_pDataPublishingThreadStruct == NULL || g_pDataPublishingThreadStruct->m_bRunning != TRUE)
        return;

    // Wake-up the publishing thead.
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataPublishingMgr:  Signal thread that there is data to publish.");
    GsSignalThread(g_pDataPublishingThreadStruct);
} //> DataPublishingMgr_SignalThread(...)

//*****************************************************************************
// Transfer the ownership of the propertyList and the publishing of the properties
// to the Publishing Manager's interim property list.
// The Caller is responsible to destroy the pPropertyList
// if 'bSynchronized' is true, then perform the push properties immediately.
//     Any pending data in the queue is pushed along with newly added properties
void DataPublishingMgr_PublishProperties(propertyList *pPropertyList, GS_BOOL bSynchronized)
{
    static GS_BOOL bListOverflow = FALSE;
    if (!pPropertyList)
        return;
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataPublishingMgr:  DataPublishingMgr_PublishProperties() received %i properties to publish.",
             pPropertyList->count);
    if (pPropertyList->count == 0)
        return;
    // protect multi-threaded access to g_pInterimPropertyList
    twMutex_Lock(g_DataPublishingMtx);
    if (g_pInterimPropertyList == NULL)
    {
        g_pInterimPropertyList = pPropertyList;
    }
    else
    {
        // If the interim list is already 'full' return.
        if (g_pInterimPropertyList->count >= g_maxPropertyQueueSize)
        {
            twMutex_Unlock(g_DataPublishingMtx);
            return;
        }
        if (bListOverflow)
        {
            // Interim list now has some space for more properties
            GsAppLog(GS_INFO, MODULE_GS_DATA, "DataPublishingMgr:  Interim property list is no longer full.");
            bListOverflow = FALSE;
        }
        // Check if appending will cause the Interim list to exceed the ,
        //  if so, then remove from the end (tail) of propertyList the # overage.
        while (g_pInterimPropertyList->count + pPropertyList->count > g_maxPropertyQueueSize)
        {
            twList_Remove(pPropertyList, pPropertyList->last, TRUE);
            if (bListOverflow == FALSE)
            {
                bListOverflow = TRUE;
                GsAppLog(GS_ERROR, MODULE_GS_DATA, "DataPublishingMgr:  Interim property list has overflowed.  Data will be lost!");
            }
        }
        // Append the input property list to the interim list.
        // both lists are locked during the append.
        // Design assumption:
        //  1. when the thread copies the interim list to the SPM, it will be relatively 'brief'
        //    thus not blocking this function for very 'long'.
        //  2. Only one interim list is required vs. a list of ptr to property lists.
        //
        // Note:  if thread is in the function CopyInterimListToSDK(), and the SPM is
        //        pushing (persisted) properties, the g_pInterimPropertyList list could be locked.
        //
        // Note:  the g_DataPublishingMtx is used to protect the g_pInterimPropertyList w/o using
        //        the  non-recursive g_pInterimPropertyList mutex which would cause a deadlock in Gs_twList_AppendList
        Gs_twList_AppendList(g_pInterimPropertyList, pPropertyList);

        // Since we own the propertyList and it is now copied, delete it.
        twApi_DeletePropertyList(pPropertyList);
    }
    twMutex_Unlock(g_DataPublishingMtx);
    if (bSynchronized)
    {
        CopyInterimListToSDK();
        PushProperties();
    }
    else
    {
        // Wake-up thread to process the data.
        DataPublishingMgr_SignalThread();
    }
} //> DataPublishingMgr_PublishProperties(...)

//*****************************************************************************
void DataPublishingMgr_SetMinPropertyQueueSize(int minPropertyQueueSize)
{
    g_minPropertyQueueSize = minPropertyQueueSize;
} //> DataPublishingMgr_SetMinPropertyQueueSize(...)

//*****************************************************************************
// set the maximum # of properties to store in the g_pInterimPropertyList
// before loss of data (throw away newer values).
void DataPublishingMgr_SetMaxPropertyQueueSize(int maxPropertyQueueSize)
{
    g_maxPropertyQueueSize = maxPropertyQueueSize;
} //> DataPublishingMgr_SetMaxPropertyQueueSize(...)

//*****************************************************************************
void DataPublishingMgr_SetPropertyPublishingDelay(int propertyPublishingDelay)
{
    //Input is in seconds, convert the value to milliseconds
    g_propertyPublishingDelay = (unsigned long)propertyPublishingDelay * 1000;
} //> DataPublishingMgr_SetPropertyPublishingDelay(...)

/*****************************************************************************
Set the data buffer output feature enable/disable.  This is used for 
scalability evaluation.
*****************************************************************************/
void DataPublishingMgr_SetDataBufferOutput(int enabled)
{
    g_bDataBufferOutput = (GS_BOOL)enabled;
} //> DataPublishingMgr_SetDataBufferOutput(...)

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

//*****************************************************************************
THREAD_FUNCTION_RETURN DataPublishingThreadFunction(void *pVoid)
{
    int waitReturnCondition = WAIT_OBJECT_0;
    // The pVoid input parameter is always the thread struct pointer
    GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid;
    if (pGsThreadStruct != g_pDataPublishingThreadStruct)
        GsAppLog(GS_ERROR, MODULE_GS_DATA, "DataPublishingMgr:  g_pDataPublishingThreadStruct is invalid. ");

    if (!pGsThreadStruct)
    {
        // Log error & exit
        GsAppLog(GS_ERROR, MODULE_GS_DATA, "DataPublishingMgr:  Thread initialiation error.  Exiting thread.");
        return (THREAD_FUNCTION_RETURN)-1;
    }
    GsAppLog(GS_TRACE, MODULE_GS_DATA, "DataPublishingMgr:  Thread started.  Thread id = %x (hex)", pGsThreadStruct->m_threadId);
#if defined(LEGATO)
    le_thread_InitLegatoThreadData("DataPublishingMgr");
#endif // LEGATO
    // continue publishing data forever while bRunning
    while (pGsThreadStruct->m_bRunning)
    {
        DATETIME beforePushTime;
        unsigned long delayPeriod;
        int twRetCode = TW_OK;
        int prePublishingSpmCount = 0;
        int postPublisingSpmCount = 0;

        waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);
        GsAppLog(GS_TRACE, MODULE_GS_DATA, "DataPublishingMgr: %s running(%s)",
                 (waitReturnCondition == WAIT_OBJECT_0 ? "Signal received." : "Thread wakup due to timeout."),
                 (pGsThreadStruct->m_bRunning ? "true" : "false"));
        if (!pGsThreadStruct->m_bRunning)
            continue;
        CopyInterimListToSDK();
        // property queue logic:  if the number of properties in the queue is < g_minPropertyQueueSize then ...
        // delay up to g_propertyPublishingDelay seconds before publishing.
        beforePushTime = twGetSystemTime(TRUE);
        delayPeriod = (unsigned long)(beforePushTime - g_propertyQueueNotEmptyTime);
        prePublishingSpmCount = GsGetSpmQueueCount();
        if (prePublishingSpmCount <= g_minPropertyQueueSize && delayPeriod < g_propertyPublishingDelay)
        {
            // wait up to the defined g_propertyPublishingDelay for the number of properties to >= the defined minimum Property Queue Size.
            pGsThreadStruct->m_waitMilliSec = g_propertyPublishingDelay - delayPeriod;
            continue;
        }
        // verify running  before the 'extended time' it takes to push properties.
        if (!pGsThreadStruct->m_bRunning)
            continue;

        // Note:  The interim list may receive more properties during the
        // blocking property push.
        twRetCode = PushProperties(); // Note:  due to error in SDK, the return code is OK even if there is an error.
        postPublisingSpmCount = GsGetSpmQueueCount();

        if (twRetCode != TW_OK && twRetCode != TW_WROTE_TO_OFFLINE_MSG_STORE)
        {
            GsAppLog(GS_ERROR, MODULE_GS_DATA, "DataPublishingMgr:  Error in publishing property list.  TW error code: %i.",
                     twRetCode);
            // Assmume there is no further action we can take.  (for example: persisted queue is full).
            // Based on research:
            //   - if off-line, the property will be persisted (assuming space available)
            //   - if on-line, then a server error, will maintain the SPM queue of values.
            //     So, we'll just add more and try again.... let the SDK do its job.
            //       - of course, this may not be the best solution.
        }
        if (postPublisingSpmCount)
        {
            // This is an unexpected condition - and may be based on undefined wrong assumptions.
            // We should never see this message. If the properties were published or peristed in
            //offline message store the expectation is spmCount == 0.
            // The only reason the SPM count is > 0 is when the system is offline and the persisted storage has reached its max size.
            GsAppLog(GS_INFO, MODULE_GS_DATA, "DataPublishingMgr:  SPM count (%i) is not empty after a push properties.", postPublisingSpmCount);
        }
        else
        {
            // Normal operating mode.  SPM count should be 0 after each publishe.
            g_rebootTime = 0;
        }

        if (g_pInterimPropertyList && g_pInterimPropertyList->count)
        {
            // There are pending properties to be queued & pushed. Do it immediately
            pGsThreadStruct->m_waitMilliSec = 0;
        }
        else if (delayPeriod)
        {
            pGsThreadStruct->m_waitMilliSec = delayPeriod; // indicates a potential issue with emptying the SPM Queue.
        }
        else
        {
            pGsThreadStruct->m_waitMilliSec = g_DataPublishingScanRate; // wait for signal that there is data to publish.
        }
    } //# while thread is running
      // exit
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataPublishingMgr:  exiting thread");
#if defined(LEGATO)
    le_thread_CleanupLegatoThreadData();
#endif // LEGATO
    return 0;
} //> DataPublishingThreadFunction(...)

//*****************************************************************************
void CopyInterimListToSDK()
{
    DATETIME startTime = 0;
    DATETIME finishedTime = 0;
    unsigned long elapsedTime = 0;
    int twRetCode = TW_OK;
    ListEntry *pEntry = NULL;
    GS_BOOL bSPMWasEmpty = (GsGetSpmQueueCount() == 0) ? TRUE : FALSE;
    int loopCount = 0;
    int listCount = (g_pInterimPropertyList == NULL) ? 0 : g_pInterimPropertyList->count;
    if (listCount == 0)
        return;
    // protect multi-threaded access to g_pInterimPropertyList
    twMutex_Lock(g_DataPublishingMtx);
    startTime = twGetSystemTime(TRUE);
    pEntry = g_pInterimPropertyList->first;
    while (pEntry)
    {
        // Add property to the SDK's SPM for queuing - but do not publish.
        // Philosophy note:
        //    By using the SDK Subscribed Property Manager (SubscribedPropertyXXX) - this sets the priority on
        //    sending 'time-series' data per property.
        //    An alternative approach (but more dev time) is to send 'snapshot' data that
        //    could be effectively used by expression rules.
        //
        twProperty *pProperty = (twProperty *)pEntry->value;
        twRetCode = twApi_SetSubscribedPropertyVTQ(g_pszThingIdentifier, pProperty->name,
                                                   twPrimitive_FullCopy(pProperty->value), pProperty->timestamp, pProperty->quality, FALSE, FALSE);
        if (twRetCode != TW_OK)
        {
            if (twRetCode == TW_PROPERTY_CHANGE_BUFFER_FULL)
            {
                // Notes:
                //  - error is already logged by SDK.
                //  - the persisted queue is full or some other un-recoverable error, but in any case...
                //    it is ok to delete the property from the interim list because the Interim is only for
                //    buffering data from the acquisition engines while SPM is busy publishing data
                //    (i.e. SPM has a mutex lock during publishing.  This is minimized with async publishing, but still an issue).
                //    We are dependent on the SDK for persistence since we are NOT writing a secondary persistence system.
                twRetCode = twRetCode; // for debugging
            }
        }
        else
        {
            /*If data buffer output is enabled log the property info to file */
            if (g_bDataBufferOutput)
                WriteDataBufferToFile(pProperty);
        }
        loopCount++; // for testing purposes.

        pEntry = pEntry->next;
    }
    listCount = g_pInterimPropertyList->count; // for testing purposes.

    // At this point, the assumption is the SDK's SPM owns all the properties and they will be
    // successfully pushed at the appropriate time.

    // Now clear the interim list
    // Note:  the g_DataPublishingMtx is the protection of the g_pInterimPropertyList
    // betweent the Unlock() above and the Gs_twList_AppendList() in DataPublishingMgr_PublishProperties()
    twList_Clear(g_pInterimPropertyList);

    // Note:  design assumption is the elapsed time is 'brief'.
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataPublishingMgr:  time to copy %i properties: %i ms.  Total SPM count = %i",
             listCount, (int)elapsedTime, GsGetSpmQueueCount());

    // Now clear the interim list
    // Note:  the g_DataPublishingMtx is the protection of the g_pInterimPropertyList
    // betweent the Unlock() above and the Gs_twList_AppendList() in DataPublishingMgr_PublishProperties()
    twList_Clear(g_pInterimPropertyList);

    twMutex_Unlock(g_DataPublishingMtx);

    if (bSPMWasEmpty)
    {
        // This is the 1st set of properties being set in the Subscribed Property Manager's queue...
        // so track the time in order to enable a  potential delay before pushing properties.
        g_propertyQueueNotEmptyTime = twGetSystemTime(TRUE);
    }
} //> CopyInterimListToSDK(...)

//*****************************************************************************
int PushProperties()
{
    int twRetCode = TW_OK;
    DATETIME startTime;
    DATETIME finishedTime;
    int spmCount = GsGetSpmQueueCount();
    twList *pAsyncCbMessageIdList = NULL;

    startTime = twGetSystemTime(TRUE);
    g_bPushingProperties = TRUE;

    //  Note:  from debugging experience, the callback [GeneralResponseAsyncCallback]
    //         can be called BEFORE the function twApi_PushSubscribedPropertiesAsync() returns!
    //         This is because for 'large' infotable (i.e. lots of properties > 200),
    //         it can take longer to free the memory then it does to make the round-trip
    //         asynchronous call to the ThingWorx Server.
    //         Therefore:  trying to match the GeneralResponseAsyncCallback 'id'
    //         to the msg ID returned by twApi_PushSubscribedPropertiesAsync() is ** unreliable **.

    twRetCode = twApi_PushSubscribedPropertiesAsync(g_pszThingIdentifier, FALSE, GeneralResponseAsyncCallback,
                                                    &pAsyncCbMessageIdList);
    // free list.
    if (pAsyncCbMessageIdList)
    {
        g_pushSubscribedPropertiesAsyncMsgId = (pAsyncCbMessageIdList->first) ? *((int *)pAsyncCbMessageIdList->first->value) : 0;
        twList_Delete(pAsyncCbMessageIdList);
        pAsyncCbMessageIdList = NULL;
    }
    g_bPushingProperties = FALSE;

    if (twRetCode == TW_OK)
    {
        unsigned long TAT = 0;
        finishedTime = twGetSystemTime(TRUE);
        TAT = (unsigned long)(finishedTime - startTime);

        GsAppLog(GS_DEBUG, MODULE_GS_DATA, "DataPublishingMgr:  time to push %i subscribed properties: %i ms.  Async Message id = %i",
                 spmCount, (int)TAT, g_pushSubscribedPropertiesAsyncMsgId);
    }
    else
    {
        twRetCode = twRetCode;
    }

    return twRetCode;
} //> PushProperties(...)

/******************************************************************************
Create a CSV file with properties put into SDK buffer for transferring to the 
platform.
******************************************************************************/
void WriteDataBufferToFile(twProperty *pProperty)
{
    TW_FILE_HANDLE hFile = NULL;
    GS_BOOL bFileExists = TRUE;
    char szBuffer[FILE_OUTPUT_BUFFER_SIZE];
    static GS_BOOL bLoggedError = FALSE;
    char *pszPropertyValueAsString;
    char szTimeBuffer[TIME_BUFFER_SIZE];

    if (!twDirectory_FileExists(g_pszDataBufferFilename))
        bFileExists = FALSE;

    hFile = TW_FOPEN(g_pszDataBufferFilename, "a+");
    if (!hFile && bLoggedError == FALSE)
    {
        GsAppLog(GS_ERROR, MODULE_GS_DATA, "Could not open file %s", g_pszDataBufferFilename);
        bLoggedError = TRUE;
        return;
    }
    if (!bFileExists)
    {
        snprintf(szBuffer, FILE_OUTPUT_BUFFER_SIZE, "%s",
                 "Date(readable),Timestamp, Name, Value, Quality\n");
        TW_FWRITE(szBuffer, sizeof(char), strlen(szBuffer), hFile);
    }
    pszPropertyValueAsString = GsConvertPrimativeValueToString(pProperty->value);
    twGetTimeString(pProperty->timestamp, szTimeBuffer, "%Y-%m-%d %H:%M:%S", TIME_BUFFER_SIZE, FALSE, TRUE);
    // log the values.  Note:  timestamp does not have ms.
    snprintf(szBuffer, FILE_OUTPUT_BUFFER_SIZE, "%s,%llu,%s,%s,%s\n",
             szTimeBuffer, pProperty->timestamp, pProperty->name, pszPropertyValueAsString, pProperty->quality);
    TW_FWRITE(szBuffer, sizeof(char), strlen(szBuffer), hFile);
    TW_FREE(pszPropertyValueAsString);
    TW_FCLOSE(hFile);
} //> WriteDataBufferToFile(...)

//******************************************************************************
// This is a general purpose asychronous message response callback.
// This is required for the Push Properties Async function.
//
//  Note:  from debugging experience, the callback can be called BEFORE
//         the function twApi_PushSubscribedPropertiesAsync() returns!
//         This is because for 'large' infotable (i.e. lots of properties),
//         it can take longer to free the memory then it does to make the round-trip
//         asynchronous call to the ThingWorx Server.
//         Therefore:  trying to match the input 'id' to the msg ID returned by
//         twApi_PushSubscribedPropertiesAsync() is unreliable without additonal codeing effort..
//
int GeneralResponseAsyncCallback(uint32_t id, enum msgCodeEnum code,
                                 char *pszReason, twInfoTable *pIT)
{
    // Programmer Note:  If there is a loss of connectivity (code != TWX_SUCCESS) - you may need to
    // add extensive logic to prevent the edge case of loss of data being sent to the Server (and NOT persisted).
    TW_FREE(pIT);

    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "GeneralResponseAsyncCallback  message id = %i; code = 0x%x (0x40 is success), reason = %s",
             id, code, pszReason);

    return TW_OK;
} //> GeneralResponseAsyncCallback(...)
