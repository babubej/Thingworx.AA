//**************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//**************************************************************************
//
//  Filename   :  GsThread.h
//
//  Description:  Define ELGiAgent's OS abstraction layer for threads
//
//
//**************************************************************************

#ifndef __GS_THREAD_H__
#define __GS_THREAD_H__

// Linux includes and defines to make thread coding similar to Windows implementation.
#ifndef WIN32
#include <sys/time.h>
#include <pthread.h>
#define INFINITE 0xFFFFFFFF
#define WAIT_OBJECT_0 0x00000000L
#define WAIT_TIMEOUT 0x00000102L
#define WAIT_FAILED 0xFFFFFFFF
#endif

// Event struct
typedef struct GsEventStruct
{
#ifdef WIN32
	HANDLE m_waitEvent; // Event handle
#else
	TW_MUTEX m_waitEvent;		  // the Event  - blocks multiple waits
	TW_MUTEX m_conditionEvent;	  // used when waiting for the condition.
	pthread_cond_t *m_pCondition; // condition used with m_conditionEvent
#endif
} GsEventStruct;

// event struct management functions
GsEventStruct *GsCreateEventStruct();
void GsDestroyEventStruct(GsEventStruct *);

// wait function
unsigned long GsWaitForEvent(GsEventStruct *, unsigned long milliSeconds);
void GsSignalEvent(GsEventStruct *);

//
// Below are GsThread definitions
//
#ifdef WIN32
// Win32 Thread function prototype
typedef DWORD WINAPI GsThreadProc(void *);
unsigned long GsGetCurrentThreadId();
#else
// Linux Thread function prototype
typedef void *GsThreadProc(void *);
pthread_t GsGetCurrentThreadId();
#endif

// thread struct
typedef struct GsThreadStruct
{
	unsigned char m_bRunning;	  // thread is running or not
	unsigned char m_bSuspend;	  // non zero for suspend mode
	void *m_parameter;			  // optional caller parameter to pass down to the thread function
	TW_MUTEX m_dataMutex;		  // global data protection
	unsigned long m_waitMilliSec; // execution frequency
#ifdef WIN32
	unsigned long m_threadId; // the thread id
	HANDLE m_threadHandle;	  // the thread handle
#else
	pthread_t m_threadId; // the thread id
#endif
	GsEventStruct *m_pGsEventStruct; // The Event
} GsThreadStruct;

// thread functions
GsThreadStruct *GsCreateThreadStruct();
void GsDestroyThreadStruct(GsThreadStruct *);

// Starts the thread running
int GsStartThread(GsThreadStruct *, GsThreadProc pThreadFun);

// Signal the thread to wake up.
void GsSignalThread(GsThreadStruct *pGsThreadStruct);

// stops the thread. It returns after thread is exited
void GsStopThread(GsThreadStruct *);

// GsChangeThreadStatus() suspend or resume the thread
void GsChangeThreadStatus(GsThreadStruct *, unsigned char uSuspend);

// this is called inside the Thread function to throttles the thread execution cycle. do not use sleep()
int GsThreadWaitForRunCycle(GsThreadStruct *);

// Create a recursive mutex instead of a default mutex like used by twMutexCreate()
// For Windows use the standard ThingWorx mutex (which is recursive by definition)
// For Linux use a special recursive mutex.
TW_MUTEX GS_RecursiveMutex_Create();

// calculate the delay for the acquisition loop.  The goal is to maintain a
// constant/consistent aquisition loop timing w/o jitter.
//
// input:
//   - calculatedDelay: can either be a calculated delay or the configured delay
//   - actualLoopTime: the time spent in the  last acquisition loop.
// return:  the delay for the next acquisition loop.
unsigned long CalculateDelay(GsThreadStruct *pStruct, unsigned long calculatedDelay, unsigned long actualLoopTime);

#endif // __GS_THREAD_H__
