//*****************************************************************************
//
//  Copyright © 1985-2017 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  GsThreadLinux.c
//
//  Description:  Linux implementation of the ELGiAgent's threading abstraction layer
//                See GsThread.c for detailed description.
//
//
//*****************************************************************************

#include "AgentConfig.h"

// To include ETIMEDOUT
#include <errno.h>
#include "twOSPort.h" // for TW_MUTEX
#include "GsThread.h"

//*****************************************************************************
// creates the event struct
GsEventStruct *GsCreateEventStruct()
{
	GsEventStruct *pGsEventStruct = TW_MALLOC(sizeof(GsEventStruct));
	if (pGsEventStruct)
	{
		pGsEventStruct->m_waitEvent = GS_RecursiveMutex_Create();
		pGsEventStruct->m_conditionEvent = GS_RecursiveMutex_Create();
		pGsEventStruct->m_pCondition = TW_MALLOC(sizeof(pthread_cond_t));
		if (pGsEventStruct->m_waitEvent && pGsEventStruct->m_pCondition)
		{
			if (pthread_cond_init(pGsEventStruct->m_pCondition, 0) == 0)
				return pGsEventStruct;
		}
	}
	GsAppLog(GS_ERROR, MODULE_GS_DATA, "GsCreateEventStruct:  Failed to initialize Linux condition.");
	GsDestroyEventStruct(pGsEventStruct);
	return 0;
}

//*****************************************************************************
// destroys the event struct
void GsDestroyEventStruct(GsEventStruct *pGsEventStruct)
{
	if (pGsEventStruct)
	{
		if (pGsEventStruct->m_waitEvent)
			twMutex_Delete(pGsEventStruct->m_waitEvent);
		if (pGsEventStruct->m_conditionEvent)
			twMutex_Delete(pGsEventStruct->m_conditionEvent);
		if (pGsEventStruct->m_pCondition)
		{
			pthread_cond_destroy(pGsEventStruct->m_pCondition);
			TW_FREE(pGsEventStruct->m_pCondition);
			pGsEventStruct->m_pCondition = 0;
		}
		TW_FREE(pGsEventStruct);
	}
}

//*****************************************************************************
// wait for the event.
unsigned long GsWaitForEvent(GsEventStruct *pGsEventStruct, unsigned long milliSeconds)
{
	unsigned long ret = WAIT_FAILED;
	struct timeval now;
	struct timespec timeout;

	if (pGsEventStruct == 0)
		return ret;
	// lock any other calls to this function.  (Very unlikely)
	twMutex_Lock(pGsEventStruct->m_waitEvent);
	// lock the condition mutex.  This is required before calling pthread_cond_wait().
	twMutex_Lock(pGsEventStruct->m_conditionEvent);

	if (milliSeconds != INFINITE)
	{
		gettimeofday(&now, NULL);

		timeout.tv_sec = now.tv_sec;
		timeout.tv_nsec = (now.tv_usec * 1000);

		timeout.tv_sec += (milliSeconds / 1000);
		timeout.tv_nsec += ((milliSeconds % 1000) * 1000000);

		if (timeout.tv_nsec > 1000000000)
		{
			timeout.tv_sec += (timeout.tv_nsec / 1000000000);
			timeout.tv_nsec = (timeout.tv_nsec % 1000000000);
		}
		ret = pthread_cond_timedwait(pGsEventStruct->m_pCondition, pGsEventStruct->m_conditionEvent, &timeout);
	}
	else
	{
		/*GsAppLog(GS_DEBUG, MODULE_GS_DATA, "GsWaitForEvent:  infinite wait for thread id:  %x", 
            pGsThreadStruct->m_threadId);*/

		ret = pthread_cond_wait(pGsEventStruct->m_pCondition, pGsEventStruct->m_conditionEvent);

		/*GsAppLog(GS_DEBUG, MODULE_GS_DATA, "GsWaitForEvent:  wait condition signalled for thread id:  %x", 
            pGsThreadStruct->m_threadId);*/
	}

	// change return code to reflect the Windows defintions.
	if (ret == 0)
		ret = WAIT_OBJECT_0;
	else if (ret == ETIMEDOUT)
		ret = WAIT_TIMEOUT;
	else
		ret = WAIT_FAILED;

	// Upon successful return from pthread_cond_wait(), the mutex shall have been locked and shall be owned by the calling thread.
	twMutex_Unlock(pGsEventStruct->m_conditionEvent);
	twMutex_Unlock(pGsEventStruct->m_waitEvent);
	return ret;
}

void GsSignalEvent(GsEventStruct *pGsEventStruct)
{
	if (pGsEventStruct)
		pthread_cond_broadcast(pGsEventStruct->m_pCondition);
}

//*****************************************************************************
// creates the thread struct
GsThreadStruct *GsCreateThreadStruct()
{
	GsThreadStruct *pGsThreadStruct = TW_MALLOC(sizeof(GsThreadStruct));
	if (pGsThreadStruct)
	{
		pGsThreadStruct->m_bRunning = FALSE;
		pGsThreadStruct->m_bSuspend = FALSE;
		pGsThreadStruct->m_parameter = 0;
		pGsThreadStruct->m_dataMutex = GS_RecursiveMutex_Create();
		pGsThreadStruct->m_waitMilliSec = 500;
		pGsThreadStruct->m_threadId = 0;
		pGsThreadStruct->m_pGsEventStruct = GsCreateEventStruct();
		if (pGsThreadStruct->m_dataMutex && pGsThreadStruct->m_pGsEventStruct)
			return pGsThreadStruct;
	}
	GsDestroyThreadStruct(pGsThreadStruct);
	return 0;
}

//*****************************************************************************
// destroys the thread struct
void GsDestroyThreadStruct(GsThreadStruct *pGsThreadStruct)
{
	if (pGsThreadStruct)
	{
		if (pGsThreadStruct->m_dataMutex)
			twMutex_Delete(pGsThreadStruct->m_dataMutex);
		if (pGsThreadStruct->m_pGsEventStruct)
			GsDestroyEventStruct(pGsThreadStruct->m_pGsEventStruct);
		TW_FREE(pGsThreadStruct);
	}
}

//*****************************************************************************
// start the thread running
int GsStartThread(GsThreadStruct *pGsThreadStruct, GsThreadProc pFun)
{
	int i = 0;
	if (pGsThreadStruct)
	{
		pGsThreadStruct->m_bRunning = TRUE;
		pthread_create(&pGsThreadStruct->m_threadId, NULL, pFun, pGsThreadStruct);
		i = (int)pGsThreadStruct->m_threadId;
	}
	return i;
}

//*****************************************************************************
// Signal the thread to wake up.
void GsSignalThread(GsThreadStruct *pGsThreadStruct)
{
	if (pGsThreadStruct)
	{
		//    	GsAppLog(GS_TRACE, MODULE_GS_DATA, "GsSignalThread:  pCondition = %i.",
		//           pGsThreadStruct->m_pGsEventStruct->m_pCondition);
		// wake up the waiting object
		pthread_cond_broadcast(pGsThreadStruct->m_pGsEventStruct->m_pCondition);
	}
}

//*****************************************************************************
// stop the running thread
void GsStopThread(GsThreadStruct *pGsThreadStruct)
{
	if (pGsThreadStruct)
	{
		// stop
		pGsThreadStruct->m_bRunning = FALSE;

		//    	GsAppLog(GS_TRACE, MODULE_GS_DATA, "GsStopThread:  Initiate shutdown for thread id: %x.  signal condition to wake up thread.",
		//           pGsThreadStruct->m_threadId);

		// wake up the waiting object
		pthread_cond_broadcast(pGsThreadStruct->m_pGsEventStruct->m_pCondition);

		//    	GsAppLog(GS_TRACE, MODULE_GS_DATA, "GsStopThread:  condition signalled.  Wait for exit of thread.");

		// wait for exit
		if (pGsThreadStruct->m_threadId)
		{
			int retCode = pthread_join(pGsThreadStruct->m_threadId, NULL);
			if (retCode != 0)
				GsAppLog(GS_ERROR, MODULE_GS_DATA, "GsStopThread:  pthread_join returned error %i for thread %x.",
						 retCode, pGsThreadStruct->m_threadId);
			/*
            else
    	        GsAppLog(GS_TRACE, MODULE_GS_DATA, "GsStopThread:  Thread %i has exited.", pGsThreadStruct->m_threadId );
 */
		}
		pGsThreadStruct->m_threadId = 0;
	}
}

//*****************************************************************************
// Create a recursive mutex instead of a default mutex like used by twMutexCreate()
TW_MUTEX GS_RecursiveMutex_Create()
{
	int retCode = 0;
	pthread_mutexattr_t attr;
	pthread_mutex_t *tmp = TW_MALLOC(sizeof(pthread_mutex_t));
	if (!tmp)
		return 0;
	/*create a recursive mutex */
	pthread_mutexattr_init(&attr);
	retCode = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);

	if (retCode == EINVAL)
		printf("GS_RecursiveMutex_Create:  pthread_mutexattr_settype() return code = %i.  This is the 'EINVAL' return code", retCode);
	else if (retCode != 0)
		printf("GS_RecursiveMutex_Create:  pthread_mutexattr_settype() return error code = %i.", retCode);

	pthread_mutex_init(tmp, &attr);
	pthread_mutexattr_destroy(&attr);
	return tmp;
}

//*****************************************************************************
pthread_t GS_GetCurrentThreadId()
{
	return pthread_self();
}
