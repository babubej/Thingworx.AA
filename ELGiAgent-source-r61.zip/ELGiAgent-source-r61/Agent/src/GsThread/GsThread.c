//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  GsThread.c
//  
//  Description:  
/*
    C style struct to manage threads in an OS abstracted manner.
    Threads are defined using Windows nominclature, but an abstraction implementation 
    is done in both Windows (see GsThreadWin.c) & Linux (GsThreadLinux.c).

    Thread implementation has the following features (encapsulated via the structure GsThreadStruct)
      - Threads can 'wake up' after a defined waith period, or by being signalled.
      - Theads can be paused and resumed
      - Threads are implemented to loop while the running flag is true.  This facilitates
        a clean shutdown of the system.

    Essential global functions:
      - GsStartThread
      - GsSignalThread
      - GsStopThread
      - GsThreadWaitForRunCycle

    A word about mutexes:  
         A Windows mutex is recursive.  The default SDK implementation the Linux mutex is NOT recursive.
         In order to have Linux follow the same pattern, the SDK's Linux mutex implementation is superceed (overridden).
         This is done in 2 ways:  
           1. using the Agent function GS_RecursiveMutex_Create()
           2. updating the SDK source code with an Agent overlay.  
        See Initialization.c, OverrideSDKCreateMutex() for details.


*/
//
//*****************************************************************************

#include "twApi.h"
#include "GsThread.h"

//
// suspend or resume the thread: uSuspend == 0 means resume. uSuspend == 1 means suspend
//
void GsChangeThreadStatus(GsThreadStruct* pGsThreadStruct, unsigned char uSuspend)
{
	if(pGsThreadStruct)
	{
		pGsThreadStruct->m_bSuspend = uSuspend;

		// wake up the thread in both cases. 
		// The thread will run its cycle once upon wake up, then go to sleep or go alive accordingly
		GsSignalThread(pGsThreadStruct);
	}
}

//*****************************************************************************
// wait for the next execution cycle or to be signalled
int GsThreadWaitForRunCycle(GsThreadStruct* pGsThreadStruct)
{
	unsigned long i = WAIT_FAILED;
    if(!pGsThreadStruct)
        return i;
SuspendThread:
	i = (int)GsWaitForEvent(pGsThreadStruct->m_pGsEventStruct, pGsThreadStruct->m_waitMilliSec);
    if (pGsThreadStruct->m_bSuspend)
    {
        // centralize suspension of all threads.
        pGsThreadStruct->m_waitMilliSec = INFINITE;
        goto SuspendThread;
    }
	return (int)i;
}

//*****************************************************************************
// calculate the delay for the acquisition loop.  The goal is to maintain a 
// constant/consistent aquisition loop timing w/o jitter.
//
// input: 
//   - calculatedDelay: can either be a calculated delay or the configured delay
//   - actualLoopTime: the time spent in the  last acquisition loop.
// return:  the delay for the next acquisition loop.
//           
unsigned long CalculateDelay(GsThreadStruct* pStruct, unsigned long calculatedDelay, unsigned long actualLoopTime)
{
    unsigned long delay;

    // The last acquisition loop took 'loopTime' milliseconds.
    // Adjust the next delay by the time it took to loop.
    // This keeps a consistent data rate.
	if(pStruct->m_bSuspend != 0)
		delay = INFINITE;
	else if(calculatedDelay == INFINITE)
		delay = INFINITE;
    else if (actualLoopTime > calculatedDelay)
        delay = 0;
    else
        delay = calculatedDelay - actualLoopTime;
    return delay;
}
