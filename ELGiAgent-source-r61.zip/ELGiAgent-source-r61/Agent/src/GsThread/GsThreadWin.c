//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  GsThreadWin.c
//
//  Description:  Windows implementation of the ELGiAgent's threading abstraction layer
//                See GsThread.c for detailed description.
//
//*****************************************************************************

#include "twApi.h"
#include "GsThread.h"

//*****************************************************************************
// creates the event struct
GsEventStruct *GsCreateEventStruct()
{
	GsEventStruct *pGsEventStruct = (GsEventStruct *)TW_MALLOC(sizeof(GsEventStruct));
	if (pGsEventStruct)
	{
		// Note:  event auto-resets.
		pGsEventStruct->m_waitEvent = CreateEvent(0, FALSE, FALSE, NULL);
		if (pGsEventStruct->m_waitEvent)
			return pGsEventStruct;
	}

	GsDestroyEventStruct(pGsEventStruct);
	return 0;
}

//*****************************************************************************
// destroys the event struct
void GsDestroyEventStruct(GsEventStruct *pGsEventStruct)
{
	if (pGsEventStruct)
	{
		if (pGsEventStruct->m_waitEvent)
			CloseHandle(pGsEventStruct->m_waitEvent);

		TW_FREE(pGsEventStruct);
	}
}

//*****************************************************************************
// wait for the Event.
unsigned long GsWaitForEvent(GsEventStruct *pGsEventStruct, unsigned long milliSeconds)
{
	unsigned long i = WAIT_FAILED;
	if (pGsEventStruct)
		i = WaitForSingleObject(pGsEventStruct->m_waitEvent, milliSeconds);
	return i;
}

//*****************************************************************************
void GsSignalEvent(GsEventStruct *pGsEventStruct)
{
	if (pGsEventStruct)
		SetEvent(pGsEventStruct->m_waitEvent);
}

//*****************************************************************************
// creates the thread struct
GsThreadStruct *GsCreateThreadStruct()
{
	GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)TW_MALLOC(sizeof(GsThreadStruct));
	if (pGsThreadStruct)
	{
		pGsThreadStruct->m_bRunning = FALSE;
		pGsThreadStruct->m_bSuspend = FALSE;
		pGsThreadStruct->m_parameter = 0;
		pGsThreadStruct->m_dataMutex = GS_RecursiveMutex_Create();
		pGsThreadStruct->m_waitMilliSec = 500; // caller can override this value
		pGsThreadStruct->m_threadId = 0;
		pGsThreadStruct->m_threadHandle = 0;
		pGsThreadStruct->m_pGsEventStruct = GsCreateEventStruct();
		if (pGsThreadStruct->m_dataMutex && pGsThreadStruct->m_pGsEventStruct)
			return pGsThreadStruct;
	}

	GsDestroyThreadStruct(pGsThreadStruct);
	return 0;
}

//*****************************************************************************
// destroys the thread struct
void GsDestroyThreadStruct(GsThreadStruct *pGsThreadStruct)
{
	if (pGsThreadStruct)
	{
		if (pGsThreadStruct->m_threadHandle)
			CloseHandle(pGsThreadStruct->m_threadHandle);
		if (pGsThreadStruct->m_dataMutex)
			twMutex_Delete(pGsThreadStruct->m_dataMutex);
		if (pGsThreadStruct->m_pGsEventStruct)
			GsDestroyEventStruct(pGsThreadStruct->m_pGsEventStruct);

		TW_FREE(pGsThreadStruct);
	}
}

//*****************************************************************************
// start the thread running
int GsStartThread(GsThreadStruct *pGsThreadStruct, GsThreadProc pFunction)
{
	int i = 0;
	if (pGsThreadStruct)
	{
		pGsThreadStruct->m_bRunning = TRUE;
		pGsThreadStruct->m_threadHandle = CreateThread(0, 0, pFunction, pGsThreadStruct, 0, &pGsThreadStruct->m_threadId);
		i = (int)pGsThreadStruct->m_threadHandle;
	}
	return i;
}

//*****************************************************************************
// Signal the thread to wake up.
void GsSignalThread(GsThreadStruct *pGsThreadStruct)
{
	if (pGsThreadStruct)
	{
		// set event
		SetEvent(pGsThreadStruct->m_pGsEventStruct->m_waitEvent);
	}
}

//*****************************************************************************
// stop the running thread
void GsStopThread(GsThreadStruct *pGsThreadStruct)
{
	if (pGsThreadStruct)
	{
		// stop
		pGsThreadStruct->m_bRunning = FALSE;

		// set event
		SetEvent(pGsThreadStruct->m_pGsEventStruct->m_waitEvent);

		// wait for exit
		if (pGsThreadStruct->m_threadHandle)
			WaitForSingleObject(pGsThreadStruct->m_threadHandle, INFINITE);
		pGsThreadStruct->m_threadHandle = 0;
	}
}

//*****************************************************************************
// Create a recursive mutex instead of a default mutex like used by twMutexCreate()
// For Windows use the standard ThingWorx mutex (which is recursive by definition)
// For Linux use a special recursive mutex.  See GsThreadLinux.c
TW_MUTEX GS_RecursiveMutex_Create()
{
	return twMutex_Create();
}

//*****************************************************************************
unsigned long GsGetCurrentThreadId()
{
	return GetCurrentThreadId();
}
