//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  Utilities.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:  Various support (utility) functions.
//                These functions only use the 'C' run-time library and are
//                already cross-platform compatible.
//
//*****************************************************************************

#include "AgentConfig.h"
#include "cJSON.h"

// global shutdown event
GsEventStruct *g_pGsShutdownEventStruct = NULL;

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

// GsVerifyJSONContent
//  - input:  JSON object, JSON object element name, JSON object element value
//  - return:  pointer to memory holding the content of the JSON object element
//             value.
// caller is responsible to free the memory returned by GsVerifyJSONContent*****/
cJSON *GsVerifyJSONContent(cJSON *pJSONContent, char *pszJSONObjectName)
{
    cJSON *pszJSONObjectValue = NULL;
    pszJSONObjectValue = cJSON_GetObjectItem(pJSONContent, pszJSONObjectName);
    if (!pszJSONObjectValue)
    {
        //Log the error
        GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "JSON parsing error.  Object name not found: %s",
                 pszJSONObjectName);
    }
    return pszJSONObjectValue;
} //> GsVerifyJSONContent(...)
//>----------------------------------------------------------------------------

// Duplicate the string.
// input:  source string to be duplicated.
// return:  pointer to duplicated string.
//  *** The caller is responsible to free the memory of the returned pointer
char *GsStringDup(const char *pszSource)
{
    char *pszDest = NULL;
    if (pszSource != NULL)
    {
        pszDest = (char *)TW_CALLOC(strlen(pszSource) + 1, 1);

        // without the memset, the result will be garbage on empty strings
        memset(pszDest, 0, strlen(pszSource) + 1);
        strcpy(pszDest, pszSource);
    }
    return pszDest;
} //> GsStringDup(...)
//>----------------------------------------------------------------------------

/****************************************************************************
 Get the absolute directory location per CWD
 input: pszSubFolderName:  name of subfolder directory.
 return: pointer to absolute directory path relative to the current working directory
  *** The caller is responsible to free the memory of the returned pointer
****************************************************************************/
char *GsGetRelativeDirectoryName(char *pszSubFolderName)
{
    char *pszAbsolutePath = (char *)TW_CALLOC(PATH_MAX + 1, 1);
    char *pszCWD = GsGetCwd();
    strcpy(pszAbsolutePath, pszCWD);
    if (pszSubFolderName)
    {
        strcat(pszAbsolutePath, TW_FILE_DELIM_STR);
        strcat(pszAbsolutePath, pszSubFolderName);
    }
    TW_FREE(pszCWD);
    return pszAbsolutePath;
} //> GsGetRelativeDirectoryName(...)
//>----------------------------------------------------------------------------

/*****************************************************************************
Return the absolute path & filename relative to the current working directory. 
input:   
    - pszSubFolderName:  Optional sub-folder name  (can be NULL)
    - pszFileName:  file name
return:  pointer to relative file path.
*** The caller is responsible to free the memory of the returned pointer
*****************************************************************************/
char *GsGetRelativeFilename(char *pszSubFolderName, char *pszFileName)
{
    // assumes returned path will be max path in length.
    char *pszAbsoluteFilePath = GsGetRelativeDirectoryName(pszSubFolderName);
    if (pszFileName)
    {
        strcat(pszAbsoluteFilePath, TW_FILE_DELIM_STR);
        strcat(pszAbsoluteFilePath, pszFileName);
    }
    return pszAbsoluteFilePath;
} //> GsGetRelativeFilename(...)
//>----------------------------------------------------------------------------

/*****************************************************************************
Return the full file name path of the path + filename.
input:   
    - pszPath:  path name (relative or absolute)
    - pszFileName:  file name
 If path does not end in a deliminter it will be added.
 return:  pointer to complete file name with path.
  *** The caller is responsible to free the memory of the returned pointer
*****************************************************************************/
char *GsAppendFilenameToPath(char *pszPath, char *pszFileName)
{
    char *pszFullPathName = NULL;
    if (!pszPath || !pszFileName)
        return NULL;
    unsigned int length = strlen(pszFileName);
    for (int idx = 0; idx < length; idx++)
    {
        if (pszFileName[idx] == '/' || pszFileName[idx] == '\\')
            pszFileName[idx] = TW_FILE_DELIM;
    } //# for each char
    pszFullPathName = (char *)TW_CALLOC(PATH_MAX + 1, 1);
    strcpy(pszFullPathName, pszPath);
    if (pszPath[strlen(pszPath) - 1] != TW_FILE_DELIM)
        strcat(pszFullPathName, TW_FILE_DELIM_STR);
    strcat(pszFullPathName, pszFileName);
    return pszFullPathName;
} //> GsAppendFilenameToPath(...)
//>----------------------------------------------------------------------------

/*****************************************************************************
Return the full file name path of the path + filename.
input:   
    - pszPath:  path name (relative or absolute)
    - pszFolderName:  folder name to be appended.
 If path does not end in a deliminter it will be added.
 return:  pointer to complete file name with path.
  *** The caller is responsible to free the memory of the returned pointer
*****************************************************************************/
char *GsAppendFolderNameToPath(char *pszPath, char *pszFolderName)
{
    char *pszFullPathName = NULL;
    if (!pszPath)
        return NULL;
    pszFullPathName = (char *)TW_CALLOC(PATH_MAX + 1, 1);
    memset(pszFullPathName, 0, PATH_MAX + 1);
    strcpy(pszFullPathName, pszPath);
    if (pszFolderName)
    {
        if (pszPath[strlen(pszPath) - 1] != TW_FILE_DELIM)
            strcat(pszFullPathName, TW_FILE_DELIM_STR);
        strcat(pszFullPathName, pszFolderName);
    }
    return pszFullPathName;
} //> GsAppendFolderNameToPath(...)
//>----------------------------------------------------------------------------

void GsInitializeShutdownEvent()
{
    g_pGsShutdownEventStruct = GsCreateEventStruct();
} //> GsInitializeShutdownEvent()
//>----------------------------------------------------------------------------

// This function does not return until signaled
unsigned long GsWaitForShutdownEvent(unsigned long delay)
{
    unsigned long result = WAIT_FAILED;
    if (g_pGsShutdownEventStruct)
        result = GsWaitForEvent(g_pGsShutdownEventStruct, delay);
    return result;
} //> GsWaitForShutdownEvent(...)
//>----------------------------------------------------------------------------

// Wait for the shutdown signal on Windows
void GsWaitForShutdownSignal()
{
    unsigned long delay = INFINITE;
    // define delay variable for testing purposes
    GsCheckForShutdownSignal(delay);
} //> GsWaitForShutdownSignal()
//>----------------------------------------------------------------------------

// check for the shutdown signal
// return TRUE if shutdown signal was or has been received.
GS_BOOL GsCheckForShutdownSignal(unsigned long delay)
{
    // maintain state of shutdown signal.
    // This is requried because events are defined to 'auto-reset'.
    static unsigned long waitState = WAIT_FAILED;
    if (waitState == WAIT_OBJECT_0)
    {
        // shutdown has already been signaled.
        return TRUE;
    }
    // if return is WAIT_OBJECT_0, then shutdown received.  Otherwise return is WAIT_TIMEOUT
    waitState = GsWaitForShutdownEvent(delay);
    if (waitState == WAIT_OBJECT_0)
    {
        return TRUE;
    }
    return FALSE;
} //> GsCheckForShutdownSignal(...)
//>----------------------------------------------------------------------------

void GsSignalShutdownEvent()
{
    if (g_pGsShutdownEventStruct)
        GsSignalEvent(g_pGsShutdownEventStruct);
} //> GsSignalShutdownEvent(...)
//>----------------------------------------------------------------------------

void GsGsDestroyShutdownEvent()
{
    GsDestroyEventStruct(g_pGsShutdownEventStruct);
} //> GsGsDestroyShutdownEvent(...)
//>----------------------------------------------------------------------------

// Function pointer for a twlist destructor:
// Item will be removed from a list (by twlist), but NOT deleted.
// the Item entries memory is managed else where (by g_pPropertyTemplateList).
//
// Note:  if memory management becomes more difficult, may need to add
// some type of reference counting.
void GsDontDeleteFunc(void *pItem)
{
}
//>----------------------------------------------------------------------------

GS_BOOL GsIsPathAbsolute(const char *pszPath)
{
    if (pszPath == NULL || strlen(pszPath) == 0)
        return FALSE;
    if (pszPath[0] == '/' || pszPath[1] == ':')
        return TRUE;
    return FALSE;
} //> GsIsPathAbsolute(...)
//>----------------------------------------------------------------------------

// construct the dir from the input configured string.
// The configured string can be a relative or absolute path.
// if relative, it is appended to the current working directory.
// caller owns the returned memory
//
char *GsCreateRelOrAbsDir(char *pszConfiguredPath, char *pszCustomCwd)
{
    char *pszCwd = GsGetCwd();
    char *pszCurrentDir = pszCwd;
    int iLast = 0;
    int iStart = 0;
    int lenCwd = 0;
    char *pszOutputPath = NULL;
    if (strlen(pszCustomCwd) > 0)
        pszCurrentDir = pszCustomCwd;
    lenCwd = (int)strlen(pszCurrentDir);
    pszOutputPath = (char *)TW_MALLOC(lenCwd + strlen(pszConfiguredPath) + 4);
    if (GsIsPathAbsolute(pszConfiguredPath))
    {
        // absolute path
        strcpy(pszOutputPath, pszConfiguredPath);
    }
    else
    {
        // relative path
        strcpy(pszOutputPath, pszCurrentDir);
        iLast = ((int)strlen(pszOutputPath)) - 1;
        if (pszOutputPath[iLast] != TW_FILE_DELIM)
        {
            pszOutputPath[iLast + 1] = TW_FILE_DELIM;
            pszOutputPath[iLast + 2] = 0;
        }
        // remove leading ./, leave other configs like ../
        iStart = 0;
        if (pszConfiguredPath[0] == '.')
        {
            if (pszConfiguredPath[1] == '/' || pszConfiguredPath[1] == '\\')
                iStart = 2;
        }
        strcat(pszOutputPath, pszConfiguredPath + iStart);
    }
    // remove trailing / or \, so that twDirectory_FileExists() will work
    iLast = ((int)strlen(pszOutputPath)) - 1;
    if (pszOutputPath[iLast] == '/' || pszOutputPath[iLast] == '\\')
        pszOutputPath[iLast] = 0;

    if (twDirectory_FileExists(pszOutputPath) == FALSE)
    {
        GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Virtual directory does not exist. Trying to create... %s", pszOutputPath);
        twDirectory_CreateDirectory(pszOutputPath);
    }
    TW_FREE(pszCwd);
    return pszOutputPath;
} //> GsCreateRelOrAbsDir(...)
//>----------------------------------------------------------------------------

// General function to initiate a shutdown.  Set bRestartApplication to restart the Agent application.
void GsShutdownApplication(GS_BOOL bRestartApplication)
{
    twSleepMsec(1000); // enable any pending messages just before shutdown to be delivered.
    g_bReceivedShutdownSignal = TRUE;
    g_bRestartApplication = bRestartApplication;
    GsSignalShutdownEvent();
    ConnectionMgr_Disconnect("Application Shutdown");
} //> GsShutdownApplication(...)
//>----------------------------------------------------------------------------

// If file exists, backup by renaming with added timestamp
// returns return of the MoveFile instruction as the success code:  TW_OK or GetLastError()
int GsBackupFileWithTimestamp(char *pszFilename)
{
// Note:  Memory on the stack - it is not allocated.
#define TIME_BUFFER_SIZE (32)
    char szTimeBuffer[TIME_BUFFER_SIZE];
    int len = PATH_MAX + 1;
    char pszTimeStampedFilename[PATH_MAX + 1];
    char szExtension[PATH_MAX + 1];
    char *pszFilenameExtensionPos = NULL;

    if (!twDirectory_FileExists(pszFilename))
    {
        return TW_OK;
    }
    // sanity check to keep from blowing up the stack.
    if (strlen(pszFilename) + TIME_BUFFER_SIZE > PATH_MAX)
    {
        // do nothing to replace file.
        return TW_OK;
    }
    memset(pszTimeStampedFilename, 0, len);
    memset(szExtension, 0, len);
    // Get the file extension.
    strcpy(pszTimeStampedFilename, pszFilename);
    pszFilenameExtensionPos = strrchr(pszTimeStampedFilename, '.'); // reverse find.
    if (pszFilenameExtensionPos)
    {
        // Normal assmption is there is a file extension.
        strcpy(szExtension, pszFilenameExtensionPos);
        pszFilenameExtensionPos[0] = 0; // This null-terminates the new file name before the exstionsion.
    }
    // append timestamp to core file name and tehn append the extension back to the filename.
    twGetSystemTimeString(szTimeBuffer, "_%Y%m%d_%H%M%S", TIME_BUFFER_SIZE, FALSE, TRUE);
    strcat(pszTimeStampedFilename, szTimeBuffer);
    strcat(pszTimeStampedFilename, szExtension);                      // Note:  for rare conditions, the extension could be NULL.
    return twDirectory_MoveFile(pszFilename, pszTimeStampedFilename); // rename file.
} //> GsBackupFileWithTimestamp(...)
//>----------------------------------------------------------------------------
