//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  ConnectionMgr.c
//
//  Subsystem  :  EMS_GetConnected
//
//  Description:
/*
     Central management of connecting, reconnecting and disconnecting to/from the ThingWorx Server via the C-SDK. 

     Why is this module necessary? The SDK implementation of auto-reconnect is not considered to be robust enough.
     The SDK is not rebust enough nor consistent in its management of the connection to handle 
     1) a Server that is down 
     2) auto-retry - where the SDK either stops trying to reconnect after n-retries or stays in too tight of a while loop when reconnecting.
     3) consistent workflow of unexpected loss of connection (i.e. on a read opertation error instead of just
        'disconnecting' and letting another process auto-reconnected, the SDK attempts to restart the socket
         which can cause a potential issue if multiple threads are seeking the establish the connection simultaneously).

    Essential global functions:
    - ConnectionMgr_Connect():  Use SDK functions to establish a connection with the Server.
       If there is a failure to connect, the thread will manage re-connection. 
    - ConnectionMgr_Disconnect():  Use the SDK functions to disconenct from the Sever.
    - 

    This code follows the standard pattern for a functional module with global functions for:  initialize, start and shutdown
    - ConnectionMgr_Initialize():
      *  Create the (locally) global thread structure
      *  Register callbacks with the SDK to be notified when a connection occurs and when a disconnect occurs.
    - ConnectionMgr_Start():
      *  Start the thread that manages keeping the connection alive. 
    - ConnectionMgr_Shutdown():
      *  Initiate disconnect
      *  Unregister callbacks
      *  stop the thread.

    Thread workflow:
    - Periodically check if still connected.  Thread can be signalled to auto-reconnect if a disconnect occurs.
    - If not connected:
      * Delay before attempting to re-connect.  [See thead function for details]
      * attampt to reconnect. 
*/

#include "AgentConfig.h"
#include "ConnectionMgr.h"
#include "DataSimulatorMgr.h"
#include "twSwUpdateManager.h"
#include "ExtDataAcquisition.h"
#include "DelayedTasksMgr.h"
#include "configParams.h"
#include "properties.h"
#include "services.h"

// private (locally global) variables
static GsThreadStruct *g_pConnectionMgrThreadStruct = NULL;
uint64_t g_disconnectedPeriodBeforeReboot = 60 * 60 * 1000; // default 1 hour
GS_BOOL g_lastConnectedState = FALSE;
uint64_t g_lastDisconnectedTS = 0;

// function prototypes
THREAD_FUNCTION_RETURN ConnectionMgrThreadFunction(void *pVoid);

static void ConnectionMgr_AutoReconnect();
static int OnBindCloseCallbackEventHandler(twWs *pWs, const char *pszReason, size_t length);
static int OnConnectedCallbackEventHandler(twWs *pWs, const char *pszData, size_t length);
static void OnAuthenticatedCallbackEventHandler(char *credentialType, char *credentialValue, void *userdata);
static void OnBindEventCallbackEventHandler(char *entityName, char isBound, void *userdata);

// !!! code is subject to change per API release.
// Todo:
// SDK string using in BindClose Callback when the SDK is restarting the Socket.
// These are then used to indicate a RestartingSocket use case.
static const char *g_pszFrameReadTimeout = "Frame read timeout";
static const char *g_pszSocketError = "Socket Error";

static GS_BOOL g_bSDKIsRestartingSocket = FALSE;
static unsigned long g_restartingSocketDelay = 30000; // default:  wait 30 seconds if restarting the socket.
/* Variable indicating if the Agent should auto-reconnect.  Reconnects are inhibited during shutdown. */
static GS_BOOL g_bInihibitReconnection = FALSE;
//>----------------------------------------------------------------------------

void ConnectionMgr_Initialize()
{
    g_pConnectionMgrThreadStruct = GsCreateThreadStruct();
    if (g_pConnectionMgrThreadStruct)
    {
        // Thread only wakes up when signalled.
        g_pConnectionMgrThreadStruct->m_waitMilliSec = INFINITE;
    }
    // subscribe to SDK for conntion related callbacks.
    twApi_RegisterCloseCallback(OnBindCloseCallbackEventHandler);
    twApi_RegisterConnectCallback(OnConnectedCallbackEventHandler);
    twApi_RegisterOnAuthenticatedCallback(OnAuthenticatedCallbackEventHandler, TW_NO_USER_DATA);
    //twApi_RegisterBindEventCallback(g_pszThingIdentifier, OnBindEventCallbackEventHandler, TW_NO_USER_DATA);
} //> ConnectionMgr_Initialize()
//>----------------------------------------------------------------------------

int ConnectionMgr_Start()
{
    // start the thread
    twcfg.connect_retries = 10;
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ConnectionMgr:  Initiate start of thread");
    GsStartThread(g_pConnectionMgrThreadStruct, ConnectionMgrThreadFunction);
    return TW_OK;
} //> ConnectionMgr_Start()
//>----------------------------------------------------------------------------

void ConnectionMgr_ShuttingDown()
{
    g_bInihibitReconnection = TRUE;
} //> ConnectionMgr_ShuttingDown()
//>----------------------------------------------------------------------------

void ConnectionMgr_Shutdown()
{
    // Force SDK-disconnect.
    ConnectionMgr_Disconnect("Shutting down");

    // Unregister the callback.  Do NOT call the close calback after thg connection mgr is shutdown.
    // This avoids calling the disconnect manager during API delete.
    twApi_RegisterCloseCallback(NULL);

    // stop the thread
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ConnectionMgr:  Initiate shutdown");
    GsStopThread(g_pConnectionMgrThreadStruct);
    GsDestroyThreadStruct(g_pConnectionMgrThreadStruct);
    g_pConnectionMgrThreadStruct = NULL;
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ConnectionMgr:  shutdown complete");
} //> ConnectionMgr_Shutdown()
//>----------------------------------------------------------------------------

// bForceConnection true is essentially an 'auto-reconnect' mode of operation.
ConnectionStatus ConnectionMgr_Connect(GS_BOOL bForceConnection)
{
    int err = TW_OK;
    // No need to proceed if already connected.
    if (twApi_isConnected() || twApi_ConnectionInProgress())
    {
        g_lastConnectedState = TRUE;
        g_lastDisconnectedTS = 0;
        GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ConnectionMgr_Connect:  Already connected or connection is in process.");
        return csSuccess;
    }
    if (bForceConnection == TRUE)
    {
        // ignore inhibit reconnection input for force connection:  On loss of connection, do auto reconnect.
        g_bInihibitReconnection = FALSE;
    }
    else
    {
        g_bInihibitReconnection = TRUE;
    }
    /* Connect to server */
    err = twApi_Connect(twcfg.connect_timeout, twcfg.connect_retries);
    if (err)
    {
        g_lastConnectedState = FALSE;
        g_lastDisconnectedTS = twGetSystemMillisecondCount();
        if (bForceConnection == FALSE)
        {
            // It is not the connection manager's responsiblity to force a connection.
            return csFailed;
        }
        else
        {
            // On failure, let thread manage making a connection.
            ConnectionMgr_AutoReconnect();
            return csAsyncRetry;
        }
    }
    if (twApi_isConnected())
    {
        g_lastConnectedState = TRUE;
        g_lastDisconnectedTS = 0;
    }
    return csSuccess;
} //> ConnectionMgr_Connect(...)
//>----------------------------------------------------------------------------

int ConnectionMgr_Disconnect(char *pszReason)
{
    //Ensure the manual disconnect does not initated a reconnect via the OnBindCloseCallbackEventHandler()
    g_bInihibitReconnection = TRUE;
    // in case SDK is retrying to make a connections, stop it.
    twApi_StopConnectionAttempt();
    // give it a small window to finish before calling disconnect.
    // Another non-Deterministic solution due to SDK coding.
    twSleepMsec(1000);
    twApi_Disconnect(pszReason);
    g_lastConnectedState = FALSE;
    g_lastDisconnectedTS = twGetSystemMillisecondCount();
    return TW_OK;
} //> ConnectionMgr_Disconnect(...)
//>----------------------------------------------------------------------------

void ConnectionMgr_AutoReconnect()
{
    // Wake-up the thread to connect.
    g_bInihibitReconnection = FALSE;
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "ConnectionMgr:  Connection lost. Attempting to reconnect.");
    GsSignalThread(g_pConnectionMgrThreadStruct);
} //> ConnectionMgr_AutoReconnect()
//>----------------------------------------------------------------------------

/**
 * @brief Set the Disconnected Period Before Reboot 
 * 
 * @param disconnectedPeriodBeforeReboot Input time in hours 
 */
void SetDisconnectedPeriodBeforeReboot(double disconnectedPeriodBeforeReboot)
{
    g_disconnectedPeriodBeforeReboot = (uint64_t)(disconnectedPeriodBeforeReboot * 60 * 60 * 1000);
} //> SetDisconnectedPeriodBeforeReboot()
//>----------------------------------------------------------------------------

// Thread to manage API tasker
THREAD_FUNCTION_RETURN ConnectionMgrThreadFunction(void *pVoid)
{
    GS_BOOL bStartUpDelayCompleted = FALSE;
    GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid; // The void* parameter is always the thread struct pointer
    if (!pGsThreadStruct)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "ConnectionMgr:  Thread initialiation error.  Exiting thread.");
        return (THREAD_FUNCTION_RETURN)-1;
    }
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ConnectionMgr:  Thread started.  Thread id = %x (hex)", pGsThreadStruct->m_threadId);
#if defined(LEGATO)
    le_thread_InitLegatoThreadData("ConnectionMgr");
#endif // LEGATO
    while (pGsThreadStruct->m_bRunning)
    {
        int res = TW_OK;
        // Wait for signal from AutoReconnect  or shutdown.
        int waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);
        GsAppLog(GS_TRACE, MODULE_GS_DATA, "ConnectionMgr: %s running(%s)",
                 (waitReturnCondition == WAIT_OBJECT_0 ? "Signal received." : "Thread wakup due to timeout."),
                 (pGsThreadStruct->m_bRunning ? "true" : "false"));
        if (!twApi_isConnected() && g_lastConnectedState)
        {
            g_lastConnectedState = FALSE;
            g_lastDisconnectedTS = twGetSystemMillisecondCount(); // mark first timestamp
        }
        else if (twApi_isConnected())
        {
            g_lastConnectedState = TRUE;
            g_lastDisconnectedTS = 0;
        }
        /* Time to wait before rebooting the device in an act of failure to connect to the platform*/
        while (pGsThreadStruct->m_bRunning && !twApi_isConnected() && !g_bInihibitReconnection && !twApi_ConnectionInProgress())
        {
            if (!g_lastConnectedState && g_lastDisconnectedTS > 0 && (twGetSystemMillisecondCount() - g_lastDisconnectedTS > g_disconnectedPeriodBeforeReboot))
            {
                GsAppLog(GS_FORCE, MODULE_GS_RUNTIME,
                         "ConnectionMgr: Restarting the application in full. Disconnected state for more than %lu ms.", g_disconnectedPeriodBeforeReboot);
                GsShutdownApplication(TRUE); //! force restart
                g_lastConnectedState = FALSE;
                g_lastDisconnectedTS = twGetSystemMillisecondCount(); // mark first timestamp
                ConnectionMgr_Disconnect("Forced Application Restart");
                break; // quit loop
            }
            // Need to delay for two reasons.
            // 1.  If SDK is in the middle of calling restartSocket() as indicated by the flag g_bSDKIsRestartingSocket,
            //     there is a potential deadlock condition.
            //     The workflow to set the g_bSDKIsRestartingSocket is to to stop the ThingWorx Server -
            //     but depending on the SDK workflow, you may get a disconnect and callback to bindClose without
            //     it being a restarting of the socket.
            //     In the case of g_bSDKIsRestartingSocket == TRUE, we need to have a delay to avoid a potential
            //     race/deadlock condition.
            //     The delay is currently defined based on empirical data.
            //  2.  Need a random delay before re-connecting to the server.  This is for scalabiltiy purposes to
            //      prevent 'x' Agent from simultaneously attempting to connect to a rebooted server.
            // There is no harm in invoking both delays.  The only use case of concern would be Low Power Mode,
            // but it has an override for how long to wait before suspending.
            if (g_bSDKIsRestartingSocket)
            {
                // have thead delay to allow for a clean shutdown.
                pGsThreadStruct->m_waitMilliSec = g_restartingSocketDelay;
                g_bSDKIsRestartingSocket = FALSE;
                GsAppLog(GS_INFO, MODULE_GS_RUNTIME,
                         "ConnectionMgr:  Delaying %i ms before attempting to reconnect to the ThingWorx Server - due to restartSocket error.",
                         pGsThreadStruct->m_waitMilliSec);
                break;
            }
            if (bStartUpDelayCompleted == FALSE)
            {
                unsigned int startUpDelay = twcfg.max_connect_delay;
                bStartUpDelayCompleted = TRUE;
                // have thread delay to allow for a clean shutdown.
                if (startUpDelay < 100)
                {
                    startUpDelay = 5000; // 5s fallback
                }
                pGsThreadStruct->m_waitMilliSec = startUpDelay;
                GsAppLog(GS_INFO, MODULE_GS_RUNTIME,
                         "ConnectionMgr:  Delaying %i ms before attempting to reconnect to the ThingWorx Server.",
                         pGsThreadStruct->m_waitMilliSec);
                break;
            }
            if (g_bReceivedShutdownSignal)
                break;
            // Attempt to make a connection.
            // Note:  Do not call ConnectionMgr_Connect() because it needs to handle other uses cases
            //        besides connecting.
            GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "ConnectionMgr:  Attempting to reconnect to the ThingWorx Server.");
            res = twApi_Connect(twcfg.connect_timeout, twcfg.connect_retries);
            if (res == TW_OK && twApi_isConnected())
            {
                g_lastConnectedState = TRUE; // mark as connected
                g_lastDisconnectedTS = 0;    // reset timer
                GsAppLog(GS_FORCE, MODULE_GS_RUNTIME,
                         "ConnectionMgr: ThingWorx Server connection re-establishment was successful");
                // wait for next signal that an action is needed.
                pGsThreadStruct->m_waitMilliSec = INFINITE;
            }
            else
            {
                g_lastConnectedState = FALSE;
            }
            // reset flag so random delay will occur at the next connection attempt.
            bStartUpDelayCompleted = FALSE;
        } //# while is not connected
        //#
    } //# while thread is running
    // exit
    GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ConnectionMgr:  extiting thread");
#if defined(LEGATO)
    le_thread_CleanupLegatoThreadData();
#endif // LEGATO
    return 0;
} //> ConnectionMgrThreadFunction(...)
//>----------------------------------------------------------------------------

int AutoBindItemsCallbackWrapper(twInfoTable *pContent, char *pBuffer, int bufferSize)
{
    if (!pBuffer || !pContent)
        return -1;
    char *itemNamesOutput = pBuffer;
    char tmp[256];
    const int tmpSize = 256;
    const int length = (pContent != NULL ? pContent->rows->count : -1);
    int numChars = 0;
    int idx = 0, nameIndex = -1;
    twInfoTableRow *pRow = NULL;
    twPrimitive *pValue = NULL;
    memset(itemNamesOutput, 0, bufferSize);
    if (length > 0 && twDataShape_GetEntryIndex(pContent->ds, "name", &nameIndex) == TW_INDEX_NOT_FOUND)
        nameIndex = -1;
    for (; idx < length && nameIndex != -1; idx++)
    {
        pRow = twInfoTable_GetEntry(pContent, idx);
        pValue = twInfoTableRow_GetEntry(pRow, nameIndex);
        if (pValue && pValue->type == TW_STRING)
        {
            memset(tmp, 0, tmpSize);
            snprintf(tmp, tmpSize, "[%s] ", pValue->val.bytes.data);
            snprintf(itemNamesOutput + numChars, bufferSize - 1 - numChars, "%s", tmp);
            numChars = strnlen(itemNamesOutput, bufferSize);
        }
    } //# for each infotable row
    return length;
} //> AutoBindItemsCallbackWrapper(...)
//>----------------------------------------------------------------------------

int AutoBindPropertiesServiceCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent)
{
    char propertyNamesOutput[4096];
	memset(propertyNamesOutput, 0, 4096);
    const int length = AutoBindItemsCallbackWrapper(pContent, propertyNamesOutput, 4096);
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "ConnectionMgr: Automatically bound %d properties:\r\n%s", length, propertyNamesOutput);
    StaticPropertyUpdate();
    twInfoTable_Delete(pContent);
    return TW_OK;
} //> AutoBindPropertiesServiceCallback(...)
//>----------------------------------------------------------------------------

int AutoBindServicesServiceCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent)
{
    char serviceNamesOutput[4096];
	memset(serviceNamesOutput, 0, 4096);
	const int length = AutoBindItemsCallbackWrapper(pContent, serviceNamesOutput, 4096);
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "ConnectionMgr: Automatically bound %d services:\r\n%s", length, serviceNamesOutput);
    //StaticPropertyUpdate();
    twInfoTable_Delete(pContent);
    return TW_OK;
} //> AutoBindServicesServiceCallback(...)
//>----------------------------------------------------------------------------

void AutoBindRemotePropertiesAndServices()
{
    char *remoteThingName = g_pszRemoteThingName;
    if (!remoteThingName)
    {
        remoteThingName = g_pszThingIdentifier; // fallback to use thing identifier
    }
    if (!remoteThingName)
    {
        GsAppLog(GS_WARN, MODULE_GS_RUNTIME, "AutoBindRemotePropertiesAndServices: Skipping action - remote thing name / identifier is not available!");
        return;
    }
    if (!g_pszRegistrationThingName)
    {
        GsAppLog(GS_WARN, MODULE_GS_RUNTIME, "AutoBindRemotePropertiesAndServices: Skipping action - remote registration thing name is unknown!");
        return;
    }
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "AutoBindRemotePropertiesAndServices: Automatically binding remote items for thing '%s'.", remoteThingName);
    uint32_t msgId = 0;
    twInfoTable *pItInputA = NULL;
    twInfoTable *pItInputB = NULL;
    pItInputA = twInfoTable_CreateFromString(STR_BIND_REMOTE_THING_NAME, remoteThingName, TRUE);
    pItInputB = twInfoTable_CreateFromString(STR_BIND_REMOTE_THING_NAME, remoteThingName, TRUE);
    //! Properties auto bind
    twApi_InvokeServiceAsync(TW_THING, g_pszRegistrationThingName,
                             STR_BIND_PROPERTIES_SERVICE, pItInputA,
                             TRUE, AutoBindPropertiesServiceCallback, &msgId);
    //! Services auto bind
    twApi_InvokeServiceAsync(TW_THING, g_pszRegistrationThingName,
                             STR_BIND_SERVICES_SERVICE, pItInputB,
                             TRUE, AutoBindServicesServiceCallback, &msgId);
    twInfoTable_Delete(pItInputA);
    twInfoTable_Delete(pItInputB);
} //> AutoBindRemotePropertiesAndServices()
//>----------------------------------------------------------------------------

int OnConnectedCallbackEventHandler(twWs *pWs, const char *pszData, size_t length)
{
    // Called when a connection is established (re-established)
    return TW_OK;
} //> OnConnectedCallbackEventHandler(...)

typedef struct RegisterAgentCallbackInfo
{
    uint32_t id;
    enum msgCodeEnum code;
    char *reason; // duplicated
    twInfoTable *pContent;
} RegisterAgentCallbackInfo;

void RegisterAgentDelayedTask(void *pUserData)
{
    if (!pUserData)
        return;
    RegisterAgentCallbackInfo *pCallbackInfo = (RegisterAgentCallbackInfo *)pUserData;
    uint32_t id = pCallbackInfo->id;
    enum msgCodeEnum code = pCallbackInfo->code;
    char *reason = pCallbackInfo->reason;
    twInfoTable *pContent = pCallbackInfo->pContent;

    twPrimitive *pPrimResult = NULL;
    cJSON *pJsonResult = NULL;
    cJSON *pJsonInnerResult = NULL;
    cJSON *pJsonTemp = NULL;
    int success = 0;
    int err = 0;
    char *stringified = NULL;
    GS_BOOL isFirstRegistration = FALSE;
    if (!g_pszThingIdentifier || strlen(g_pszThingIdentifier) == 0)
    {
        isFirstRegistration = TRUE;
    }
    GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME, "Agent Registration Callback for fabNumber='%s', imeiNumber='%s', msgId='%u'",
             g_pszFabNumber, g_pszImeiNumber, id);
    if (code == TWX_SUCCESS)
    {
        twInfoTable_GetPrimitive(pContent, STR_IT_COL_RESULT, 0, &pPrimResult);
        pJsonResult = twPrimitive_ToJson("result", pPrimResult, NULL);
        stringified = cJSON_Print(pJsonResult);
        pJsonInnerResult = cJSON_GetObjectItem(pJsonResult, "result"); // wrapped
        pJsonTemp = cJSON_GetObjectItem(pJsonInnerResult, STR_SUCCESS);
        if (isFirstRegistration)
        {
            GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME,
                     "%s: result='%s'",
                     g_pszRegistrationServiceName, stringified);
        }
        success = pJsonTemp->valueint;
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Registration of '%s' Thing responded with %s success status.",
                 g_pszRegistrationThingName, success ? "TRUE" : "FALSE");
        if (success)
        {
            // This will also trigger any additional file saving operations
            ParseRegisterServiceOutput(pJsonInnerResult);
            ExtDataAcquisition_ReadConfiguration();
        }
        TW_FREE(stringified);
        cJSON_Delete(pJsonResult);
    }
    else
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Current twApi pointer value: %p", twApi_GetApi());
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Failed to properly register Agent via '%s' Thing: %s", g_pszRegistrationThingName, reason);
    }
    twInfoTable_Delete(pContent);
    if (!g_bFirstTimeCallbacksSetup)
    {
        twApi_UnregisterSynchronizeStateEventCallback(g_pszThingIdentifier,
                                                      PushSubscribedPropertiesAsyncSynchronizeStateCallback,
                                                      TW_NO_USER_DATA);
        twApi_UnregisterSynchronizeStateEventCallback(NULL,
                                                      PushSubscribedPropertiesAsyncSynchronizeStateCallback,
                                                      TW_NO_USER_DATA);
        twApi_RegisterSynchronizeStateEventCallback(g_pszThingIdentifier,
                                                    PushSubscribedPropertiesAsyncSynchronizeStateCallback,
                                                    TW_NO_USER_DATA);

        twApi_UnregisterBindEventCallback(g_pszThingIdentifier,
                                          OnBindEventCallbackEventHandler,
                                          TW_NO_USER_DATA);
        twApi_UnregisterBindEventCallback(NULL,
                                          OnBindEventCallbackEventHandler,
                                          TW_NO_USER_DATA);
        twApi_RegisterBindEventCallback(g_pszThingIdentifier,
                                        OnBindEventCallbackEventHandler,
                                        TW_NO_USER_DATA);

        //!DataPublishingMgr_Initialize();
        // Start data acquistion and publishing.
        //!DataPublishingMgr_Start();
        //! Before initializing, check if simulator is to be used.
        //!DataSimulatorMrg_ReadConfiguration();
        if (g_bSimulatorEnabled)
        {
            DataSimulatorMgr_Initialize();
            DataSimulatorMgr_Start();
        }
        ExtDataAcquisition_Start();
        GsAppLog(GS_FORCE, MODULE_GS_RUNTIME, "Initialization: Setting up callbacks");
    } //? is First Time Callbacks Setup
    twSleepMsec(250);
    GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME, "Checking if entity '%s' is properly bound.", g_pszThingIdentifier);
    if (!twApi_IsEntityBound(g_pszThingIdentifier))
    {
        GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Attempting to bind with '%s' Thing.", g_pszThingIdentifier);
        err = twApi_BindThing(g_pszThingIdentifier);
        if (err != TW_OK)
        {
            GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "Initialization: ConnectToTWPlatform_Start, unable to bind");
        }
    }
    g_bFirstTimeCallbacksSetup = TRUE;
    if (reason)
        TW_FREE(reason);
} //> RegisterAgentDelayedTask(...)

int RegisterAgentCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent)
{
    if (!DelayedTasks_IsActivated())
        return TW_OK;
    RegisterAgentCallbackInfo *pData = (RegisterAgentCallbackInfo *)TW_MALLOC(sizeof(RegisterAgentCallbackInfo));
    pData->id = id;
    pData->code = code;
    pData->reason = NULL;
    if (reason)
        pData->reason = GsStringDup(reason);
    pData->pContent = pContent;
    DelayedTasks_AddTask(RegisterAgentDelayedTask, pData, TRUE);
    return TW_OK;
} //> RegisterAgentCallback(...)
//>----------------------------------------------------------------------------

void OnAuthenticatedDelayedTask(void *pUserData)
{
    // there won't be any user data required here
    uint32_t msgId = 0;
    twInfoTable *pItInput = NULL;
    twInfoTableRow *pInputRow = NULL;
    twDataShape *pItDataShape = NULL;
    pItDataShape = twDataShape_Create(twDataShapeEntry_Create(STR_REGISTER_FAB_NUMBER, "", TW_STRING));
    twDataShape_AddEntry(pItDataShape, twDataShapeEntry_Create(STR_REGISTER_IMEI_NUMBER, "", TW_STRING));
    twDataShape_AddEntry(pItDataShape, twDataShapeEntry_Create(STR_REGISTER_DETAILS_1, "", TW_INTEGER));
    twDataShape_AddEntry(pItDataShape, twDataShapeEntry_Create(STR_REGISTER_DETAILS_2, "", TW_INTEGER));

    pItInput = twInfoTable_Create(pItDataShape);
    pInputRow = twInfoTableRow_Create(twPrimitive_CreateFromString(g_pszFabNumber, TRUE));
    twInfoTableRow_AddEntry(pInputRow, twPrimitive_CreateFromString(g_pszImeiNumber, TRUE));
    twInfoTableRow_AddEntry(pInputRow, twPrimitive_CreateFromInteger(g_iMachineDetails_1));
    twInfoTableRow_AddEntry(pInputRow, twPrimitive_CreateFromInteger(g_iMachineDetails_2));
    twInfoTable_AddRow(pItInput, pInputRow);
    //retCode = twApi_InvokeService(TW_THING, g_pszRegistrationThingName,
    //                              g_pszRegistrationServiceName, pItInput,
    //                              &pItResult, -1, TW_PUSH_CONNECT_FORCE);
    twApi_InvokeServiceAsync(TW_THING, g_pszRegistrationThingName,
                             g_pszRegistrationServiceName, pItInput,
                             TW_PUSH_CONNECT_FORCE, RegisterAgentCallback, &msgId);
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Attempting at registration with fabNumber='%s', imeiNumber='%s', msgId='%u'",
             g_pszFabNumber, g_pszImeiNumber, msgId);
    twInfoTable_Delete(pItInput);
}

void OnAuthenticatedCallbackEventHandler(char *credentialType, char *credentialValue, void *userData)
{
    /* Callbacks only when we have connected & authenticated */
    if (!credentialType)
        return;
    if (DelayedTasks_IsActivated())
        DelayedTasks_AddTask(OnAuthenticatedDelayedTask, NULL, FALSE);
    GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME, "authEventHandler: Authenticated using %s.  Userdata = 0x%x", credentialType, userData);
} //> OnAuthenticatedCallbackEventHandler(...)
//>----------------------------------------------------------------------------

typedef struct OnBindEventCallbackInfo
{
    char *entityName;
    char isBound;
} OnBindEventCallbackInfo;

void OnBindEventDelayedTask(void *pUserData)
{
    if (!pUserData)
        return;
    char isBound = ((OnBindEventCallbackInfo *)pUserData)->isBound;
    char *entityName = ((OnBindEventCallbackInfo *)pUserData)->entityName;
    ((OnBindEventCallbackInfo *)pUserData)->entityName = NULL;
    /* First NULL says "tell me about all things that are bound */
    if (isBound && !g_bFirstTimeBoundComplete)
    {
        /*****************************************
		Register properties/services here
		*****************************************/
        // Register the static properties
        RegisterStaticProperties();
        // Register the services
        RegisterServices();
        // Also need to register all other properties - this includes dynamic
        // properties (like from simulator) or the ones coming from the config.
        // Need to determine additional support for removing old properties.
        // This can be done in the registration service.
        {
            // Auto bind (create properties and bind to remote names)
            // It actually will call helper service at platform side
            AutoBindRemotePropertiesAndServices();
        }
        // slight delay to ensure that async bind call finished
        // not the best practice, but in this case it'll work if there weren't any
        // connection issues on start
        twSleepMsec(1500); // One-time update of static properties
        GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "bindEventHandler: Entity '%s' was Bound.", entityName);
        g_bFirstTimeBoundComplete = TRUE;
    }
    else
    {
        GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME, "bindEventHandler: Entity '%s' was Unbound!", entityName);
    }
    TW_FREE(entityName);
} //> OnBindEventDelayedTask(...)

void OnBindEventCallbackEventHandler(char *entityName, char isBound, void *userData)
{
    if (!DelayedTasks_IsActivated())
        return; //! skip
    OnBindEventCallbackInfo *pData = (OnBindEventCallbackInfo *)TW_MALLOC(sizeof(OnBindEventCallbackInfo));
    pData->entityName = GsStringDup(entityName);
    pData->isBound = isBound;
    // Execute in a different thread! (outside of message/async loop)
    DelayedTasks_AddTask(OnBindEventDelayedTask, pData, TRUE);
} //> OnBindEventCallbackEventHandler(...)
//>----------------------------------------------------------------------------

/*
** Function to handle websocket disconnect.
** The websocket reconnect is initated in all unexpected network connectivity
** issues except:
** - RestartApplication service
** - RestartDevice service
** - Receive Shutdown signal
** 
*/
int OnBindCloseCallbackEventHandler(twWs *pWs, const char *pszReason, size_t length)
{
    int res = TW_OK;
    // note:  SDK does not correctly format and null terminate all the pszReason strings.  Print only the 1st 256 characters.
    char szShortReason[512];
    memset(szShortReason, 0, 512);
    if (pszReason)
    {
        strncpy(szShortReason, pszReason, length > 511 ? 511 : length);
    }
    GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME,
             "Activation: OnBindCloseCallbackEventHandler, Invoked close callback function because of '%s'",
             szShortReason);
    // Have swUpdateManager abort all jobs --- Utilities SCM doesn't know how to process a job after a loss of connection.
    if (twSwUpdateManager_AbortJobs())
    {
        GsAppLog(GS_TRACE, MODULE_GS_SCM, "ConnectionMgr: all software update jobs aborted due to a loss of connection.");
    }
    // clear flag indicating that initial Platform communication has been initialized.
    g_bServerHandshakingInitializationCompleted = FALSE;
    if (g_bInihibitReconnection)
    {
        // either shutting down, manually disconnected or in a 'disconnected' mode of operation.
        GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "ConnectionMgr: OnBindCloseCallbackEventHandler, received a disconnect signal but not in a state to initiate a reconnect.");
    }
    else
    {
        // Need to auto-reconnect via the connection manager.
        // Do NOT attempt to call API function when in a callback, instead signal API Connection thread to reconnect.
        // Verify that a reconnect is enabled (during disconnected mode reconnections are disabled except when connecting).
        GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME, "ConnectionMgr: OnBindCloseCallbackEventHandler, signalling ConnectionMgr to reconnect with ThingWorx Server");
        if (szShortReason && (strcmp(szShortReason, g_pszFrameReadTimeout) == 0 || strcmp(szShortReason, g_pszSocketError) == 0))
        {
            g_bSDKIsRestartingSocket = TRUE; // this forces an extra delay to wait for the SDK and avoid potential dead-lock / conflict.
        }
        ConnectionMgr_AutoReconnect();
    }
    return res;
} //> OnBindCloseCallbackEventHandler(...)
