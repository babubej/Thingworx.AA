/*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
******************************************************************************
//
//  Filename   :  main.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:  this is the 'main' entry point to starting the application.

************************************
***** Running the application ******
************************************
The ELGiAgent can be run in both Windows and Linux.  
In Windows, the default is to run 'console' mode
Windows executable input parameters:
   -register [service name]. 
        Description:  This registers the application to run as a Windows Service.  
            The optional [service name] is the name of the Windows Service.
            If the service name is not provided, the default name is:  ThingWorxAgent.
            The Service is registered with the startup type set to 'Automatic'.

   -unregister [service name]"
        Description:  This unregisters the application from running as a Windows Service.  
            The optional [service name] is the name of the Windows Service.
            If the service name is not provided, the default name is:  ThingWorx Agent.
Linux executable input parameters:
  -D  This indicates the application is to be run as a daemon.

The configuration of the ThingWorx SDK and this application is read from a set of JSON files.
See the user's guide for details.

*************************
***** General Info ******
*************************
This is an overall description of the entire system; this is essentually a "developers user's guide".
Note:  as always, where there are 'too many fingers in the pie', the code gets messier than desired and not consistent in formatting or style.

This application is multi-threaded executable with static libraries. 
It has an OS abstration layer for portability.  The application is written in 'C' and roughly follows 
the coding standard defined in the document:  "C++ Code Standard for GSO-IoT.docx" 
Important naming conventions include:
- Functions start with an upper case.
- Structures start with an upper case.
- variables start with a lower case.
    - variable prefixes include:
       g_    global variable.  This can be used for variable that are global in scope to the application, 
             but most frequently it is used for variables that are static and only ‘global’ in scope to the file.
       b     boolean
       m_    a member of a data structure.

The term 'module' is used in these descriptions to refer to a functional unit, usually defined within a .c/.h file.

**************************************************
***** Initialization - Startup  - Shutdown  ******
**************************************************

The overall process flow of the application is as follows:
 - Initialize
 - Start
 - Wait For Shutdown signal
 - Shutdown

Most functional modules have function that follow the convention <module name>_<function> for example:
<module_name>_Initialize
<module_name>_Start
<module_name>_Shutdown

Some modules with threads also have a function:
<module_name>_SignalThread

During initialization configuration files are read, data structures are allocated and/or initialized
During Start:  Each module's '_Start' is called.  This is where threads are started.  
After Start:  The system is essentially event based on timing loops that acquire data and events
              or via Service calls from the SDK layer.
Shutdown:  This system can be shutdown via a Service call or via a signal from the OS layer.  Each module is shutdown individually.

*********************************
*****  File descriptions  *******
*********************************

File descriptions are grouped along functional lines

**** Process workflow   ****
- main.c   
    calls overall functions responsible for initialization, startup and shutdown
- Initialization.c
    managaes overall initialization (including device registration with the Server) and Startup 
- Shutdown.c
    manages overall shutdown

**** Configuration *****
For a detailed description of each .json file, see the design specification section 2.2

- configParams.c
    reads the configuration files and sets configuration data structures for the application and the SDK.

****  SDK Threads  *****
The SDK is essentially built as a single threaded task manager, but instead, 
the tasks can be managed by threads in a multi-threaded application.
- API_Task.c
     Thread to manage the tw-c-sdk twApi_TaskerFunction()
- MessageThreadPoolMgr.c
     Thread to manage the tw-c-sdk twMessageHandler_msgHandlerTask()
- SCM_Task.c
      Manage interface with ThingWorx Utilities Software Content Management (SCM).
      Create & Destroy the twSwUpdateManager
      Create Thread to manage the twSwUpdateManager_TaskerFunction for SCM tasks.
      Manage the 'install script'
      Process the swUpdateManager notification callback.

      >>> NOTE: <<<
        This code will need to be modified if using a [to be released] version of the SDK that directly supports SCM.

****  Connectivity Thread  *****
- ConnectionMgr.c
     Interface wrapper for connecting to the ThingWorx server via the C-SDK.
     Thread to manage re-connecting with connectivity is lost.

****  Data Acquistion and Publishing *****
- DataSimulator.c
    Using simulator.json - you can enable and configure a data simulator. 
    This was designed for testing throughput.
    Generally speaking, there is no need to mix the data simulator and actual data acquisition.
- DataPublishingMgr.c
    Thread to manage a list of properties and use the SDK to publish (i.e. send) the data to the Server.  
    Due to limitation ins the SDK Subscribed Properties Manager (SPM), the DataPublishingManager needs to actively (and asynchronously) 
    queue properties while the SCM is synchronously (i.e. a blocking operation) sending data to the Server.

****  Misc Modules   ****
- ErrorEventMgr.c
    Thread to manage intercepting of log errors and sending them as SDK Events to the Server.
    The publishing of events is configurable in the file agent_config.json and by default is diabled. 
    This code is a good example of firing events via the SDK in a thread safe manner.

- fileWatcher.c
    File download complete function to enable updating of logging configuration with needing an agent restart. 

- LoggingMgr.c  
    Manage logging of SDK and application information to a file
    
- properties.c
    Send static Agent informational properties to the Server.

- Services.c
    Definition and implementation of the application's servcies which are called (invoked) via the Server.

**** Utilities and OS abstration ******
- GsThread.c
    OS abstracted threading functions.
- GsTheadWin.c
    Windows specific threads and events management.
- GSThreadLinux
    Linux specific threads and events management.
- OS_Utilities.c
    General OS agnostic utilities  (they are OS agnostic because of the use of the SDK or the HMS 'C' API).
- OS_UtilitiesWin32.c
    Windows specific file i/o and other utilities
- OS_UtilitiesLinux.c
    Linux specific file i/o and other utilities
- Utilities
    Contains multiple utility functions.
- SDK_ExtensionUtilities.c
    Implementation file for various ThingWorx 'C' SDK extenion functions 
    !!! code is subject to change per SDK API release.  !!!

- TarGzip.c
  Utility to list and extract the content of a tar.gz archive file.

**** Important Header Files ****
- AgentConfig.h
    General purpose application header that is normally the 1st include in all source files.

- GeneralDefines.
- GeneralStringDefines.h
    Central place for defining strings and other constants, including constants when reading JSON files.

**** Temporary Files to support an early release of ThingWorx Utilities Software Content Management. ****
When an official SDK that interfaces with SCM is release these files will need to be removed andn
the SCM_Task.c file modified to work with the new SDK interfaces. 
- twSwUpdateManager.c
- twSwUpdateJob.c

**** Preprocessor Definitions ****
CMake defines a set of preprocessor definitions. The ELGiAgent uses the following preprocessor definitions:
•	AGENT_VERSION=<tbd>"
•	AGENT_NAME="ELGiAgent"
•	PROJECT_NAME="ELGiAgent"
The C-SDK uses the following preprocessor definitions:
•	ENABLE_FILE_XFER=1
•	OFFLINE_MSG_STORE=2
•	C_SDK_VERSION="<tbd> "
•	TW_TLS_INCLUDE="twOpenSSL.h"
•	TW_OS_INCLUDE="twWindows-openssl.h"
•	ENABLE_TUNNELING
•	ENABLE_FILE_XFER
•	IGNORE_UNSTABLE_TESTS=1
•	ENABLE_FIPS_MODE=1
The for backwards compatibility for the Microsoft compiler, the following are defined:
•	_CRT_SECURE_NO_DEPRECATE
•	_CRT_SECURE_NO_WARNINGS
•	_CRT_NONSTDC_NO_DEPRECATE

******************************************************************************/
#if defined(LEGATO)
#include "legato.h"
#endif

#include "AgentConfig.h"
#include "ExtDataConnection.h"
#include "configParams.h"
#include "cJSON.h"
#include "Initialization.h"
#include "Shutdown.h"

// The thing identifier is destignated as an identifier by the leading '*'.
// In the 'C-SDK' the identifier is the 'thing name'.
char *g_pszThingIdentifier = NULL; /* Remote Thing Identifier */
char *g_pszRegistrationThingName = NULL;
char *g_pszRegistrationServiceName = NULL;
char *g_pszRemoteThingName = NULL; /* Remote Thing Name (available upon first registration) */
char *g_pszProcessName = NULL;     // This is the name of the process
char *g_pszFabNumber = NULL;
char *g_pszImeiNumber = NULL;
GS_BOOL g_bFabNumberValid = FALSE;
GS_BOOL g_bDaemon = FALSE;
GS_BOOL g_bFirstTimeBoundComplete = FALSE;
GS_BOOL g_bFirstTimeCallbacksSetup = FALSE;

/*Configuring default values for system wide variables */
GS_BOOL g_bReceivedShutdownSignal = FALSE; /* Variable indiacting the status of shutdown signal */
GS_BOOL g_bPublishDataDuringFileTransfer = FALSE;
int g_publishMessageTimeout = -1;
GS_BOOL g_bEnableErrorEvents = FALSE;
GS_BOOL g_bRestartApplication = FALSE;
GS_BOOL g_bDisableWebSocketCompression = FALSE;              /*Disable the compression while communicating to platform */
GS_BOOL g_bServerHandshakingInitializationCompleted = FALSE; // currently only used at 1st time initialization.

// function prototypes
int InitAndStart();

// ProcessProgramArguments return:
//   1 - successfully registered or unregistered as a service
//   0 - No input parameters
//  -1 - invalid parameter
//  -2 - failed to register.
int ProcessProgramArguments(int argc, char **argv);

//****************************************************************************
#if defined(LEGATO)
COMPONENT_INIT
#else
int main(int argc, char **argv)
#endif // LEGATO
{
    // For consistency between Windows and Linux, override the SDK's mutex implementation.
    OverrideSDKCreateMutex();
    // Logger must be initialized 1st.
    // This does not load any configuration files nor does create additional folders.
    GsLog_InitializeDefaults();
#if defined(LEGATO)
    ExtDataConnection_Initialize();
    twSleepMsec(5000);
#else
    g_bIsWaitingForConnection = FALSE;
    int rc = ProcessProgramArguments(argc, argv);
    if (rc != 0)
        return rc;
#endif // LEGATO
#if defined(LINUX)
    if (g_bDaemon)
    {
        // This is helper function from unistd header
        daemon(1, 0);
    }
#endif // LINUX
    InitAndStart();
} //> main()

//****************************************************************************
/*
Windows executable input parameters:
   -register [service name]. 
        Description:  This registers the application to run as a Windows Service.  
            The optional [service name] is the name of the Windows Service.
            If the service name is not provided, the default name is:  ThingWorxAgent.
            The Service is registered with the startup type set to 'Automatic'.

   -unregister [service name]\n"
        Description:  This unregisters the application from running as a Windows Service.  
            The optional [service name] is the name of the Windows Service.
            If the service name is not provided, the default name is:  ThingWorx Agent.
Linux executable input parameters:
  -D  This indicates the application is to be run as a daemon.
*/
// return:
//   1 - successfully registered or unregistered as a service
//   0 - No input parameters
//  -1 - invalid parameter
//  -2 - failed to register.
int ProcessProgramArguments(int argc, char **argv)
{
    int i = 1;
    int rc = 0; // assume no input arguments.
    // there are only 2 input arguements plus the process name as agrg 0.

    // Save process name.
    g_pszProcessName = GsConvertPath(argv[0]);

    while (i < argc)
    {
        GS_BOOL bOptArg = (i < (argc - 1)) && (argv[i + 1][0] != '-');
        char *pszArg = argv[i];

#if defined(WIN32)
        if (strcmp(pszArg, "-home") == 0)
        {
            rc = SetAgentHomeDir(bOptArg ? argv[++i] : NULL);
        }
        else
        {
            printf("inputs:\n  -register [service name]\n  -unregister [service name]\n  -home [agent home directory]\n");
            return -1;
        }
#elif defined(LINUX)
        if (strcmp(pszArg, "-D") == 0)
        {
            // run as a daemon
            g_bDaemon = TRUE;
        }
        else if (strcmp(pszArg, "-home") == 0)
        {
            rc = SetAgentHomeDir(bOptArg ? argv[++i] : NULL);
        }
        else
        {
            printf("Available options:\n  -D    run as a daemon\n  -home [agent home directory]\n");
            return -1;
        }
#endif
        i++;
    } // while
    return rc;
} //> ProcessProgramArguments(...)

static unsigned int g_initThreadWaitMs = 5000;
static DATETIME g_initThreadWakeupTime = 0;
static GsThreadStruct *g_pInitThreadStruct = NULL;

void InitThreadMgr_Shutdown()
{
    if (g_pInitThreadStruct != NULL)
    {
        // stop DataSim data acquisition and clean up memory.
        GsAppLog(GS_TRACE, MODULE_GS_DATA, "InitThread:  Initiate shutdown");
        GsStopThread(g_pInitThreadStruct);
        GsDestroyThreadStruct(g_pInitThreadStruct);

        GsAppLog(GS_TRACE, MODULE_GS_RUNTIME, "InitThread:  shutdown complete");
    }
} //> InitThreadMgr_Shutdown()

THREAD_FUNCTION_RETURN InitThreadFunction(void *pVoid)
{
#if defined(LEGATO)
    le_thread_InitLegatoThreadData("InitThread");
    int seedIx = 0;
    int waitReturnCondition = WAIT_OBJECT_0;
    GsThreadStruct *pGsThreadStruct = (GsThreadStruct *)pVoid; // The void* parameter is always the thread struct pointer
    GsAppLog(GS_FORCE, MODULE_GS_DATA, "InitThread:  Initialization is enabled.");
    if (!pGsThreadStruct)
    {
        GsAppLog(GS_ERROR, MODULE_GS_DATA, "InitThread:  Thread initialiation error.  Exiting thread.");
        return (THREAD_FUNCTION_RETURN)-1;
    }
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "InitThread:  Thread started.  Thread id = %x (hex)", pGsThreadStruct->m_threadId);
    // while bRunning, continues to run
    while (pGsThreadStruct->m_bRunning)
    {
        unsigned long loopTime = 0;
        unsigned long waitTime = 0; // init to no wait.
        // Wait for signal or timeout for the next acquisition scan.
        waitReturnCondition = GsThreadWaitForRunCycle(pGsThreadStruct);
        GsAppLog(GS_TRACE, MODULE_GS_DATA, "InitThread: %s running(%s)",
                 (waitReturnCondition == WAIT_OBJECT_0 ? "Signal received." : "Thread wakup due to timeout."),
                 (pGsThreadStruct->m_bRunning ? "true" : "false"));
        if (!pGsThreadStruct->m_bRunning || g_bReceivedShutdownSignal)
            break;
        g_initThreadWakeupTime = twGetSystemTime(TRUE);
        if (!g_bIsWaitingForConnection && g_bFabNumberValid)
        {
            pGsThreadStruct->m_bRunning = FALSE;
        }
        else if (g_bIsWaitingForConnection)
        {
            GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Still waiting for the connection state... sleeping for 5s.", "Connectivity");
        }
        if (!g_bFabNumberValid)
        {
            GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Still waiting for the correct Fab Number... ", "Initialization");
            ExtDataAcquisition_FetchFabNumber();
        }
        // calculate the total time within the acquisition loop.
        loopTime = (unsigned long)(twGetSystemTime(TRUE) - g_initThreadWakeupTime);
        if (loopTime < g_initThreadWaitMs)
            waitTime = g_initThreadWaitMs - loopTime;
        g_pInitThreadStruct->m_waitMilliSec = waitTime;
    }  //? is thread running
#endif // LEGATO
    if (!g_bReceivedShutdownSignal)
    {
        /* Normal system initialization - without blocking */
        int err = Initialize();
        if (err != TW_OK)
        {
            // give time for a human to read the error message before exiting.
            GsWaitForShutdownEvent(15000);
            exit(0);
        }
    }
    if (!g_bReceivedShutdownSignal)
    {
        /* Start the system.  Connection to the Server must be established in Start. */
        int err = Start();
        if (err != TW_OK)
        {
            exit(0);
        }
    }
    // This main thread now waits for a Control-C or Sigterm or a restart from the Server / SCM.
    if (!g_bReceivedShutdownSignal)
        GsWaitForShutdownSignal();
    // do a clean shutdown
    Shutdown();
    InitThreadMgr_Shutdown();
    TW_FREE(g_pszProcessName);
#if defined(_CRTDBG_MAP_ALLOC)
    // Show memory leaks.
    // For more information on finding memory leaks using Visual Studio,
    // see:  https://msdn.microsoft.com/en-us/library/x98tx3cf.aspx
    _CrtDumpMemoryLeaks();
#endif
    GsAppLog(GS_DEBUG, MODULE_GS_DATA, "InitThread:  extiting thread");
#if defined(LEGATO)
    le_thread_CleanupLegatoThreadData();
#endif // LEGATO
    return 0;
} //> InitThreadFunction(...)

/******************************************************************************
Function to kick-off the Agent initialize and start.
*******************************************************************************/
int InitAndStart()
{
#if 0
#if defined(LEGATO)
//    while (g_bIsWaitingForConnection)
//    {
//        GsAppLog(GS_INFO, MODULE_GS_CONFIG, "%s: Still waiting for the connection state... sleeping for 5s.", "Connectivity");
//        twSleepMsec(5000);
//    }
#endif // LEGATO

    /* System initialization */
    int err = Initialize();
    if (err != TW_OK)
    {
        // give time for a human to read the error message before exiting.
        GsWaitForShutdownEvent(15000);
        exit(0);
    }
    /* Start the system.  Connection to the Server must be established in Start. */
    err = Start();
    if (err != TW_OK)
    {
        exit(0);
    }
#endif
    /*
     * Pre initialization - without blocking
     * This is to just load configuration files, initialize 
     * data acquisition configs - but not trigger any kind 
     * of threads or loops. This is required to call any 
     * legato specific APIs that are hooked to the main 
     * API thread (when component initializes) 
     */
    int err = PreInitialize();
    if (err != TW_OK)
    {
        exit(0);
    }
#if defined(LEGATO)
    // Create thread structure
    g_pInitThreadStruct = GsCreateThreadStruct();
    // wait before starting 1st acquisition.
    g_pInitThreadStruct->m_waitMilliSec = 2500;

    // start the thread
    GsAppLog(GS_TRACE, MODULE_GS_DATA, "InitThread: Initiate start of thread");
    GsStartThread(g_pInitThreadStruct, InitThreadFunction);
#else
    // LINUX / WINDOWS
    // Just call this without thread to block it!
    InitThreadFunction(NULL);
#endif // LEGATO

    return 0;
} //> InitAndStart()
