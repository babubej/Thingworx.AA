//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  OS_Utilities.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:  OS abstraction implementation layer for various support (utility) functions.
//                These functions only use the 'C' run-time library and are
//                already cross-platform compatible ... OR call the OS abstration layer.
//                For OS specific implementation see:  OS_UtilitiesWin32.c and
//                OS_UtilitiesLinux.c
//
//                Most functions provide helpful File I/O or time functionality.
//
//*****************************************************************************

#include "twApi.h"
#include "AgentConfig.h"
#include "Utilities.h"
#include "OS_Utilities.h"

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

//*****************************************************************************
// GsReadFileContent
//  - input:  Filename of file to be read.
//  - return:  pointer to memory holding the content of the entire file.
// caller is responsible to free the memory returned by GsGetCwd****************/
// ****************************************************************************
char *GsReadFileContent(char *fileName)
{
	char *data = NULL;
	long len = 0;
	FILE *fd = TW_FOPEN(fileName, "rb");
	if (!fd)
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "GsReadFileContent():Error opening the file: '%s'.", fileName);
		return data;
	}
	TW_FSEEK(fd, 0, SEEK_END);
	len = (long)TW_FTELL(fd);
	TW_FSEEK(fd, 0, SEEK_SET);
	data = (char *)TW_MALLOC(len + 1);
	memset(data, 0, len + 1);
	TW_FREAD(data, 1, len, fd);
	TW_FCLOSE(fd);
	return data;
}

int GsWriteFileContent(char *fileName, const char *fileContent)
{
	if (!fileName || !fileContent)
	{
		return GS_FAILED;
	}
	long len = 0;
	FILE *fd = TW_FOPEN(fileName, "w+");
	if (!fd)
	{
		GsAppLog(GS_ERROR, MODULE_GS_CONFIG, "GsWriteFileContent():Error opening the file: '%s'.", fileName);
		return GS_FAILED;
	}
	TW_FSEEK(fd, 0, SEEK_SET);
	TW_FWRITE(fileContent, 1, strlen(fileContent), fd);
	TW_FCLOSE(fd);
	return GS_OK;
}

//*****************************************************************************
//
// GetLocalTime()
//					It returns the system's local time based on seconds.
//
//*****************************************************************************
GS_BOOL GsGetLocalTime(struct tm *pLocal)
{
	time_t seconds = GsGetSecondsSince1970();
	if (pLocal)
	{
		struct tm *ptm = localtime(&seconds);
		if (ptm)
		{
			*pLocal = *ptm;
			return TRUE;
		}
	}
	return FALSE;
}

//*****************************************************************************
//
// GsGetSecondsSince1970()
//	returns a time_t in Epoch time.
//
//*****************************************************************************
time_t GsGetSecondsSince1970()
{
	DATETIME dateTime = twGetSystemTime(1);
	return (time_t)(dateTime / 1000);
}

//*****************************************************************************
int GsGetYear()
{
	struct tm localTime;
	GsGetLocalTime(&localTime);
	return localTime.tm_year + 1900;
}

//*****************************************************************************
// Get file extension
char *GsGetFileExtension(char *pszFilename)
{
	char *pExtension = NULL;
	int iLast;

	if (pszFilename == NULL || strlen(pszFilename) == 0)
		return NULL;

	iLast = (int)strlen(pszFilename) - 1;
	while (iLast >= 0)
	{
		if (pszFilename[iLast] == '\\' || pszFilename[iLast] == '/')
			return pExtension;

		// Per shilpa code logic, this function returns on the last dot
		if (pszFilename[iLast] == '.')
		{
			pExtension = pszFilename + iLast;
			return pExtension;
		}
		iLast--;
	}

	return pExtension;
}

//*****************************************************************************
// Get the path portion of the full-path file name. Caller owns the memory
// Path must have been converted per OS already
char *GsGetPathPortion(char *pszFullPathFile)
{
	char *pPath = NULL;
	int iLen = (int)strlen(pszFullPathFile);

	// look for the directory delimiter
	while (iLen > 0 && pszFullPathFile[iLen - 1] != TW_FILE_DELIM)
		iLen--;

	if (iLen == 0)
		return pPath;

	pPath = (char *)TW_MALLOC(strlen(pszFullPathFile) + 1);
	if (pPath)
	{
		strcpy(pPath, pszFullPathFile);
		pPath[iLen - 1] = 0;
	}

	return pPath;
}

//*****************************************************************************
// Get the file name portion of the full-path file name. Caller owns the memory
// Path must have been converted per OS already
char *GsGetFileNamePortion(char *pszFullPathFile)
{
	char *pStart;
	char *pFile = (char *)TW_MALLOC(strlen(pszFullPathFile) + 1);

	if (pFile)
	{
		pStart = strrchr(pszFullPathFile, TW_FILE_DELIM);
		if (pStart)
			strcpy(pFile, pStart + 1);
		else
			strcpy(pFile, pszFullPathFile);
	}

	return pFile;
}

//*****************************************************************************
// Recursively delete all contents of a directory. !!! Be careful !!!
// return 0 if successful, otherwise error code
int GsDeleteDirectoryRecursive(char *pszDirectory)
{
	int error = 0;
	int iLast;
	intptr_t hFile;
	struct _finddata32_t fileData;
	char SearchSpec[PATH_MAX];
	char SubDir[PATH_MAX];

	if (pszDirectory == NULL || strlen(pszDirectory) == 0)
		return GS_INVALID_PARAMS;

	GsAppLog(GS_DEBUG, MODULE_GS_CONFIG, "Deleting directory %s with all its contents!", pszDirectory);

	strcpy(SearchSpec, pszDirectory);
	iLast = (int)strlen(pszDirectory) - 1;
	if (pszDirectory[iLast] != TW_FILE_DELIM)
		strcat(SearchSpec, TW_FILE_DELIM_STR);
	strcat(SearchSpec, "*");

	memset(&fileData, 0, sizeof(fileData));
	hFile = GsFindFirst(SearchSpec, &fileData);
	while ((error == 0) && (hFile != -1))
	{
		// skip the "." and ".." entries
		if (strcmp(fileData.name, ".") && strcmp(fileData.name, ".."))
		{
			strcpy(SubDir, pszDirectory);
			if (pszDirectory[iLast] != TW_FILE_DELIM)
				strcat(SubDir, TW_FILE_DELIM_STR);
			strcat(SubDir, fileData.name);

			// recurse if directory, or just delete file
			if (fileData.attrib & FILE_ATTRIBUTE_DIRECTORY)
				error = GsDeleteDirectoryRecursive(SubDir);
			else
				error = twDirectory_DeleteFile(SubDir);
		}

		if (GsFindNext(hFile, &fileData) != 0)
			break;
	}

	if (hFile != -1)
		GsFindClose(hFile);

	if (error == 0)
		error = twDirectory_DeleteDirectory(pszDirectory);

	return error;
}

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************
