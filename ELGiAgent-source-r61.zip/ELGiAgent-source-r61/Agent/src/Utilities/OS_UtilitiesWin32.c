//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  OS_UtilitiesWin32.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:  OS abstraction layer for various support (utility) functions.
//                Windows implementation.
//
//*****************************************************************************

#include "twApi.h"
#include "AgentConfig.h"
#include "Utilities.h"
#include "OS_Utilities.h"

#include <io.h>

// local proptotypes
BOOL CtrlHandler(DWORD fdwCtrlType);

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

/*****************************************************************************
// GsGetCwd()
//  - returns char* to the current working directory.
// caller is responsible to free the memory returned by GsGetCwd****************/
char *GsGetCwd()
{
	// Get current working directory, copy into allocated string.
	char *pszCWD = NULL;
	int len = MAX_PATH + 1;
	char szBuffer[MAX_PATH + 1];
	memset(szBuffer, 0, len);
	GetCurrentDirectoryA(len, szBuffer);
	pszCWD = (char *)TW_MALLOC(strlen(szBuffer) + 1);
	strcpy(pszCWD, szBuffer);
	return pszCWD;
}

//*****************************************************************************
GS_BOOL GsSetCwd(const char *pszCwd)
{
	// 0 ok / -1 fail
	return SetCurrentDirectoryA(pszCwd);
}

//*****************************************************************************
char *GsGetEnvironmentVariable(const char *variableName)
{
	char *pszBuffer;
	size_t returnSize = 0;
	if (variableName == NULL || strlen(variableName) == 0)
		return NULL;
	pszBuffer = (char *)TW_MALLOC(MAX_PATH);
	memset(pszBuffer, 0, MAX_PATH);
	if (!GetEnvironmentVariableA(variableName, pszBuffer, MAX_PATH))
	{
		TW_FREE(pszBuffer); // free memory
		pszBuffer = NULL;
	}
	//(getenv_s(&returnSize, pszBuffer, MAX_PATH, variableName) != 0);
	return pszBuffer;
}

//*****************************************************************************
unsigned long GsGetCurrentProcessId(void)
{
	// Can also use _getpid() from process header
	return GetCurrentProcessId();
}

//*****************************************************************************
// Install the OS shutdown signal handler
void GsInstallOSShutdownSignalHandler()
{
	// Install Windows 'CTRL_C' event handler.
	SetConsoleCtrlHandler((PHANDLER_ROUTINE)CtrlHandler, TRUE);
}

//*****************************************************************************
unsigned long GsExecuteProgram(char *szFile, char *pszArgs, unsigned long *pExitCode, GS_BOOL bWait, unsigned long maxWaitDelay)
{
	unsigned long retCode = TW_OK;
	STARTUPINFOA si;
	PROCESS_INFORMATION pi;
	char CommandAndArgs[512];

	// Format: "program-name program-args"
	strcpy(CommandAndArgs, szFile);
	if (pszArgs)
	{
		strcat(CommandAndArgs, " ");
		strcat(CommandAndArgs, pszArgs);
	}
	memset(&si, 0, sizeof(si));
	memset(&pi, 0, sizeof(pi));
	si.cb = sizeof(si);
	si.dwFlags = 0;
	if (CreateProcessA(NULL, CommandAndArgs, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
	{
		DWORD dwChildExitCode = 0;
		// wait for finish
		if (bWait)
			WaitForSingleObject(pi.hProcess, maxWaitDelay);
		// Get return value from executable.
		if (!GetExitCodeProcess(pi.hProcess, &dwChildExitCode))
			retCode = GetLastError();
		// Update the exit code variable if available. This function will return TW_OK,
		// even if exit code indicates an error.
		if (pExitCode)
			*pExitCode = (unsigned long)dwChildExitCode;
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);
	}
	else
		retCode = GetLastError(); // Update the return code to show that executing the process was unsuccessful.
	//LPWSTR pBuffer = NULL;
	//FormatMessage(FORMAT_MESSAGE_FROM_STRING | FORMAT_MESSAGE_ALLOCATE_BUFFER,
	//			  pMessage, 0, 0, (LPWSTR)&pBuffer);
	//LocalFree(pBuffer);
	return retCode;
}

//*****************************************************************************
char *GsReadLineFromFile(char *buffer, int size, FILE *hFile)
{
	return fgets(buffer, size, hFile);
}

//*****************************************************************************
// Convert path delimiter (slash vs. back-slash).
char *GsConvertPath(char *pPath)
{
	// convert slash to back-slash and a drive letter
	char exeName[MAX_PATH];
	int i = 0;
	int iLen = (int)strlen(pPath);

	char *pReturn = (char *)TW_MALLOC(iLen + 8);
	if (pReturn)
	{
		memset(pReturn, 0, iLen + 8);
		if (pPath[0] == '/' || pPath[0] == '\\')
		{
			// add drive letter
			if (GetModuleFileNameA(NULL, exeName, MAX_PATH) > 0)
				pReturn[0] = exeName[0];
			else
				pReturn[0] = 'C';
			pReturn[1] = ':';
		}
		strcat(pReturn, pPath);

		iLen = (int)strlen(pReturn);
		for (i = 0; i < iLen; i++)
		{
			if (pReturn[i] == '/')
				pReturn[i] = '\\';
		}
	}
	return pReturn;
}

//*****************************************************************************
// pPath is File. delimiter has been converted per platform
GS_BOOL GsCreateFolderForFile(char *pFile)
{
	// strip off the file name
	GS_BOOL b = FALSE;
	int i;
	char save;
	int iLen = (int)strlen(pFile);

	for (i = iLen - 1; i > 0; i--)
	{
		if (pFile[i] == '\\')
		{
			save = pFile[i + 1];
			pFile[i + 1] = 0; // keep the back slash
			b = GsCreateFolderRecursive(pFile);
			pFile[i + 1] = save;
			break;
		}
	}

	return b;
}

//*****************************************************************************
// pPath is folder. delimiter has been converted per platform
GS_BOOL GsCreateFolderRecursive(char *pPath)
{
	// directories have to be created one by one.
	// Caller should make sure that pPath ends with '\\'
	int i;
	DWORD attr;
	int iLen = (int)strlen(pPath);
	for (i = 0; i < iLen; i++)
	{
		if (pPath[i] == '\\')
		{
			pPath[i] = 0;
			CreateDirectoryA(pPath, NULL);
			pPath[i] = '\\';
		}
	}

	attr = GetFileAttributesA(pPath);
	return attr != (DWORD)-1;
}

//*****************************************************************************
GS_BOOL GsDeleteFile(char *pFile)
{
	return DeleteFileA(pFile);
}

//*****************************************************************************
GS_BOOL GsRenameFile(char *pSourceFile, char *pTargetFile)
{
	return MoveFileA(pSourceFile, pTargetFile);
}

//*****************************************************************************
// convert ascii string to an long long
uint64_t GsAsciiToLongLong(char *pszString)
{
	return _atoi64(pszString);
}

//*****************************************************************************
// open a file
int Gsopen(char *pathname, int oflags, int mode)
{
	return _open(pathname, oflags, mode);
}

//*****************************************************************************
// FindFirst, Findnext, FindClose utility function
intptr_t GsFindFirst(char *filespec, struct _finddata32_t *fileinfo)
{
	return _findfirst32(filespec, fileinfo);
}

/*****************************************************************************/
int GsFindNext(intptr_t handle, struct _finddata32_t *fileinfo)
{
	return _findnext32(handle, fileinfo);
}

/*****************************************************************************/
int GsFindClose(intptr_t handle)
{
	return _findclose(handle);
}

/*****************************************************************************/
int GsSetFilePermissionRWX(char *pszFileName)
{
	return 0;
}

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

//*****************************************************************************
BOOL CtrlHandler(DWORD fdwCtrlType)
{
	switch (fdwCtrlType)
	{
		// Handle the CTRL-C signal.
	case CTRL_C_EVENT:
	case CTRL_SHUTDOWN_EVENT:
		GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Received OS shutdown signal");
		GsShutdownApplication(FALSE);
		return (TRUE);
	default:
		return FALSE;
	}
}
