//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  OS_UtilitiesLinux.c
//
//  Subsystem  :  EDS_Agent
//
//  Description:  OS abstraction layer for various support (utility) functions.
//                Linux implementation
//
//*****************************************************************************

#include "twApi.h"
#include "AgentConfig.h"
#include "Utilities.h"
#include "OS_Utilities.h"

#include <stdlib.h>
#include <unistd.h>
#include <string.h>

//
// signal handlers for unix.
//
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>

// internal helpers
int MatchShellExpression(char *str, char *shexp);
void OnShutdownSignal(int i);

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

//*****************************************************************************
// GsGetCwd()
//  - returns char* to the current working directory.
// caller is responsible to free the memory returned by GsGetCwd
char *GsGetCwd()
{
    // Get current working directory, copy into allocated string.
    char *pszCWD = NULL;
    int len = PATH_MAX + 1;
    char szBuffer[PATH_MAX + 1];
    memset(szBuffer, 0, len);
    getcwd(szBuffer, len);
    pszCWD = (char *)TW_MALLOC(strlen(szBuffer) + 1);
    strcpy(pszCWD, szBuffer);
    return pszCWD;
}

//*****************************************************************************
GS_BOOL GsSetCwd(const char *pszCwd)
{
    // 0 ok / -1 fail
    return chdir(pszCwd) != -1;
}

//*****************************************************************************
char *GsGetEnvironmentVariable(const char *variableName)
{
    char *pszBuffer = NULL;
    if (variableName == NULL || strlen(variableName) == 0)
        return NULL;
    char *pszValue = secure_getenv(variableName);
    size_t length = 0;
    if (pszValue != NULL)
    {
        length = strlen(pszValue);
        pszBuffer = (char *)TW_MALLOC(length + 1);
        memset(pszBuffer, 0, length + 1);
        strncpy(pszBuffer, pszValue, length);
    }
    return pszBuffer;
}

//*****************************************************************************
unsigned long GsGetCurrentProcessId(void)
{
    return getpid();
}

//*****************************************************************************
// Install the OS shutdown signal handler
void GsInstallOSShutdownSignalHandler()
{
    // Install Linux signal handler
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;

    sa.sa_handler = OnShutdownSignal;
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);
}

//*****************************************************************************
// Execute a bat file (Windows) or shell scripts (Linux)
unsigned long GsExecuteProgram(char *szFile, char *params, unsigned long *pExitCode, GS_BOOL bWait, unsigned long maxWaitDelay)
{
    char *argv[32];
    int exitCode = 0;
    int count = 0, status = 0;
    int pipefds[2];
    int i, j;
    pid_t childPid, sid;

    // Self-pipe trick (needed to determine if execvp() failed).
    // https://stackoverflow.com/questions/1584956/how-to-handle-execvp-errors-after-fork
    if (pipe(pipefds))
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "GsExecuteProgram: pipe(): %s", strerror(errno));
        return errno;
    }
    if (fcntl(pipefds[1], F_SETFD, fcntl(pipefds[1], F_GETFD) | FD_CLOEXEC))
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "GsExecuteProgram: fcntl(): %s", strerror(errno));
        return errno;
    }
    childPid = fork();
    switch (childPid)
    {
    // Error occurred while forking
    case -1:
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "GsExecuteProgram: fork(): %s", strerror(errno));
        return errno;
    // Child process entry point
    case 0:
        close(pipefds[0]);
        // close all decriptors except standard IO
        i = 3;
        for (; i < 1024; i++)
        {
            if (i != pipefds[1])
                close(i); // do not close the pipe
        }
        if (!bWait)
        {
            // The parent process won't wait for this child process
            // Child process should detach from it!
            sid = setsid();
            if (sid < 0)
                GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "GsExecuteProgram: setsid(): %s", strerror(status));
        }
        // parse agruments
        memset(argv, 0, 32);
        argv[0] = szFile;
        if (params && params[0] != 0)
        {
            i = 2;
            j = 0;
            argv[1] = params;
            while (params[j] && i < 31)
            {
                if (params[j] == ' ')
                {
                    params[j] = 0x0;
                    j++;
                    argv[i] = params + j;
                    i++;
                }
                else
                {
                    j++;
                }
            }
            argv[i] = NULL;
        }
        execvp(szFile, argv); // execvp() does not return on success.
        // At this point the execvp() has failed - store the error code.
        status = errno;
        // Write the return code to the pipe. The fact that it was written into means that execvp() failed.
        write(pipefds[1], &status, sizeof(int));
        // Without creating pipes it would be necessary to return errno via _exit().
        // This would make it difficult to determine in the parent process if the errno level
        // (higher than 0) is coming from the process that was executed or the execvp() failure.
        _exit(0);
    // Parent process entry point.
    default:
        close(pipefds[1]);
        // Read the exit code (if any) from the pipe - this is to determine failure in execution,
        // for example because of missing file/bad path (ENOENT).
        while ((count = read(pipefds[0], &status, sizeof(int))) == -1)
            if (errno != EAGAIN && errno != EINTR)
                break;
        if (count)
        {
            GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "GsExecuteProgram: execvp(%s): %s", szFile, strerror(status));
            return TW_UNKNOWN_ERROR;
        }
        close(pipefds[0]);
        // When not waiting for the process to finish, just return directly the status (if any).
        if (!bWait)
            return TW_OK;
        while (waitpid(childPid, &status, 0) == -1)
        {
            if (errno != EINTR)
            {
                GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "GsExecuteProgram: waitpid(): %s", strerror(errno));
                return errno;
            }
        }
        if (WIFEXITED(status))
        {
            // The child process had exited normally with error code defined.
            exitCode = WEXITSTATUS(status);
            if (pExitCode)
                *pExitCode = (unsigned long)exitCode;
        }
        else if (WIFSIGNALED(status))
        {
            // Child was killed/signaled off by another process.
            return TW_UNKNOWN_ERROR;
        }
    } // switch(childPid)
    // The execution of the specified process was successful.
    return TW_OK;
}

//*****************************************************************************
char *GsReadLineFromFile(char *buffer, int size, FILE *hFile)
{
    return fgets(buffer, size, hFile);
}

//*****************************************************************************
// Convert path delimiter (slash vs. back-slash)
char *GsConvertPath(char *pPath)
{
    // convert back-slash to slash
    int i = 0;
    int iLen = strlen(pPath);
    char *pReturn = TW_MALLOC(iLen + 8);
    if (pReturn)
    {
        if (pPath[0] >= 'a' && pPath[0] <= 'z' || pPath[0] >= 'A' && pPath[0] <= 'Z')
        {
            if (pPath[1] == ':')
            {
                if (pPath[2] == '/' || pPath[2] == '\\')
                    i = 2;
            }
        }
        strcpy(pReturn, pPath + i);

        iLen = strlen(pReturn);
        for (i = 0; i < iLen; i++)
        {
            if (pReturn[i] == '\\')
                pReturn[i] = '/';
        }
    }

    return pReturn;
}

//*****************************************************************************
// pPath is File. delimiter has been converted per platform
GS_BOOL GsCreateFolderForFile(char *pFile)
{
    // strip off the file name
    GS_BOOL b = FALSE;
    int i;
    char save;
    int iLen = strlen(pFile);

    for (i = iLen - 1; i > 0; i--)
    {
        if (pFile[i] == '/')
        {
            save = pFile[i + 1];
            pFile[i + 1] = 0; // keep the slash
            b = GsCreateFolderRecursive(pFile);
            pFile[i + 1] = save;
            break;
        }
    }

    return b;
}

//*****************************************************************************
// pPath is folder. delimiter has been converted per platform
GS_BOOL GsCreateFolderRecursive(char *pPath)
{
    // directories have to be created one by one.
    // Caller should make sure that pPath ends with '/'
    struct stat sbuf;
    int iLen = strlen(pPath);
    int i;
    for (i = 0; i < iLen; i++)
    {
        if (pPath[i] == '/')
        {
            pPath[i] = 0;
            mkdir(pPath, 0777);
            pPath[i] = '/';
        }
    }
    return (stat(pPath, &sbuf) == 0);
}

//*****************************************************************************
// pFile is file name
GS_BOOL GsDeleteFile(char *pFile)
{
    return (unlink(pFile) == 0);
}

//*****************************************************************************
// pSourceFile is old file name. pTargetFile is new file name
GS_BOOL GsRenameFile(char *pSourceFile, char *pTargetFile)
{
    return (rename(pSourceFile, pTargetFile) == 0);
}

//*****************************************************************************
// convert ascii string to an long long
uint64_t GsAsciiToLongLong(char *pszString)
{
    return atoll(pszString);
}

//*****************************************************************************
// open a file
int Gsopen(char *pathname, int oflags, int mode)
{
    oflags |= O_LARGEFILE;
    return open(pathname, oflags, mode);
}

//*****************************************************************************
// FindFirst, Findnext, FindClose utility functions
intptr_t GsFindFirst(char *filespec, struct _finddata32_t *fileinfo)
{
    char *pPathDelim;
    char *pPattern;
    int res = 0;
    int iLen;

    // check filespec
    if (fileinfo == NULL || filespec == NULL || strlen(filespec) == 0 || strlen(filespec) > PATH_MAX)
        return -1;

    iLen = strlen(filespec);
    struct FIND_FILE_INFO *pFindFileInfo = (struct FIND_FILE_INFO *)TW_MALLOC(sizeof(struct FIND_FILE_INFO));
    if (!pFindFileInfo)
        return -1;

    memset(fileinfo, 0, sizeof(struct _finddata32_t));

    pFindFileInfo->m_pFilePath = TW_MALLOC(iLen + 1);
    pFindFileInfo->m_pFilePattern = TW_MALLOC(iLen + 1);
    pFindFileInfo->m_pDir = NULL;
    if (pFindFileInfo->m_pFilePath == NULL || pFindFileInfo->m_pFilePattern == NULL)
    {
        if (pFindFileInfo->m_pFilePath)
            TW_FREE(pFindFileInfo->m_pFilePath);
        if (pFindFileInfo->m_pFilePattern)
            TW_FREE(pFindFileInfo->m_pFilePattern);
        return -1;
    }

    // set up path and pattern
    pPathDelim = strrchr(filespec, TW_FILE_DELIM);
    if (pPathDelim)
    {
        strcpy(pFindFileInfo->m_pFilePath, filespec);
        pFindFileInfo->m_pFilePath[pPathDelim - filespec + 1] = 0; // retain the "/"
        pPattern = pPathDelim + 1;
    }
    else
    {
        strcpy(pFindFileInfo->m_pFilePath, "./");
        pPattern = filespec;
    }
    strcpy(pFindFileInfo->m_pFilePattern, pPattern);

    // open the directory, then call FindNext
    if (pFindFileInfo->m_pDir = opendir(pFindFileInfo->m_pFilePath))
        res = GsFindNext((intptr_t)pFindFileInfo, fileinfo);

    // return handle to caller
    if (pFindFileInfo->m_pDir && res == 0)
        return (intptr_t)pFindFileInfo;
    else
    {
        // clean up
        TW_FREE(pFindFileInfo->m_pFilePath);
        TW_FREE(pFindFileInfo->m_pFilePattern);
        if (pFindFileInfo->m_pDir)
            closedir(pFindFileInfo->m_pDir);

        TW_FREE(pFindFileInfo);
        return -1;
    }
}

//*****************************************************************************
int GsFindNext(intptr_t handle, struct _finddata32_t *fileinfo)
{
    char fileName[PATH_MAX];
    struct dirent entBuf;
    struct dirent *entBufPtr = &entBuf;
    struct dirent *ent;
    struct stat statBuf;
    int iLast;
    struct FIND_FILE_INFO *pFindFileInfo = (struct FIND_FILE_INFO *)handle;

    if (pFindFileInfo == NULL || fileinfo == NULL)
        return -1;

    memset(fileinfo, 0, sizeof(struct _finddata32_t));

    if (pFindFileInfo == NULL)
        return -1;

    // read the directory until a match, or end of reading
    while (readdir_r(pFindFileInfo->m_pDir, entBufPtr, &ent) == 0 && ent != NULL)
    {
        if (strcmp(ent->d_name, ".") == 0)
            continue;

        if (strcmp(ent->d_name, "..") == 0)
            continue;

        if (MatchShellExpression(ent->d_name, pFindFileInfo->m_pFilePattern))
        {
            // copy file name
            strcpy(fileinfo->name, ent->d_name);

            // set directory or file
            iLast = strlen(pFindFileInfo->m_pFilePath) - 1;
            strcpy(fileName, pFindFileInfo->m_pFilePath);
            if (pFindFileInfo->m_pFilePath[iLast] != '/')
                strcat(fileName, "/");
            strcat(fileName, ent->d_name);
            if (stat(fileName, &statBuf) == 0) // if stat fail, ignore this entry and continue
            {
                if (statBuf.st_mode & S_IFREG)
                    fileinfo->attrib |= FILE_ATTRIBUTE_ARCHIVE;
                else if (statBuf.st_mode & S_IFDIR)
                    fileinfo->attrib |= FILE_ATTRIBUTE_DIRECTORY;
                break;
            }
        }
    }

    return ent ? 0 : -1;
}

//*****************************************************************************
int GsFindClose(intptr_t handle)
{
    // free memory and closedir()
    struct FIND_FILE_INFO *pFindFileInfo = (struct FIND_FILE_INFO *)handle;
    if (pFindFileInfo)
    {
        TW_FREE(pFindFileInfo->m_pFilePath);
        TW_FREE(pFindFileInfo->m_pFilePattern);
        closedir(pFindFileInfo->m_pDir);

        TW_FREE(pFindFileInfo);
    }
    return 0;
}

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

// match the expressions
int MatchShellExpression(char *str, char *shexp)
{
    while (1)
    {
        char c = *shexp++;
        switch (c)
        {
        case 0:
            return (*str == 0 ? 1 : 0);

        case '?':
            if (*str == 0)
                return 0;
            ++str;
            break;

        case '*':
            c = *shexp;
            while (c == '*')
                c = *++shexp;
            if (c == 0)
                return 1;
            while (*str != 0)
            {
                if (MatchShellExpression(str, shexp))
                    return 1;

                ++str;
            }
            return (0);

        default:
            if (c != *str)
                return 0;
            ++str;
            break;
        }
    }
    // statement not reached
    return 0;
}

/*****************************************************************************/
int GsSetFilePermissionRWX(char *pszFileName)
{
    return chmod(pszFileName, S_IRUSR | S_IWUSR | S_IXUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IXOTH);
}

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

//*****************************************************************************
void OnShutdownSignal(int i)
{
    GsAppLog(GS_DEBUG, MODULE_GS_RUNTIME, "Linux shutdown event received.");
    GsShutdownApplication(FALSE);
}
