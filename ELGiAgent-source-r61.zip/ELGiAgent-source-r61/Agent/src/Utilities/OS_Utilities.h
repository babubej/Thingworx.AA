//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  OS_Utilities.h
//
//  Subsystem  :  ELGiAgent
//
//  Description:  OS abstraction layer for various support (utility) functions.
//
//*****************************************************************************

#ifndef __OS_UTILITIES_H__
#define __OS_UTILITIES_H__

#if defined(__linux__) || defined(__linux) || defined(linux)
#if !defined(LINUX)
#define LINUX 1
#endif
#endif

#if defined(_WIN32) && !defined(WIN32)
#define WIN32 1
#endif

#include <time.h>
#include "GeneralDefines.h"

//*****************************************************************************
// GsGetCwd()
//  - returns char* to the current working directory.
// caller is responsible to free the memory returned by GsGetCwd
// ****************************************************************************
char *GsGetCwd();

GS_BOOL GsSetCwd(const char *pszCwd);

//*****************************************************************************
// GsGetEnvironmentVariable
char *GsGetEnvironmentVariable(const char *variableName);

//*****************************************************************************
// GsGetCurrentProcessId()
unsigned long GsGetCurrentProcessId(void);

//*****************************************************************************
// GsReadFileContent
//  - input:  Filename of file to be read.
//  - return:  pointer to memory holding the content of the entire file.
// caller is responsible to free the memory returned by GsReadFileContent
// ****************************************************************************
char *GsReadFileContent(char *fileName);

int GsWriteFileContent(char *fileName, const char *fileContent);

//*****************************************************************************
//
// GsReadLineFromFile()
// Read a line from the open file. Read will stop either (size - 1) characters are read, or newline is encountered.
// Return NULL if file end is reached and no content is read.
//
//*****************************************************************************
char *GsReadLineFromFile(char *buffer, int size, FILE *hFile);

//*****************************************************************************
//
// GsGetSecondsSince1970()
//	returns a time_t in Epoch time.
//
//*****************************************************************************
time_t GsGetSecondsSince1970();

//*****************************************************************************
//
// GetLocalTime()
//					It returns the system's local time based on seconds.
//
//*****************************************************************************
GS_BOOL GsGetLocalTime(struct tm *pLocal);

//*****************************************************************************
int GsGetYear();

//*****************************************************************************
// Wait for the shutdown signal.
void GsWaitForShutdownSignal();

//*****************************************************************************
// return TRUE if shutdown signal was or has been received.
GS_BOOL GsCheckForShutdownSignal(unsigned long delay);

//*****************************************************************************
// Install the OS shutdown signal handler
void GsInstallOSShutdownSignalHandler();

//*****************************************************************************
// Execute a program, or batch file (Windows) or shell script (Linux)
// pszArgs is a list of args separated by spaces
// For tar example: -xzf example.tar.gz -C folder
// bWait to wait for the child process to exit
// maxWaitDelay:  maximim time to wait for a synchronous process to finish.
unsigned long GsExecuteProgram(char *szFile, char *pszArgs, unsigned long *pExitCode, GS_BOOL bWait, unsigned long maxWaitDelay);

// Convert path (slash vs. back-slash). Caller owns the return memory
char *GsConvertPath(char *pPath);

// Get the path portion of the full-path file name. Caller owns the memory
// Path must have been converted per OS already
char *GsGetPathPortion(char *pszFullPathFile);

// Get the file name portion of the full-path file name. Caller owns the memory
// Path must have been converted per OS already
char *GsGetFileNamePortion(char *pszFullPathFile);

// pPath is folder
GS_BOOL GsCreateFolderRecursive(char *pPath);

// pFile is file name
GS_BOOL GsCreateFolderForFile(char *pFile);

// pFile is file name
GS_BOOL GsDeleteFile(char *pFile);

// pSourceFile is old file name. pTargetFile is new file name
GS_BOOL GsRenameFile(char *pSourceFile, char *pTargetFile);

// convert ascii string to an long long
uint64_t GsAsciiToLongLong(char *pszString);

// implement open() function for Linux and Windows
int Gsopen(char *pathname, int oflags, int mode);

// Get file extension
char *GsGetFileExtension(char *pszFilename);

// Set a file's permissions to read/write/execute.
int GsSetFilePermissionRWX(char *pszFileName);

// FindFirst, Findnext, FindClose utility functions support.
#ifdef WIN32
#include <io.h>
#else
#define FILE_ATTRIBUTE_DIRECTORY 0x00000010
#define FILE_ATTRIBUTE_ARCHIVE 0x00000020

struct _finddata32_t
{
    unsigned int attrib;
    time_t time_create; /* -1 for FAT file systems */
    time_t time_access; /* -1 for FAT file systems */
    time_t time_write;
    size_t size;
    char name[260];
};

struct FIND_FILE_INFO
{
    char *m_pFilePath;
    char *m_pFilePattern;
    DIR *m_pDir;
};
#endif

// GsFindFirst, GsFindNext, and GsFindClose functions
intptr_t GsFindFirst(char *filespec, struct _finddata32_t *fileinfo);
int GsFindNext(intptr_t handle, struct _finddata32_t *fileinfo);
int GsFindClose(intptr_t handle);

#endif // __OS_UTILITIES_H__
