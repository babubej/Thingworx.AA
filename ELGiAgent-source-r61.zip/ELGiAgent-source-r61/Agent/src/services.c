// ****************************************************************************
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
// ****************************************************************************
//
//  Filename   : services.c
//
//  Subsystem  : ELGiAgent
//
//  Description:  A collection of ThingWorx Services (unrelated to each other).
/*
    These Service are registered with and then invoked by the ThingWorx Server.
    Service include:
        - RestartApplication
        - ExecuteApplicationRemote

    This code follows the standard pattern for a functional module with global functions for:  initialize, start and shutdown.
    This code does NOT have a thread.  The Services are processed on the caller's thread (the SDK messaging function).
    Therefore, RestartApplication() signals the 'main' (main.c) thread to shutdown & restart.
               ExecuteApplicationRemote has the optional parameter to execute an application 
               synchronously or asynchronously. 
              
    Programmer Note:  ThingWorx Services are defined with the same input/output parameters, but 
       use an Infotable for input & output.  The Infotable (like events) are defined per a specific 'data shape'.
       Services need to be registered with the ThingWorx Server to define which input/output infotables are optionally
       used and also to define their data shapes.
       At the server, you will need to browse for the remove services in order to use them.

       It is recommended that you retain these services for you application and use them as examples for 
       implementing your own services.  
*/
//>----------------------------------------------------------------------------

#include "AgentConfig.h"
#include "configParams.h"

/* Upload Configuration Service information */
#define UPLOAD_CONFIGURATION_SERVICE_NAME "UploadConfiguration"
#define UPLOAD_CONFIGURATION_SERVICE_DESC "Upload new Modbus Configuration files on demand (modbus config & tag parser info)"

/* Retrieve Configuration Service information */
#define RETRIEVE_CONFIGURATION_SERVICE_NAME "RetrieveConfiguration"
#define RETRIEVE_CONFIGURATION_SERVICE_DESC "Retrieve current configuration files from the agent (if any)"

/* Retrieve Logging File Configuration */
#define RETRIEVE_LOGGING_INFO_SERVICE_NAME "RetrieveLoggingInfo"
#define RETRIEVE_LOGGING_INFO_SERVICE_DESC "Retrieve current logging info (levels & categories)"

/* Set Logging Level Service */
#define SET_LOGGING_LEVEL_SERVICE_NAME "SetLoggingLevel"
#define SET_LOGGING_LEVEL_SERVICE_DESC "Set current logging level for a given category"
#define SET_LOGGING_LEVEL_MODULE_NAME "moduleName"
#define SET_LOGGING_LEVEL_LEVEL "level"
#define SET_LOGGING_LEVEL_PERSIST "persist"

/* Start Data Acquisition Service information */
#define START_DATA_ACQUISITION_SERVICE_NAME "StartDataAcquisition"
#define START_DATA_ACQUISITION_SERVICE_DESC "Start data acquisition process on demand if possible"

/* Restart Application Service information */
#define RESTART_APP_SERVICE_NAME "RestartApplication"
#define RESTART_APP_SERVICE_DESC "Restart the Agent"

/* Unregister Application Service information */
#define UNREGISTER_APP_SERVICE_NAME "UnregisterApplication"
#define UNREGISTER_APP_SERVICE_DESC "Unregister the Agent from the Platform"

#define UNREGISTER_APP_SHOULD_SHUTDOWN "shouldShutdown"
#define UNREGISTER_APP_TIMEOUT_SEC "timeoutSec"

/* Execute Application Service and data shape strings. */
#define EXECUTE_APPLICATION_SERVICE_NAME "ExecuteApplicationRemote"
#define EXECUTE_APPLICATION_SERVICE_DESC "Execute an application on the remote device."
#define EXECUTE_APPLICATION_NAME "application"
#define EXECUTE_APPLICATION_PARAMETERS "parameters"
#define EXECUTE_APPLICATION_WAIT "executeSynchronously"
#define EXECUTE_APPLICATION_WAIT_DELAY "synchronousWaitDelaySeconds"

/* Execute Application Service and data shape strings. */
#define GET_LOG_FILE_SERVICE_NAME "GetCurrentLogFile"
#define GET_LOG_FILE_SERVICE_DESC "Retrieve the current content of the log file as an InfoTable."

/* Execute Application Service resulting data shape strings. */
#define EXECUTE_APP_DS_COLUMN_STATUS "status"
#define EXECUTE_APP_DS_COLUMN_STATUS_DESC "Boolean value indicating whether or not it was possible to execute the given application."
#define EXECUTE_APP_DS_COLUMN_EXIT_CODE "exitCode"
#define EXECUTE_APP_DS_COLUMN_EXIT_CODE_DESC "Exit code returned by the executed process (it's application dependent)."
#define EXECUTE_APPLICATION_DS_NAME "com.thingworx.ELGiAgent.ExecuteApplicationRemoteDS"
#define STR_INFOTABLE_RESULT "result"

#define NUM_MAX_PARAMS 10
#define NUM_MAX_FIELDS 10
//>----------------------------------------------------------------------------

typedef struct FieldInfo
{
    const char *name;
    const char *description;
    enum BaseType type;
} FieldInfo;

typedef struct DataShapeInfo
{
    const char *name;
    FieldInfo fields[NUM_MAX_FIELDS];
} DataShapeInfo;

typedef struct ParameterInfo
{
    const char *name;
    const char *description;
    enum BaseType type;
} ParameterInfo;

typedef struct ServiceInfo
{
    const char *name;
    const char *description;
    ParameterInfo parameters[NUM_MAX_PARAMS];
    enum BaseType resultType;
    DataShapeInfo resultDS;
    service_cb callback;
    void *userData;
} ServiceInfo;

static twInfoTable *g_pExeAppInfoTable = NULL;

//>----------------------------------------------------------------------------
// function prototypes
twDataShape *CreateExecuteApplicationDataShape();

enum msgCodeEnum UploadConfiguration(const char *pszEntityName, const char *pszServiceName,
                                     twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata);

enum msgCodeEnum RetrieveConfiguration(const char *pszEntityName, const char *pszServiceName,
                                       twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata);

enum msgCodeEnum RetrieveLoggingInfo(const char *pszEntityName, const char *pszServiceName,
                                     twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata);

enum msgCodeEnum SetLoggingLevel(const char *pszEntityName, const char *pszServiceName,
                                 twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata);

enum msgCodeEnum StartDataAcquisition(const char *pszEntityName, const char *pszServiceName,
                                      twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata);

enum msgCodeEnum RestartApplication(const char *pszEntityName, const char *pszServiceName,
                                    twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata);

enum msgCodeEnum UnregisterApplication(const char *pszEntityName, const char *pszServiceName,
                                       twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata);

enum msgCodeEnum ExecuteApplication(const char *pszEntityName, const char *pszServiceName,
                                    twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata);

enum msgCodeEnum GetCurrentLogFile(const char *pszEntityName, const char *pszServiceName,
                                   twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata);

//>----------------------------------------------------------------------------

//* UploadConfiguration service
static ServiceInfo s_uploadConfigurationInfo;
//* RetrieveConfiguration service
static ServiceInfo s_retrieveConfigurationInfo;
//* RetrieveLoggingInfo service
static ServiceInfo s_retrieveLoggingInfo;
//* SetLoggingLevel
static ServiceInfo s_setLoggingLevelInfo;
//* StartDataAcquisition service
static ServiceInfo s_startDataAcquisitionInfo;
//* RestartApplication service
static ServiceInfo s_restartApplicationInfo;
//* UnregisterApplication service
static ServiceInfo s_unregisterApplicationInfo;
//* ExecuteApplication service
static ServiceInfo s_executeApplicationInfo;
//* ExecuteApplication service
static ServiceInfo s_getCurrentLogFileInfo;

static ServiceInfo *s_allServicesRegistrationList[] = {
    &s_uploadConfigurationInfo,
    &s_retrieveConfigurationInfo,
    &s_retrieveLoggingInfo,
    &s_setLoggingLevelInfo,
    &s_startDataAcquisitionInfo,
    &s_restartApplicationInfo,
    &s_unregisterApplicationInfo,
    /*&s_executeApplicationInfo,*/
    &s_getCurrentLogFileInfo,
    NULL};

//>----------------------------------------------------------------------------

void Services_Initialize()
{
    g_pExeAppInfoTable = twInfoTable_Create(CreateExecuteApplicationDataShape());
} //> Services_Initialize()
//>----------------------------------------------------------------------------

// Service_Start() This gets called once only on start up
// There is no threads necessary and nothing to do in start/shutdown.
int Services_Start()
{
    return TW_OK;
} //> Services_Start()
//>----------------------------------------------------------------------------

void Services_Shutdown()
{
    if (g_pExeAppInfoTable)
        twInfoTable_Delete(g_pExeAppInfoTable);
    g_pExeAppInfoTable = NULL;
} //> Services_Shutdown()
//>----------------------------------------------------------------------------

/**
 * Function to register services with ThingWorx Server. 
 */
void RegisterServices()
{
    const int numServices = sizeof(s_allServicesRegistrationList) / sizeof(ServiceInfo *);
    int maxFields = 0;
    ServiceInfo *pServiceInfo = NULL;
    ParameterInfo *pParamInfo = NULL;
    FieldInfo *pFieldInfo = NULL;
    twDataShapeEntry *pEntry = NULL;
    twDataShape *pInputsDS = NULL;
    twDataShape *pOutputDS = NULL;

    for (int siIdx = 0; siIdx < numServices; siIdx++)
    {
        pServiceInfo = s_allServicesRegistrationList[siIdx];
        // last pointer should be NULL
        if (!pServiceInfo)
            break; // end!
        if (!pServiceInfo->name)
            continue; // skip over empty name!
        pInputsDS = NULL;
        pOutputDS = NULL;
        for (int pIdx = 0; pIdx < NUM_MAX_PARAMS; pIdx++)
        {
            pParamInfo = &pServiceInfo->parameters[pIdx];
            // last name pointer should be NULL
            if (!pParamInfo->name)
                break; // end!
            // Create a single data shape field - this will represent a single input paramater
            pEntry = twDataShapeEntry_Create(pParamInfo->name, pParamInfo->description, pParamInfo->type);
            if (!pInputsDS)
                pInputsDS = twDataShape_Create(pEntry);
            else
                twDataShape_AddEntry(pInputsDS, pEntry);
        } //# for each possible input parameter
        // Create output data shape only on IT output type
        if (pServiceInfo->resultType == TW_INFOTABLE)
            maxFields = NUM_MAX_FIELDS;
        for (int fIdx = 0; fIdx < maxFields; fIdx++)
        {
            pFieldInfo = &pServiceInfo->resultDS.fields[fIdx];
            if (!pFieldInfo->name)
                break; // end!
            // Create a single data shape field - for the output type info
            pEntry = twDataShapeEntry_Create(pFieldInfo->name, pFieldInfo->description, pFieldInfo->type);
            if (!pOutputDS)
                pOutputDS = twDataShape_Create(pEntry);
            else
                twDataShape_AddEntry(pOutputDS, pEntry);
        } //# for each possible result field
        if (pOutputDS != NULL && pServiceInfo->resultType == TW_INFOTABLE)
        {
            pOutputDS->name = GsStringDup(pServiceInfo->resultDS.name);
        }
        /* Register service from the list. All required information should be available from the structs */
        twApi_RegisterService(TW_THING, g_pszThingIdentifier, (char *)pServiceInfo->name,
                              (char *)pServiceInfo->description, pInputsDS, pServiceInfo->resultType,
                              pOutputDS, pServiceInfo->callback, pServiceInfo->userData);
    } //# for each service info

} //> RegisterServices()
//>----------------------------------------------------------------------------

//* UploadConfiguration service
static ServiceInfo s_uploadConfigurationInfo = {
    UPLOAD_CONFIGURATION_SERVICE_NAME, // name
    UPLOAD_CONFIGURATION_SERVICE_DESC, // description
    // parameters
    {{STR_MODBUS_CONFIG, "Modbus configuration file content", TW_STRING},
     {STR_TAG_PARSER, "Tag parser JSON content", TW_JSON},
     {STR_SHOULD_RESTART, "Should restart current app", TW_BOOLEAN},
     {NULL}},
    // resultType
    TW_BOOLEAN,
    // resultDS
    {NULL, {NULL}},
    // callback
    UploadConfiguration,
    // userData
    NULL};

#define SERVICE_NAME UPLOAD_CONFIGURATION_SERVICE_NAME
enum msgCodeEnum UploadConfiguration(const char *pszEntityName, const char *pszServiceName,
                                     twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
    cJSON *pJsonContent = NULL;
    int retCode = TW_OK;
    twPrimitive *pModbusConfigParam = NULL;
    twPrimitive *pTagParserParam = NULL;
    twPrimitive *pRestartParam = NULL;
    char *pszModbusConfigContent = NULL;
    char *pszTagParserUnformatted = NULL;
    GS_BOOL shouldRestart = FALSE;
    twInfoTable *pResultInfoTable = NULL;
    twInfoTableRow *pResultRow = NULL;

    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Invoking service : %s", SERVICE_NAME);
    // verify service name.
    if (strcmp(pszServiceName, SERVICE_NAME) != 0)
        return TWX_BAD_OPTION;

    // Validate all 2 input parameters.  Note:  ThingWorx Server can send NULL parameters if the user doesn't set them explicitly.
    retCode = twInfoTable_GetPrimitive(pItParams, STR_MODBUS_CONFIG, 0, &pModbusConfigParam);
    if (retCode != TW_OK || pModbusConfigParam->type != TW_STRING || pModbusConfigParam->val.bytes.len == 0)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type string and to not be a NULL value",
                 SERVICE_NAME, STR_MODBUS_CONFIG);
        return TWX_PRECONDITION_FAILED;
    }

    retCode = twInfoTable_GetPrimitive(pItParams, STR_TAG_PARSER, 0, &pTagParserParam);
    if (retCode != TW_OK || pTagParserParam->type != TW_JSON)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type JSON",
                 SERVICE_NAME, STR_TAG_PARSER);
        return TWX_PRECONDITION_FAILED;
    }
    // optional / no fail if missing or different
    retCode = twInfoTable_GetPrimitive(pItParams, STR_SHOULD_RESTART, 0, &pRestartParam);
    if (retCode == TW_OK && pRestartParam->type == TW_BOOLEAN)
    {
        shouldRestart = pRestartParam->val.boolean;
    }
    pszModbusConfigContent = (pModbusConfigParam) ? pModbusConfigParam->val.bytes.data : NULL;
    if (pszModbusConfigContent != NULL)
    {
        // Open & overwrite fully the target file with new content
        // (possibly create backup ?)
        RefreshModbusConfigurationFile(pszModbusConfigContent);
    } //# Modbus Configuration File

    pszTagParserUnformatted = (pTagParserParam) ? pTagParserParam->val.bytes.data : NULL;
    if (pszTagParserUnformatted != NULL)
    {
        pJsonContent = cJSON_Parse(pszTagParserUnformatted);
        if (!pJsonContent)
        {
            shouldRestart = FALSE;
        }
        else
        {
            char *stringified = cJSON_Print(pJsonContent);
            RefreshTagParserConfigurationFile(stringified);
            TW_FREE(stringified);
            cJSON_Delete(pJsonContent);
        }
    } //# Tag Parser Configuration File
    *ppItContent = twInfoTable_CreateFromBoolean(STR_IT_COL_RESULT, TRUE);
    if (shouldRestart)
        GsShutdownApplication(TRUE);
    return TWX_SUCCESS;
} //> UploadConfiguration(...)
#undef SERVICE_NAME
//>----------------------------------------------------------------------------

//* RetrieveConfiguration service
static ServiceInfo s_retrieveConfigurationInfo = {
    RETRIEVE_CONFIGURATION_SERVICE_NAME, // name
    RETRIEVE_CONFIGURATION_SERVICE_DESC, // description
    // parameters
    {{NULL}},
    // resultType
    TW_JSON,
    // resultDS
    {NULL, {NULL}},
    // callback
    RetrieveConfiguration,
    // userData
    NULL};

#define SERVICE_NAME RETRIEVE_CONFIGURATION_SERVICE_NAME
enum msgCodeEnum RetrieveConfiguration(const char *pszEntityName, const char *pszServiceName,
                                       twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{

    cJSON *pJson = cJSON_CreateObject();
    cJSON *pJsonTagParser = NULL;
    char *pszConfigFilePath = NULL;
    char *pszConfigContent = NULL;

    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Invoking service : %s", SERVICE_NAME);
    // verify service name.
    if (strcmp(pszServiceName, SERVICE_NAME) != 0)
        return TWX_BAD_OPTION;

    pszConfigFilePath = GetFilePathInAgentHome(MODBUS_CONFIG_FOLDER_NAME, STR_MODBUS_CONFIG_FILENAME);
    pszConfigContent = GsReadFileContent(pszConfigFilePath);
    // modbus_config
    if (!pszConfigContent)
    {
        cJSON_AddItemToObject(pJson, STR_MODBUS_CONFIG, cJSON_CreateString(""));
    }
    else
    {
        cJSON_AddItemToObject(pJson, STR_MODBUS_CONFIG, cJSON_CreateString(pszConfigContent));
    }
    cJSON_AddItemToObject(pJson, STR_MODBUS_CONFIG_OK, cJSON_CreateBool(pszConfigContent != NULL));

    if (pszConfigContent != NULL)
        TW_FREE(pszConfigContent);
    TW_FREE(pszConfigFilePath);
    // tag_parser
    pszConfigFilePath = GetFilePathInAgentHome(MODBUS_CONFIG_FOLDER_NAME, STR_TAG_PARSER_CONFIG_FILENAME);
    pszConfigContent = GsReadFileContent(pszConfigFilePath);
    if (!pszConfigContent)
    {
        cJSON_AddItemToObject(pJson, STR_TAG_PARSER, cJSON_CreateObject());
    }
    else
    {
        pJsonTagParser = cJSON_Parse(pszConfigContent);
        if (!pJsonTagParser)
        {
            pJsonTagParser = cJSON_CreateObject();
            TW_FREE(pszConfigContent);
            pszConfigContent = NULL; // make OK -> false
        }
        cJSON_AddItemToObject(pJson, STR_TAG_PARSER, pJsonTagParser);
    }
    cJSON_AddItemToObject(pJson, STR_TAG_PARSER_OK, cJSON_CreateBool(pszConfigContent != NULL));
    *ppItContent = twInfoTable_CreateFromJson(pJson, "result");
    cJSON_Delete(pJson);
    if (pszConfigContent != NULL)
        TW_FREE(pszConfigContent);
    TW_FREE(pszConfigFilePath);
    return TWX_SUCCESS;
} //> RetrieveConfiguration(...)
#undef SERVICE_NAME
//>----------------------------------------------------------------------------

//* RetrieveLoggingInfo service
static ServiceInfo s_retrieveLoggingInfo = {
    RETRIEVE_LOGGING_INFO_SERVICE_NAME, // name
    RETRIEVE_LOGGING_INFO_SERVICE_DESC, // description
    // parameters
    {{NULL}},
    // resultType
    TW_JSON,
    // resultDS
    {NULL, {NULL}},
    // callback
    RetrieveLoggingInfo,
    // userData
    NULL};

#define SERVICE_NAME RETRIEVE_LOGGING_INFO_SERVICE_NAME
enum msgCodeEnum RetrieveLoggingInfo(const char *pszEntityName, const char *pszServiceName,
                                     twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
    cJSON *pJsonLogging = NULL;
    char *pszConfigFilePath = NULL;
    char *pszConfigContent = NULL;

    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Invoking service : %s", SERVICE_NAME);
    // verify service name.
    if (strcmp(pszServiceName, SERVICE_NAME) != 0)
        return TWX_BAD_OPTION;

    // read the Json file
    pszConfigFilePath = GetFilePathInAgentHome(CONFIG_FOLDER_NAME, STR_JSON_FILE_LOGGING);
    pszConfigContent = GsReadFileContent(pszConfigFilePath);
    GS_BOOL bJSONValid = FALSE;
    if (pszConfigContent)
    {
        pJsonLogging = cJSON_Parse(pszConfigContent);
        if (pJsonLogging)
        {
            cJSON *pVersion = cJSON_GetObjectItem(pJsonLogging, STR_VERSION);
            if (pVersion && pVersion->valueint == CURRENT_CONFIG_FILE_VERSION)
                bJSONValid = TRUE;
        }
    }
    // post error if json not valid
    if (bJSONValid == FALSE)
    {
        cJSON_Delete(pJsonLogging);
        *ppItContent = twInfoTable_CreateFromJson(cJSON_CreateObject(), "result");
    }
    else
    {
        // find the logger object
        cJSON *pLogger = cJSON_GetObjectItem(pJsonLogging, "logger");
        if (pLogger)
            *ppItContent = twInfoTable_CreateFromJson(pLogger, "result");
    }
    if (pszConfigContent != NULL)
        TW_FREE(pszConfigContent);
    TW_FREE(pszConfigFilePath);
    if (pJsonLogging != NULL)
        cJSON_Delete(pJsonLogging);
    return TWX_SUCCESS;
} //> RetrieveConfiguration(...)
#undef SERVICE_NAME
//>----------------------------------------------------------------------------

//* SetLoggingLevel service
static ServiceInfo s_setLoggingLevelInfo = {
    SET_LOGGING_LEVEL_SERVICE_NAME, // name
    SET_LOGGING_LEVEL_SERVICE_DESC, // description
    // parameters
    {{SET_LOGGING_LEVEL_MODULE_NAME, "Log module name to update", TW_STRING},
     {SET_LOGGING_LEVEL_LEVEL, "New log level to set. ERROR by default.", TW_STRING},
     {SET_LOGGING_LEVEL_PERSIST, "Should persist changes (still active after restart)?", TW_BOOLEAN},
     {NULL}},
    // resultType
    TW_NOTHING,
    // resultDS
    {NULL, {NULL}},
    // callback
    SetLoggingLevel,
    // userData
    NULL};

#define SERVICE_NAME SET_LOGGING_LEVEL_SERVICE_NAME
enum msgCodeEnum SetLoggingLevel(const char *pszEntityName, const char *pszServiceName,
                                 twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
    twPrimitive *pModuleNameParam = NULL;
    twPrimitive *pLevelParam = NULL;
    twPrimitive *pPersistParam = NULL;
    char *pszModuleName = NULL;
    const char *pszLevel = NULL;
    GS_BOOL persist = FALSE;
    int retCode = TW_OK;
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Invoking service : %s", SERVICE_NAME);
    // verify service name.
    if (strcmp(pszServiceName, SERVICE_NAME) != 0)
        return TWX_BAD_OPTION;

    retCode = twInfoTable_GetPrimitive(pItParams, SET_LOGGING_LEVEL_MODULE_NAME, 0, &pModuleNameParam);
    if (retCode != TW_OK || pModuleNameParam->type != TW_STRING || pModuleNameParam->val.bytes.len == 0)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type string and to not be a NULL value",
                 SERVICE_NAME, SET_LOGGING_LEVEL_MODULE_NAME);
        return TWX_PRECONDITION_FAILED;
    }
    retCode = twInfoTable_GetPrimitive(pItParams, SET_LOGGING_LEVEL_LEVEL, 0, &pLevelParam);
    if (retCode != TW_OK || pLevelParam->type != TW_STRING)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type JSON",
                 SERVICE_NAME, SET_LOGGING_LEVEL_LEVEL);
        return TWX_PRECONDITION_FAILED;
    }
    pszModuleName = (pModuleNameParam) ? pModuleNameParam->val.bytes.data : NULL;
    pszLevel = (pLevelParam) ? pLevelParam->val.bytes.data : NULL;
    if (pLevelParam->val.bytes.len == 0)
        pszLevel = "ERROR"; //? fixme
    if (!pszModuleName)
        return TWX_BAD_OPTION;
    retCode = twInfoTable_GetPrimitive(pItParams, SET_LOGGING_LEVEL_PERSIST, 0, &pPersistParam);
    if (retCode == TW_OK && pPersistParam->type == TW_BOOLEAN)
        persist = pPersistParam->val.boolean;
    GsLog_ChangeLogLevelForString(pszModuleName, pszLevel);
    if (persist)
    {
        // read in json configuration, switch values, save back
        // should create a log cofing file copy?
    }
    return TWX_SUCCESS;
} //> SetLoggingLevel(...)
#undef SERVICE_NAME
//>----------------------------------------------------------------------------

//* StartDataAcquisition service
static ServiceInfo s_startDataAcquisitionInfo = {
    START_DATA_ACQUISITION_SERVICE_NAME, // name
    START_DATA_ACQUISITION_SERVICE_DESC, // description
    // parameters
    {{NULL}},
    // resultType
    TW_BOOLEAN,
    // resultDS
    {NULL, {NULL}},
    // callback
    StartDataAcquisition,
    // userData
    NULL};

#define SERVICE_NAME START_DATA_ACQUISITION_SERVICE_NAME
enum msgCodeEnum StartDataAcquisition(const char *pszEntityName, const char *pszServiceName,
                                      twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Invoking service : %s", SERVICE_NAME);
    // verify service name.
    if (strcmp(pszServiceName, SERVICE_NAME) != 0)
        return TWX_BAD_OPTION;
    return TWX_SUCCESS;
} //> StartDataAcquisition(...)
#undef SERVICE_NAME
//>----------------------------------------------------------------------------

//* RestartApplication service
static ServiceInfo s_restartApplicationInfo = {
    RESTART_APP_SERVICE_NAME, // name
    RESTART_APP_SERVICE_DESC, // description
    // parameters
    {{NULL}},
    //resultType
    TW_NOTHING,
    // resultDS
    {NULL, {NULL}},
    // callback
    RestartApplication,
    // userData
    NULL};

#define SERVICE_NAME RESTART_APP_SERVICE_NAME
enum msgCodeEnum RestartApplication(const char *pszEntityName, const char *pszServiceName,
                                    twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Currently executing: %s to restart the Agent...", SERVICE_NAME);

    // FIXME
    /* Exit and restart the application.  This occurs asynchronously */
    GsShutdownApplication(TRUE);

    return TWX_SUCCESS;
} //> RestartApplication(...)
#undef SERVICE_NAME
//>----------------------------------------------------------------------------

//* RestartApplication service
static ServiceInfo s_unregisterApplicationInfo = {
    UNREGISTER_APP_SERVICE_NAME, // name
    UNREGISTER_APP_SERVICE_DESC, // description
    // parameters
    {{UNREGISTER_APP_SHOULD_SHUTDOWN, "", TW_BOOLEAN},
     {UNREGISTER_APP_TIMEOUT_SEC, "", TW_INTEGER},
     {NULL}},
    //resultType
    TW_NOTHING,
    // resultDS
    {NULL, {NULL}},
    // callback
    UnregisterApplication,
    // userData
    NULL};

#define SERVICE_NAME UNREGISTER_APP_SERVICE_NAME
enum msgCodeEnum UnregisterApplication(const char *pszEntityName, const char *pszServiceName,
                                       twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
    int retCode = TW_OK;
    twPrimitive *pShouldShutdownPrimitive = NULL;
    twPrimitive *pTimeoutSecPrimitive = NULL;
    GS_BOOL shouldShutdown = FALSE;
    int timeoutSec = 0;
    char *identifierCopy;

    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Invoking service : %s", SERVICE_NAME);

    // Parameters can be a NULL string.
    retCode = twInfoTable_GetPrimitive(pItParams, UNREGISTER_APP_SHOULD_SHUTDOWN, 0, &pShouldShutdownPrimitive);
    if (pShouldShutdownPrimitive && pShouldShutdownPrimitive->type != TW_BOOLEAN)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type boolean.",
                 SERVICE_NAME, UNREGISTER_APP_SHOULD_SHUTDOWN);
        return TWX_PRECONDITION_FAILED;
    }

    retCode = twInfoTable_GetPrimitive(pItParams, UNREGISTER_APP_TIMEOUT_SEC, 0, &pTimeoutSecPrimitive);
    if (pTimeoutSecPrimitive && pTimeoutSecPrimitive->type != TW_INTEGER)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type boolean.",
                 SERVICE_NAME, UNREGISTER_APP_TIMEOUT_SEC);
        return TWX_PRECONDITION_FAILED;
    }

    shouldShutdown = pShouldShutdownPrimitive->val.boolean;
    timeoutSec = pTimeoutSecPrimitive->val.integer;
    if (timeoutSec < 0)
        timeoutSec = 0;
    if (timeoutSec > 30)
        timeoutSec = 30;
    twSleepMsec(1000 * timeoutSec);
    // duplicate previous value (backup)
    identifierCopy = GsStringDup(g_pszThingIdentifier);
    g_pszThingIdentifier[0] = '\0';   // reset to empty
    RefreshServerConfigurationFile(); // save the configuration file without identifier
    SetThingIdentifier(identifierCopy);
    TW_FREE(identifierCopy);
    if (shouldShutdown)
        GsShutdownApplication(FALSE); // without restart
    return TWX_SUCCESS;
} //> UnregisterApplication(...)
#undef SERVICE_NAME
//>----------------------------------------------------------------------------

twDataShape *CreateExecuteApplicationDataShape(void)
{
    twDataShape *pDataShape = twDataShape_Create(NULL);
    twDataShape_SetName(pDataShape, EXECUTE_APPLICATION_DS_NAME);
    twDataShape_AddEntry(pDataShape, twDataShapeEntry_Create(EXECUTE_APP_DS_COLUMN_STATUS,
                                                             EXECUTE_APP_DS_COLUMN_STATUS_DESC, TW_BOOLEAN));
    twDataShape_AddEntry(pDataShape, twDataShapeEntry_Create(EXECUTE_APP_DS_COLUMN_EXIT_CODE,
                                                             EXECUTE_APP_DS_COLUMN_EXIT_CODE_DESC, TW_INTEGER));
    return pDataShape;
} //> CreateExecuteApplicationDataShape()
//>----------------------------------------------------------------------------

//* ExecuteApplication service
static ServiceInfo s_executeApplicationInfo = {
    EXECUTE_APPLICATION_SERVICE_NAME, // name
    EXECUTE_APPLICATION_SERVICE_DESC, // description
    // parameters
    {{EXECUTE_APPLICATION_NAME, NULL, TW_STRING},
     {EXECUTE_APPLICATION_PARAMETERS, NULL, TW_STRING},
     {EXECUTE_APPLICATION_WAIT, NULL, TW_BOOLEAN},
     {EXECUTE_APPLICATION_WAIT_DELAY, NULL, TW_INTEGER},
     {NULL}},
    // resultType
    TW_INFOTABLE,
    // resultDS
    {EXECUTE_APPLICATION_DS_NAME,
     // fields
     {{EXECUTE_APP_DS_COLUMN_STATUS,
       EXECUTE_APP_DS_COLUMN_STATUS_DESC, TW_BOOLEAN},
      {EXECUTE_APP_DS_COLUMN_EXIT_CODE,
       EXECUTE_APP_DS_COLUMN_EXIT_CODE_DESC, TW_INTEGER},
      {NULL}}},
    // callback
    ExecuteApplication,
    // userData
    NULL};

#define SERVICE_NAME EXECUTE_APPLICATION_SERVICE_NAME
enum msgCodeEnum ExecuteApplication(const char *pszEntityName, const char *pszServiceName,
                                    twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
    int retCode = TW_OK;
    twPrimitive *pAppNamePrimitive = NULL;
    twPrimitive *pAppParametersPrimitive = NULL;
    twPrimitive *pSynchronousPrimitive = NULL;
    twPrimitive *pSynchronousDelayPrimitive = NULL;
    char *pszAppName = NULL;
    char *pszAppParameters = NULL;
    GS_BOOL bWait = FALSE;
    unsigned long exitCode = 0;
    unsigned long waitDelay = INFINITE; // default if no wait delay is defined.
    GS_BOOL bSuccess = TRUE;
    twInfoTable *pResultInfoTable = NULL;
    twInfoTableRow *pResultRow = NULL;

    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Invoking service : %s", SERVICE_NAME);

    // verify service name.
    if (strcmp(pszServiceName, SERVICE_NAME) != 0)
        return TWX_BAD_OPTION;

    // Validate all 4 input parameters.  Note:  ThingWorx Server can send NULL parameters if the user doesn't set them explicitly.
    retCode = twInfoTable_GetPrimitive(pItParams, EXECUTE_APPLICATION_NAME, 0, &pAppNamePrimitive);
    if (retCode != TW_OK || pAppNamePrimitive->type != TW_STRING || pAppNamePrimitive->val.bytes.len == 0)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type string and to not be a NULL value",
                 SERVICE_NAME, EXECUTE_APPLICATION_NAME);
        return TWX_PRECONDITION_FAILED;
    }

    // Parameters can be a NULL string.
    retCode = twInfoTable_GetPrimitive(pItParams, EXECUTE_APPLICATION_PARAMETERS, 0, &pAppParametersPrimitive);
    if (pAppParametersPrimitive && pAppParametersPrimitive->type != TW_STRING)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type string.",
                 SERVICE_NAME, EXECUTE_APPLICATION_PARAMETERS);
        return TWX_PRECONDITION_FAILED;
    }

    retCode = twInfoTable_GetPrimitive(pItParams, EXECUTE_APPLICATION_WAIT, 0, &pSynchronousPrimitive);
    if (pSynchronousPrimitive && pSynchronousPrimitive->type != TW_BOOLEAN)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type boolean .",
                 SERVICE_NAME, EXECUTE_APPLICATION_WAIT);
        return TWX_PRECONDITION_FAILED;
    }

    retCode = twInfoTable_GetPrimitive(pItParams, EXECUTE_APPLICATION_WAIT_DELAY, 0, &pSynchronousDelayPrimitive);
    if (pSynchronousDelayPrimitive && pSynchronousDelayPrimitive->type != TW_INTEGER)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Services:  Service %s requires the input parameter '%s' to be of type integer .",
                 SERVICE_NAME, EXECUTE_APPLICATION_WAIT_DELAY);
        return TWX_PRECONDITION_FAILED;
    }

    // make sure application's path is converted per OS
    pszAppName = GsConvertPath((char *)pAppNamePrimitive->val.bytes.data);

    // set local variables.
    pszAppParameters = (pAppParametersPrimitive) ? pAppParametersPrimitive->val.bytes.data : NULL;
    if (pSynchronousPrimitive)
        bWait = (pSynchronousPrimitive->val.integer) ? TRUE : FALSE;
    if (pSynchronousDelayPrimitive)
    {
        if (pSynchronousDelayPrimitive->val.integer < 0)
            waitDelay = INFINITE;
        else
            waitDelay = pSynchronousDelayPrimitive->val.integer * 1000; // convert seconds to milliseconds
    }

    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Service %s is executing %s, with parameters: %s, Synchronous = %i, delay = %i",
             SERVICE_NAME, pszAppName, pszAppParameters, bWait, waitDelay);
    // Execute the application.
    // For Windows the exitCode can be STILL_ACTIVE (259) - this happens when the process is still running,
    // so there's no way to retrieve the exit code value. This can be avoided by choosing synchronous execution.
    retCode = GsExecuteProgram(pszAppName, pszAppParameters, &exitCode, bWait, waitDelay);
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Service %s exit code = %i (return code = %u)", SERVICE_NAME, exitCode, retCode);
    TW_FREE(pszAppName);

    pResultInfoTable = twInfoTable_FullCopy(g_pExeAppInfoTable);
    if (!pResultInfoTable)
    {
        *ppItContent = NULL;
        return TWX_NOT_ACCEPTABLE;
    }
    pResultRow = twInfoTableRow_Create(twPrimitive_CreateFromBoolean(retCode == TW_OK));
    twInfoTableRow_AddEntry(pResultRow, twPrimitive_CreateFromInteger((int)exitCode));
    twInfoTable_AddRow(pResultInfoTable, pResultRow);
    *ppItContent = pResultInfoTable;

    return TWX_SUCCESS;
} //> ExecuteApplication(...)
#undef SERVICE_NAME
//>----------------------------------------------------------------------------

//* ExecuteApplication service
static ServiceInfo s_getCurrentLogFileInfo = {
    GET_LOG_FILE_SERVICE_NAME, // name
    GET_LOG_FILE_SERVICE_DESC, // description
    // parameters
    {{NULL}},
    // resultType
    TW_NOTHING,
    // resultDS
    {NULL, {NULL}},
    //{"GenericStringList",
    // fields
    // {{"item", "item", TW_STRING},
    //  {NULL}}},
    // callback
    GetCurrentLogFile,
    // userData
    NULL};

static char *s_pszLogFileContent = NULL;
static char *s_pszLogFilePath = NULL;
static char s_pszTargetFilePath[256];
static int s_iNumLogParts = 0;
static int s_iCurrentLogPart = 0;
static int s_iLogPartMaxSize = 0;
static int s_iCurrentLogSize = 0;
static GS_BOOL s_bIsUploadingLog = FALSE;

int CreateLogsFolderServiceCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent);
int EmptyServiceCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent);
int AppendNextLogPartServiceCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent);

#define SERVICE_NAME GET_LOG_FILE_SERVICE_NAME
enum msgCodeEnum GetCurrentLogFile(const char *pszEntityName, const char *pszServiceName,
                                   twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
    //int retCode = TW_OK;
    uint32_t msgId = 0;
    //GS_BOOL bWait = FALSE;
    //GS_BOOL bSuccess = TRUE;
    //twInfoTable *pResultInfoTable = NULL;
    //twInfoTableRow *pResultRow = NULL;
    //twDataShape *pItDataShape = NULL;
    //char line[4096];
    char folderPath[128];
    //memset(line, 0, sizeof(line));
    GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "Invoking service : %s", SERVICE_NAME);

    // verify service name.
    if (strcmp(pszServiceName, SERVICE_NAME) != 0)
        return TWX_BAD_OPTION;
    memset(folderPath, 0, 128);
    sprintf(folderPath, "RemoteLogs/%s", g_pszFabNumber);
    twInfoTable *pInputPath = twInfoTable_CreateFromString("path", folderPath, TRUE);

    twApi_InvokeServiceAsync(TW_THING, "SystemRepository", "CreateFolder",
                             pInputPath, TRUE, CreateLogsFolderServiceCallback, &msgId);
    twInfoTable_Delete(pInputPath);
    if (!s_iLogPartMaxSize)
        s_iLogPartMaxSize = twcfg.max_message_size - 1024 * 128;
    return TWX_SUCCESS;
} //> GetCurrentLogFile(...)
#undef SERVICE_NAME
//>----------------------------------------------------------------------------

int CreateLogsFolderServiceCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent)
{
    twInfoTable_Delete(pContent);
    if (s_bIsUploadingLog)
        return TW_OK;
    s_bIsUploadingLog = TRUE;
    // complete path is ready to use
    // can proceed with file upload via REST
    // SaveText takes 'path' and 'content' inputs
    uint32_t msgId = 0;
    s_pszLogFilePath = GsLog_GetLogFilePath();
    //s_pszLogFilePath = "E:\\temp\\test.log"; // FIXME
    if (!s_pszLogFilePath)
    {
        return TW_ERROR_BAD_OPTION;
    }
    s_pszLogFileContent = GsReadFileContent(s_pszLogFilePath);
    if (!s_pszLogFileContent)
    {
        return TW_ERROR_READING_FILE;
    }
    //s_iLogPartMaxSize = 32; // FIXME
    s_iCurrentLogSize = strlen(s_pszLogFileContent);
    s_iCurrentLogPart = 0;
    s_iNumLogParts = s_iCurrentLogSize / s_iLogPartMaxSize + 1;

    memset(s_pszTargetFilePath, 0, 256);
    sprintf(s_pszTargetFilePath, "RemoteLogs/%s/Agent_%s_%ld.log", g_pszFabNumber, g_pszFabNumber ? g_pszFabNumber : "XYZ", twGetSystemTime(TRUE));
    AppendNextLogPartServiceCallback(0, TWX_SUCCESS, NULL, NULL); // trigger in place!
    return TW_OK;
} //> CreateLogsFolderServiceCallback(...)
//>----------------------------------------------------------------------------

typedef int (*response_cb)(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *content);

int AppendNextLogPartServiceCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent)
{
    twInfoTable_Delete(pContent);
    const char *pszDataColumnName = "data";
    const char *pszServiceName = "CreateTextFile";
    response_cb pCallback = AppendNextLogPartServiceCallback;
    twInfoTableRow *pRow = NULL;
    twInfoTable *pItInput = NULL;
    twDataShape *pDataShape = NULL;
    char *splitContent = NULL;
    char *pFileContentStart = NULL;
    size_t remainingLength = 0;
    uint32_t msgId = 0;
    if (code != TWX_SUCCESS || !s_pszLogFileContent)
    {
        s_bIsUploadingLog = FALSE;
        s_iCurrentLogPart = 0;
        if (s_pszLogFileContent != NULL)
            TW_FREE(s_pszLogFileContent);
        s_pszLogFileContent = NULL;
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Service CreateTextFile/AppendToTextFile code = %i: %s", code, reason);
        return code;
    }
    if (s_iCurrentLogPart + 1 >= s_iNumLogParts)
    {
        s_bIsUploadingLog = FALSE;
        pCallback = EmptyServiceCallback;
    }
    if (s_iCurrentLogPart > 0)
    {
        pszDataColumnName = "data"; // content is with SaveText
        pszServiceName = "AppendToTextFile";
    }
    if (s_iNumLogParts > 1)
    {
        pFileContentStart = s_pszLogFileContent + s_iCurrentLogPart * s_iLogPartMaxSize;
        remainingLength = strlen(pFileContentStart);
        if (remainingLength > s_iLogPartMaxSize)
            remainingLength = s_iLogPartMaxSize;
        splitContent = (char *)TW_MALLOC(s_iLogPartMaxSize + 1);
        memset(splitContent, 0, s_iLogPartMaxSize + 1);
        strncat(splitContent, pFileContentStart, remainingLength);
    }
    else
    {
        remainingLength = strlen(s_pszLogFileContent);
        splitContent = s_pszLogFileContent;
        s_pszLogFileContent = NULL;
    }
    {
        GsAppLog(GS_INFO, MODULE_GS_RUNTIME, "AppendToLogFile: part %d/%d, length = %d, path = '%s'",
                 s_iCurrentLogPart + 1, s_iNumLogParts, remainingLength, s_pszTargetFilePath);
        pDataShape = twDataShape_Create(twDataShapeEntry_Create("path", "", TW_STRING));
        twDataShape_AddEntry(pDataShape, twDataShapeEntry_Create(pszDataColumnName, "", TW_STRING));
        pItInput = twInfoTable_Create(pDataShape);
        pRow = twInfoTableRow_Create(twPrimitive_CreateFromString(s_pszTargetFilePath, TRUE)); // duplicate
        twInfoTableRow_AddEntry(pRow, twPrimitive_CreateFromString(splitContent, FALSE));      // take ptr ownership
        twInfoTable_AddRow(pItInput, pRow);
    }
    twApi_InvokeServiceAsync(TW_THING, "SystemRepository", (char *)pszServiceName,
                             pItInput, TRUE, pCallback, &msgId);
    twInfoTable_Delete(pItInput);
    s_iCurrentLogPart++;
    if (!s_bIsUploadingLog && s_pszLogFileContent != NULL)
        TW_FREE(s_pszLogFileContent);
    return TW_OK;
} //> AppendNextLogPartServiceCallback(...)
//>----------------------------------------------------------------------------

int EmptyServiceCallback(uint32_t id, enum msgCodeEnum code, char *reason, twInfoTable *pContent)
{
    if (code != TWX_SUCCESS)
        GsAppLog(TW_DEBUG, MODULE_GS_DATA, "Request failed: (%d) %s", code, reason);
    twInfoTable_Delete(pContent);
    return TW_OK;
} //> EmptyServiceCallback(...)
//>----------------------------------------------------------------------------
