//*****************************************************************************
//
//  Copyright © 1985-2020 PTC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :   SDK_ExtensionUtilities.c
//
//  Subsystem  :  ELGiAgent
//
//  Description:
//      Implementation file for various ThingWorx 'C' SDK extenion functions for the Agent project.
//      Why this code is here?? This code has a two fold purpose:
//          1. Wrap the SDK functions with a new function to add or enhance the functionality.
//          2. Expose SDK information that is not 'supposed' to be exposed by the SDK, but is
//             available from the SDK DLL by defining structures and methods as 'extern'.
// Programmer Note:
//                !!! THUS:  this code is subject to change per SDK API release.  !!!
//
//*****************************************************************************

#include "SDK_ExtensionUtilities.h"
#include "twFileManager.h"
#include "twProperties.h"
#include "twSwUpdateManager.h"
#include "twSubscribedProps.h"
#include "twOfflineMsgStore.h" // not needed, but maybe some day the items below will be in here.
#include <float.h>

// Programmer Note:
// !!! code is subject to change per API release.
// todo:  verify below code per release.
// the following code is directly from the C-SDK (not public) and may change pre API release.
// Define access to ThingWorx SDK 'private' variables

#ifdef __cplusplus
extern "C"
{
#endif

    // external SDK variables [that are not 'public']
    // from twSubscribedProps.c
    extern twSubscribedPropsMgr *getSPM();
    extern int getSPMSavedValuesCount(const char *thingName);
    extern int getSPMPersistedValuesLength();
    // from twOfflineMsgStore.c
    extern twOfflineMsgStore *tw_offline_msg_store;
    extern char twOfflineMsgStore_IsEnabled();
    // extern uint64_t getOfflineMsgSize();  // generates error if msg size is 0.

#ifdef __cplusplus
}
#endif

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************

/*****************************************************************************
 Convert a tw primative's value to a string.
 - input:  twPrimitive*
 - return:  pointer to string.
            The caller is responsible to free the memory of the returned string.

*****************************************************************************/
char *GsConvertPrimativeValueToString(twPrimitive *pPrimitive)
{
    char szValue[512];
    char *pszValue = szValue;
    memset(szValue, 0, 512);

    switch (pPrimitive->type)
    {
    case TW_STRING:
        pszValue = pPrimitive->val.bytes.data;
        break;
    case TW_NUMBER:
        sprintf(szValue, "%lf", pPrimitive->val.number);
        break;
    case TW_BOOLEAN:
        sprintf(szValue, "%i", (int)pPrimitive->val.boolean);
        break;
    case TW_INTEGER:
        sprintf(szValue, "%i", pPrimitive->val.integer);
        break;
    case TW_LOCATION:
        sprintf(szValue, "%lf:%lf", pPrimitive->val.location.latitude, pPrimitive->val.location.longitude);
        break;
    case TW_INFOTABLE:
        /*Assumption is the the infortable case is only asscoiated with property of type infotable 
		hence having fields Min, Max, Avg. Tried to use the DS name but is null.
		*/
        if (pPrimitive->val.infotable->rows->count == 1)
        {
            twInfoTableRow *rowData = NULL;
            double dataValueMin = 0;
            double dataValueMax = 0;
            double dataValueAvg = 0;
            int dataValueCount = 0;
            twInfoTable_GetNumber(pPrimitive->val.infotable, STR_MMA_MIN, 0, &dataValueMin);
            twInfoTable_GetNumber(pPrimitive->val.infotable, STR_MMA_MAX, 0, &dataValueMax);
            twInfoTable_GetNumber(pPrimitive->val.infotable, STR_MMA_AVG, 0, &dataValueAvg);
            twInfoTable_GetInteger(pPrimitive->val.infotable, STR_MMA_COUNT, 0, &dataValueCount);
            if (dataValueMin == DBL_MAX)
                dataValueMin = 0;
            if (dataValueMax == -DBL_MAX)
                dataValueMax = 0;
            snprintf(szValue, 511, "%lf:%lf:%lf:%d", dataValueMin, dataValueMax, dataValueAvg, dataValueCount);
        }
        else
        {
            pszValue = "UNKOWN";
        }
        break;
    default:
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME,
                 "Utilities function GsConvertPrimativeValueToString:  Unsupport base: %s",
                 baseTypeToString(pPrimitive->type));
        pszValue = "Illegal base type";
    }
    }
    return GsStringDup(pszValue);
}

//*****************************************************************************
// Given a virtual directory name, return the actual directory name for the Thing
//  *** The caller is responsible to free the memory of the returned pointer
char *GsGetActualFolderName(char *pszVirtualDir)
{
    char *pszRealPath = NULL;
    ListEntry *pEntry = NULL;
    twList *pList = twFileManager_ListVirtualDirs(g_pszThingIdentifier);
    if (!pList)
        return NULL;

    pEntry = twList_Next(pList, NULL);
    while (pEntry)
    {
        if (pEntry->value)
        {
            twFile *pDir = (twFile *)pEntry->value;
            if (strcmp(pDir->virtualPath, pszVirtualDir) == 0)
            {
                pszRealPath = GsStringDup(pDir->realPath);
                break;
            }
        }
        pEntry = twList_Next(pList, pEntry);
    }
    twList_Delete(pList);
    return pszRealPath;
}

//*****************************************************************************
// Simple 'find' function to find if an known list entry value is in a list.
GS_BOOL Gs_twList_Find(struct twList *pList, void *pEntryValue)
{
    GS_BOOL bFound = FALSE;
    struct ListEntry *pListEntry = NULL;
    twMutex_Lock(pList->mtx);
    pListEntry = pList->first;
    while (pListEntry)
    {
        if (pListEntry->value = pEntryValue)
        {
            bFound = TRUE;
            break;
        }
        pListEntry = pListEntry->next;
    }
    twMutex_Unlock(pList->mtx);
    return bFound;
}

//*****************************************************************************
// Append pNewList to pCompositeList to make a composite list.
// The compsite list will own all the nodes.
// Upon return,  pNewList will have a count 0 and will still need to be deleted to
// free the list's memory.
// Note: ThingWorx list locking is not global - therefore the caller will need to block lists as needed, BUT
//       ... BUT the pCompositeList's mutex CANNOT be locked because w/o recursive a mutex the twList_Add()
//       ... function would cause a dead-lock.
// Return:  TW_OK OR TW_INVALID_PARAM
int Gs_twList_AppendList(struct twList *pCompositeList, struct twList *pNewList)
{
    ListEntry *pEntry = NULL;

    if (pCompositeList == NULL || pNewList == NULL || pCompositeList->delete_function != pNewList->delete_function)
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Gs_twList_AppendList:  invalid parameters.");
        return TW_INVALID_PARAM;
    }

    // Ignore new list if not populated.
    if (pNewList->count == 0)
        return TW_OK;
    // ThingWorx locking is not global - therefore the caller will need to block lists as needed.
    pEntry = twList_Next(pNewList, NULL);
    while (pEntry)
    {
        twList_Add(pCompositeList, pEntry->value);
        pEntry = twList_Next(pNewList, pEntry);
    }

    pNewList->delete_function = GsDontDeleteFunc;
    twList_Clear(pNewList);

    return TW_OK;
}

/*
//*****************************************************************************

------------   Failed optimization code that may be re-vistied  -------------------


// Append pNewList to pCompositeList to make a composite list. 
// The compsite list will own all the nodes. 
// Upon return,  pNewList will have a count 0 and will still need to be deleted to
// free the list's memory.
// Both lists will be locked when appending.
// Return:  TW_OK OR TW_INVALID_PARAM
int Gs_twList_AppendList(struct twList *pCompositeList, struct twList *pNewList)
{
	if (pCompositeList == NULL || pNewList == NULL || pCompositeList->delete_function != pNewList->delete_function )
    {
        GsAppLog(GS_ERROR, MODULE_GS_RUNTIME, "Gs_twList_AppendList:  invalid parameters.");
		return TW_INVALID_PARAM;
    }

    // Ignore new list if not populated.
    if (pNewList->count == 0) 
        return TW_OK; 

	twMutex_Lock(pNewList->mtx);
	twMutex_Lock(pCompositeList->mtx);

    if (pCompositeList->first == NULL)
    {
        // the composite list is empty, so just transfer the 
        // new list to the composite list.
        pCompositeList->first = pNewList->first;
        pCompositeList->last = pNewList->last;
        pCompositeList->count = pNewList->count;
    }
    else
    {
        struct ListEntry *pEndOfCompositeFirstChain = pCompositeList->first->next;
        int i = 2;
        while (1)
        {
            if (pEndOfCompositeFirstChain->next)
            {
                pEndOfCompositeFirstChain = pEndOfCompositeFirstChain->next;
                i++;
            }
            else
                break;
        }
        if (i != pCompositeList->count)
        {
            i = i;  // debug
        }


	    // Set the new list's first node's previous pointer to the target's list last node
	    // This links the two list for a reverse search.
	    pNewList->first->prev = pCompositeList->last;

	    // Set the composite list'S last node to point to the new list's first node. 
        // ...
        pCompositeList->last->next = pNewList->first;

        // ... also link the end of the  composits list's 'first' chain to the new list.
	    // Thus, appending the new list to the composite list.
        pEndOfCompositeFirstChain->next = pNewList->first;

	    // Update the count of the composit list
	    pCompositeList->count += pNewList->count;
    }

	// Now, set the new list's count to 0 and NULL the node pointers.
	// At this time, the new list's nodes are fully transfered to the ownership
	// of the composite list.
	// The new list still needs to be deleted to free the list's memory.
	pNewList->count = 0;
	pNewList->first = NULL;
	pNewList->last = NULL;

	twMutex_Unlock(pCompositeList->mtx);
	twMutex_Unlock(pNewList->mtx);

    return TW_OK;
}
*/

//*****************************************************************************
// Get count of all queued values in the subscribed property manager.
int GsGetSpmQueueCount()
{
    int count = getSPMSavedValuesCount(g_pszThingIdentifier);
    if (count < 0)
        count = 0;
    return count;
}

//*****************************************************************************
// return the percent full of the offline message storage for persisted SPM values.
// Note:  this is stored to a different file then the offline messages.
// If the offline storage is not enabled or persited file stream is not created, return -1.
double GsGetSPMPersistedValuesOfflineStoragePercentFull()
{
    double percentFull = -1.0;
    int persistedValuesLength = getSPMPersistedValuesLength();
    if (twOfflineMsgStore_IsEnabled() && persistedValuesLength >= 0)
    {
        // Note:  through experience with the SDK, SPM's persisted values are stored to subscribed_props.bin.
        percentFull = ((double)persistedValuesLength / (double)twcfg.offline_msg_queue_size) * 100.0;
    }
    return percentFull;
}

//*********************************************************************************
// return TRUE if there is any SDK data pending being sent to the Server including:
//   - persisted messages
//   - persisted SPM values
//   - buffered SPM values.
//   - SCM jobs in process
GS_BOOL IsAnyInfoPendingToBePublished()
{
    if ((twOfflineMsgStore_IsEnabled() && tw_offline_msg_store->offlineMsgSize > 0) || GsGetSPMPersistedValuesOfflineStoragePercentFull() > 0 || GsGetSpmQueueCount() > 0 || twSwUpdateManager_IsJobInProcess() == TRUE)
        return TRUE;
    return FALSE;
}

//*********************************************************************************
// Replacement for SDK's twApi_AddPropertyToList in order to define the Property quality
int GsAddPropertyToList(propertyList *pPropertyList, char *pszName, twPrimitive *value,
                        DATETIME timestamp, char *pszQuality)
{
    return twList_Add(pPropertyList, twPropertyVTQ_Create(pszName, value, timestamp, pszQuality));
}

//*********************************************************************************
// Replacement for SDK's twApi_CreatePropertyList in order to define the Property quality
propertyList *GsCreatePropertyList(char *pszName, twPrimitive *value, DATETIME timestamp,
                                   char *pszQuality)
{
    propertyList *pPropertyList = twList_Create(twProperty_Delete);
    GsAddPropertyToList(pPropertyList, pszName, value, timestamp, pszQuality);
    return pPropertyList;
}

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************
