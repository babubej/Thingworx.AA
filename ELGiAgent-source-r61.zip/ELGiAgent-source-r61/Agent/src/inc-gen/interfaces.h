/*
 * AUTO-GENERATED interface.h for the src component.

 * Don't bother hand-editing this file.
 */

#ifndef __src_COMPONENT_INTERFACE_H_INCLUDE_GUARD
#define __src_COMPONENT_INTERFACE_H_INCLUDE_GUARD

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif // __src_COMPONENT_INTERFACE_H_INCLUDE_GUARD
