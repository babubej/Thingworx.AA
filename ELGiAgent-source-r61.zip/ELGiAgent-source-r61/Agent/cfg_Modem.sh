#!/bin/sh
# Copyright (C) Sierra Wireless Inc. Use of this work is subject to license.
#

# PATH
export PATH=/legato/systems/current/bin:/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin

iptables -F && iptables -I INPUT -j ACCEPT 
iptables -t nat -A POSTROUTING --out-interface rmnet_data0 -j MASQUERADE 
iptables -A FORWARD -o ecm0 -i rmnet_data0 -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i ecm0 -o rmnet_data0 -j ACCEPT
echo 1 > /proc/sys/net/ipv4/ip_forward


echo "Modem USB configuration completed"
